library("GLRItcl")
library(GSHydroTools)
library(DVstats)
library(EcoHydRology)

#Available data:

QWPortalGLRI <- QWPortalGLRI
pcodeINFO <- pcodeINFO
stationINFO <- stationINFO

genericCensoringValue <- function(qualifier,value, detectionLimit){
  valueToUse <- ifelse("<" == qualifier, 0, value)    
  return(valueToUse)
}

QWPull_OWC_useful <- filterBlanks(QWPortalGLRI)
QWPull_OWC_blanks <- QWPortalGLRI[!(c(1:nrow(QWPortalGLRI)) %in% QWPull_OWC_useful$index),]

stationINFO$shortName[stationINFO$fullSiteID == "USGS-04193500" | stationINFO$fullSiteID == "USGS-04193490"] <- "Maumee"
stationINFO$shortName[stationINFO$fullSiteID == "USGS-04157005" | stationINFO$fullSiteID == "USGS-04157000"] <- "Saginaw"

siteList <- setNames(stationINFO$shortName,stationINFO$fullSiteID)

# Sum values in all classes:
wideOWC <- wideGLRIData(filterGLRIData(QWPull_OWC_useful, genericCensoringValue))
wideOWC$flowCondition <- ifelse(wideOWC$HydrologicCondition=="Stable, low stage" | wideOWC$HydrologicCondition=="Stable, normal stage","Baseflow","Event")
wideOWC$flowCondition[grep("Storm",wideOWC$HydrologicEvent)] <- "Event"
wideOWC$flowCondition <- factor(wideOWC$flowCondition)


#Maumee
wideOWC$site <- ifelse(wideOWC$site=="USGS-04193500" | wideOWC$site=="USGS-04193490","USGS-04193500",wideOWC$site)
#Saginaw
wideOWC$site <- ifelse(wideOWC$site=="USGS-04157005" | wideOWC$site=="USGS-04157000","USGS-04157005",wideOWC$site)
wideOWC$labelName <- siteList[wideOWC$site]

pcodeINFO <- pcodeINFO[pcodeINFO$water_or_sediment == "water",]

OWCdataByClassFull <- PCodeClassSummary(wideOWC,pcodeINFO,"parameter_cd","class",merge=TRUE)
OWCSummaryFull <- statClassSummary(OWCdataByClassFull)
OWCSummaryFull$shortName <- as.character(siteList[OWCSummaryFull$site])
# subsummaryFull <- OWCSummaryFull[OWCSummaryFull$class == "HERBICIDE",c("site","count","startDate","endDate","station.nm")]
OWCdataByClassFull$flowCondition <- ifelse(OWCdataByClassFull$HydrologicCondition=="Stable, low stage" | OWCdataByClassFull$HydrologicCondition=="Stable, normal stage","Baseflow","Event")
OWCdataByClassFull$flowCondition[grep("Storm",OWCdataByClassFull$HydrologicEvent)] <- "Event"
OWCdataByClassFull$flowCondition <- factor(OWCdataByClassFull$flowCondition)

OWCdataByClassFull$labelName <- siteList[OWCdataByClassFull$site]

stationINFO$dischargeSites <- stationINFO$STAID
stationINFO$dischargeSites["04119400" == stationINFO$STAID] <- "04119000"
stationINFO$dischargeSites["04126010" == stationINFO$STAID] <- "04125550"
stationINFO$dischargeSites["04128500" == stationINFO$STAID] <- "04127997"
stationINFO$dischargeSites["04132052" == stationINFO$STAID] <- "04127997"
stationINFO$dischargeSites["04135020" == stationINFO$STAID] <- "04133501"
stationINFO$dischargeSites["04043000" == stationINFO$STAID] <- "04041500"
stationINFO$dischargeSites["04157000" == stationINFO$STAID] <- "04151500"
stationINFO$dischargeSites["04095090" == stationINFO$STAID] <- "04094000"
stationINFO$dischargeSites["04032000" == stationINFO$STAID] <- "04036000"
stationINFO$dischargeSites["04126000" == stationINFO$STAID] <- "04125550"
stationINFO$dischargeSites["04193490" == stationINFO$STAID] <- "04193500"
stationINFO$dischargeSites["04160900" == stationINFO$STAID] <- "04161000"
stationINFO$dischargeSites["410832081262100" == stationINFO$STAID] <- "04206000"
stationINFO$dischargeSites["04200000" == stationINFO$STAID] <- "04200500"
stationINFO$dischargeSites["04132025" == stationINFO$STAID] <- NA


stationINFO$distanceToSite <- rep(0,nrow(stationINFO))
stationINFO$distanceToSite["04119400" == stationINFO$STAID] <- 18
stationINFO$distanceToSite["04126010" == stationINFO$STAID] <- 17.5
stationINFO$distanceToSite["04128500" == stationINFO$STAID] <- 9.5
stationINFO$distanceToSite["04132052" == stationINFO$STAID] <- 25.5
stationINFO$distanceToSite["04135020" == stationINFO$STAID] <- 10.3
stationINFO$distanceToSite["04043000" == stationINFO$STAID] <- 14.8
stationINFO$distanceToSite["04157000" == stationINFO$STAID] <- 12.3
stationINFO$distanceToSite["04095090" == stationINFO$STAID] <- 4.6
stationINFO$distanceToSite["04032000" == stationINFO$STAID] <- 11.5
stationINFO$distanceToSite["04126000" == stationINFO$STAID] <- 12.75
stationINFO$distanceToSite["04193490" == stationINFO$STAID] <- 2.138
stationINFO$distanceToSite["04160900" == stationINFO$STAID] <- 8.634
stationINFO$distanceToSite["410832081262100" == stationINFO$STAID] <- 5.633
stationINFO$distanceToSite["04200000" == stationINFO$STAID] <- 2.327

wideOWC$date_site <- paste(wideOWC$ActivityStartDateGiven, wideOWC$site, sep="_")
OWCdataByClassFull$date_site <- paste(OWCdataByClassFull$ActivityStartDateGiven, OWCdataByClassFull$site, sep="_")

# eventSummary <- data.frame()

# pdf("Baseflow_80.pdf",paper="a4r",width=11.0,height=8.5)
for (i in stationINFO$site.no[!is.na(stationINFO$site.no)]){
  cat(which(stationINFO$site.no[!is.na(stationINFO$site.no)] %in% i),"\n")
  subSummary <- OWCSummaryFull[OWCSummaryFull$site == paste("USGS",i,sep="-"),]
  
  if (nrow(subSummary) == 0){
    cat("No sample at site,", i, "\n")
    next
  }
  
  dischargeID <- stationINFO$dischargeSites[which(stationINFO$STAID %in% i)]
    
  INFO <- getSiteFileData(i)
  
  subData <- OWCdataByClassFull[OWCdataByClassFull$site == paste("USGS",i,sep="-"),]
  subData$Date <- as.Date(subData$ActivityStartDateGiven)
  
  DA_mi <- as.numeric(INFO$drain.area.va)
  
  if(length(DA_mi)>1){
    DA_mi <- DA_mi[!is.na(DA_mi)]
  }
  
  if (is.na(DA_mi)) {
    DA_mi <- 50
    cat("No drainage area for",i,"\n")
  }
  
  
  sampleDates <- data.frame(ActivityStartDateGiven = subData$ActivityStartDateGiven, ActivityEndDateGiven = subData$ActivityEndDateGiven)
    
  Start_extend <- as.character(as.Date(min(sampleDates$ActivityStartDateGiven, na.rm=TRUE))-60)
  End_extend <- as.character(as.Date(max(sampleDates$ActivityStartDateGiven, na.rm=TRUE))+60)
  
  #site could be a different site than where the sample was collected, and even different between getDVData and findSampleQ
  Daily <- getDVData(dischargeID,'00060', Start_extend, End_extend,convert=FALSE)
  
  
  sampleDates <- findSampleQ(dischargeID, sampleDates, Daily)
  
  prepareHysep <- getMaxStartEnd(Daily)
  naFreeDaily <- Daily[!is.na(Daily$Q),]
  
  HYSEPReturn <- hysep(naFreeDaily$Q, naFreeDaily$Date, Start = prepareHysep$Start, 
                       End = prepareHysep$End, da=DA_mi,
                       select = "sliding", STAID = i)
  
  sampleDates <- determineHYSEPEvents(HYSEPReturn, sampleDates, 0.8)
  
  baseflowEcoHydRology <- BaseflowSeparation(naFreeDaily$Q, passes=3)
#   hydrograph(input=naFreeDaily[,c("Date","Q")],streamflow2=baseflowEcoHydRology[,1])
  baseflowEcoHydRology$Dates <- naFreeDaily$Date
  sampleDates$Dates <- as.Date(sampleDates$maxSampleTime)
  sampleDatesNew <- mergeNearest(sampleDates, "Dates",
                                 right=baseflowEcoHydRology, dates.right="Dates", max.diff="1 days")
  
  sampleDatesNew$flowCondition_EcoHydRology <- ifelse(0.8*sampleDatesNew$Discharge_cubic_feet_per_second > sampleDatesNew$bt, "Event", "Baseflow")
  HYSEPReturn$EcoHydRology <- baseflowEcoHydRology[which(baseflowEcoHydRology$Dates %in% HYSEPReturn$Dates),1]

  plotHYSEPOverview(sampleDatesNew,Daily,INFO,dischargeID,HYSEPReturn,
                    HYSEPcolNames=c("LocalMin","Fixed","EcoHydRology"),
                    baseflowColumns=c("flowConditionHYSEP_localMin","flowConditionHYSEP_Fixed",
                                      "flowCondition_EcoHydRology")
  )
  
  sampleDatesNew$site <- i
  sampleDatesNew$dischargeSite <- dischargeID
  
#   eventSummary <- rbind(eventSummary, sampleDatesNew)
  
}
# dev.off()
