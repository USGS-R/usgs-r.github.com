
library(GSHydroTools)
library(GLRItcl)
library(dataRetrieval)

SI <- SI
i <- sapply(SI, is.factor)
SI[i] <- lapply(SI[i], as.character)

stationINFO <- stationINFO

stationINFO <- merge(stationINFO, SI, by.x="shortName", by.y="Site.orig",all = TRUE)
stationINFO$labelLat <- NULL
stationINFO$labelLon <- NULL

stationINFO$offsetLat[is.na(stationINFO$offsetLat)] <- 0
stationINFO$offsetLon[is.na(stationINFO$offsetLon)] <- 0
stationINFO$offsetLineLat[is.na(stationINFO$offsetLineLat)] <- 0
stationINFO$offsetLineLon[is.na(stationINFO$offsetLineLon)] <- 0
stationINFO$lat <- NULL
stationINFO$lon <- NULL

# write.csv(stationINFO, file="station.csv",row.names=FALSE)


#Random data:
lat <- as.numeric(stationINFO$dec.lat.va[!is.na(stationINFO$dec.lat.va)])
lon <-  as.numeric(stationINFO$dec.long.va[!is.na(stationINFO$dec.long.va)])
y <- runif(n=length(lat),min=0,max=50)
countVector <- round(runif(n=length(lat),min=0,max=30),0)

# With labels:
politicalBounds <- shape_poliboundsClip
hydroPolygons <- subShape_hydropolyClip
hydroLines <- shape_hydrolineClip

xmin <- -96.5
xmax <- -72
ymin <- 40.5
ymax <- 49.5

labelVar <- "shortName"
offsetLatVar <- "offsetLat"
offsetLonVar <- "offsetLon"
offsetLineLatVar <- "offsetLineLat"
offsetLineLonVar <- "offsetLineLon"
colorVar <- "y"
sizeVar <- "count"
latVar <- "lat"
lonVar <- "lon"
mainTitle <- "Passive Sampler Site Locations"

stationINFO2 <- read.csv(file = "D:/LADData/RCode/GSHydroTools/station.csv",stringsAsFactors=FALSE)
df <- data.frame(y=y, lat=lat,lon=lon,count=countVector,stringsAsFactors=FALSE)
df <- merge(df, stationINFO2, by.x=c("lat","lon"),by.y=c("dec.lat.va","dec.long.va"))
df <- df[df$PassiveSampler == 1,]
pdf("GLex.pdf",width=11,height=8)
MapLocations(df,latVar,lonVar,
             politicalBounds,hydroPolygons,hydroLines,
             xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
             labels=labelVar, 
             offsetLat=offsetLatVar, 
             offsetLon=offsetLonVar,
             offsetLineLat=offsetLineLatVar,
             offsetLineLon=offsetLineLonVar)
dev.off()
#To view the produced plot, us the following command:
shell.exec("GLex.pdf")

library("GLRItcl")
#Available data:

passiveSites <- stationINFO2$fullSiteID[stationINFO2$PassiveSampler == 1]

pathToData <- "M:/QW Monitoring Team/GLRI toxics/Meetings/EPA July 16 2014/"

dataFiles <- c("ClassSumOCPCBPBDEPassive.csv","ClassSumOWCPassive.csv","ClassSumPAHPassive.csv",
               "ClassSumPharmPassive.csv","ClassSumYESPassive.csv","priorityPathBact.csv")

##########################################################################
OCPData <- read.csv(paste(pathToData, dataFiles[1], sep=""),stringsAsFactors=FALSE)
OCPData$FullSiteID <- paste("USGS-",padVariable(as.character(OCPData$Site),8),sep="")
OCPData$FullSiteID[nchar(OCPData$Site)>7] <- paste("USGS-",padVariable(as.character(OCPData$Site[nchar(OCPData$Site)>7]),9),sep="")

df <- merge(OCPData, stationINFO2, by.x=c("FullSiteID"),by.y=c("fullSiteID"))
latVar <- "dec.lat.va"
lonVar <- "dec.long.va"
xleft <- -95
ybottom <- 41
xright <- -90.8
ytop <- 44

for(i in names(OCPData)[1:3]){
  pdf(paste("Map",i,"Passive.pdf",sep=""),width=11,height=8)
  mainTitle = paste(i," [pg/L]",sep="")
  MapColor(df,colorVar=i,
               latVar,lonVar,
               politicalBounds,hydroPolygons,hydroLines,
               xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
               labels=labelVar, 
               offsetLat=offsetLatVar, 
               offsetLon=offsetLonVar,
               offsetLineLat=offsetLineLatVar,
               offsetLineLon=offsetLineLonVar,
               xleft=xleft,xright=xright,ytop=ytop,
               ybottom=ybottom,
               units=4)
  dev.off()
  #To view the produced plot, us the following command:
  shell.exec(paste("Map",i,"Passive.pdf",sep=""))
}

##############################################################################
OWCData <- read.csv(paste(pathToData, dataFiles[2], sep=""),stringsAsFactors=FALSE)
OWCData$FullSiteID <- paste("USGS-",padVariable(as.character(OWCData$Site),8),sep="")
OWCData$FullSiteID[nchar(OWCData$Site)>7] <- paste("USGS-",padVariable(as.character(OWCData$Site[nchar(OWCData$Site)>7]),9),sep="")

df <- merge(OWCData, stationINFO2, by.x=c("FullSiteID"),by.y=c("fullSiteID"))

for(i in names(df)[2:14]){
  pdf(paste("Map",i,"Passive.pdf",sep=""),width=11,height=8)
  mainTitle = paste(i," [ng/L]",sep="")
  MapColor(df,colorVar=i,
           latVar,lonVar,
           politicalBounds,hydroPolygons,hydroLines,
           xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
           labels=labelVar, 
           offsetLat=offsetLatVar, 
           offsetLon=offsetLonVar,
           offsetLineLat=offsetLineLatVar,
           offsetLineLon=offsetLineLonVar,
           xleft=xleft,xright=xright,ytop=ytop,
           ybottom=ybottom,
           units=3)
  dev.off()
  #To view the produced plot, us the following command:
  shell.exec(paste("Map",i,"Passive.pdf",sep=""))
}

##################################################################################
PAHData <- read.csv(paste(pathToData, dataFiles[3], sep=""),stringsAsFactors=FALSE)
PAHData$FullSiteID <- paste("USGS-",padVariable(as.character(PAHData$Site),8),sep="")
PAHData$FullSiteID[nchar(PAHData$Site)>7] <- paste("USGS-",padVariable(as.character(PAHData$Site[nchar(PAHData$Site)>7]),9),sep="")

df <- merge(PAHData, stationINFO2, by.x=c("FullSiteID"),by.y=c("fullSiteID"))

i <- "PAH"
pdf(paste("Map",i,"Passive.pdf",sep=""),width=11,height=8)
mainTitle = paste(i," [pg/L]",sep="")
MapColor(df,colorVar=i,
         latVar,lonVar,
         politicalBounds,hydroPolygons,hydroLines,
         xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
         labels=labelVar, 
         offsetLat=offsetLatVar, 
         offsetLon=offsetLonVar,
         offsetLineLat=offsetLineLatVar,
         offsetLineLon=offsetLineLonVar,
         xleft=xleft,xright=xright,ytop=ytop,
         ybottom=ybottom,
         units=4)
dev.off()
#To view the produced plot, us the following command:
shell.exec(paste("Map",i,"Passive.pdf",sep=""))


####################################################################################
PharmData <- read.csv(paste(pathToData, dataFiles[4], sep=""),stringsAsFactors=FALSE)
PharmData$FullSiteID <- paste("USGS-",padVariable(as.character(PharmData$Site),8),sep="")
PharmData$FullSiteID[nchar(PharmData$Site)>7] <- paste("USGS-",padVariable(as.character(PharmData$Site[nchar(PharmData$Site)>7]),9),sep="")

df <- merge(PharmData, stationINFO2, by.x=c("FullSiteID"),by.y=c("fullSiteID"))
i <- "dfSum"
pdf(paste("Map",i,"Passive.pdf",sep=""),width=11,height=8)
mainTitle = paste("Pharm"," [ng/L]",sep="")
MapColor(df,colorVar=i,
         latVar,lonVar,
         politicalBounds,hydroPolygons,hydroLines,
         xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
         labels=labelVar, 
         offsetLat=offsetLatVar, 
         offsetLon=offsetLonVar,
         offsetLineLat=offsetLineLatVar,
         offsetLineLon=offsetLineLonVar,
         xleft=xleft,xright=xright,ytop=ytop,
         ybottom=ybottom,
         units=3)
dev.off()
#To view the produced plot, us the following command:
shell.exec(paste("Map",i,"Passive.pdf",sep=""))

#####################################################################################
YesData <- read.csv(paste(pathToData, dataFiles[5], sep=""),stringsAsFactors=FALSE)
YesData <- data.frame(YES=as.numeric(YesData[1,]),Site=substr(colnames(YesData),2,nchar(colnames(YesData))))
YesData$FullSiteID[nchar(YesData$Site)>7] <- paste("USGS-",padVariable(as.character(YesData$Site[nchar(YesData$Site)>7]),9),sep="")

YesData$FullSiteID <- paste("USGS-",padVariable(as.character(PharmData$Site),8),sep="")

df <- merge(YesData, stationINFO2, by.x=c("FullSiteID"),by.y=c("fullSiteID"))
i <- "YES"
pdf(paste("Map",i,"Passive.pdf",sep=""),width=11,height=8)
mainTitle = paste(i," [ng/L]",sep="")
MapColor(df,colorVar=i,
         latVar,lonVar,
         politicalBounds,hydroPolygons,hydroLines,
         xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
         labels=labelVar, 
         offsetLat=offsetLatVar, 
         offsetLon=offsetLonVar,
         offsetLineLat=offsetLineLatVar,
         offsetLineLon=offsetLineLonVar,
         xleft=xleft,xright=xright,ytop=ytop,
         ybottom=ybottom,
         units=3)
dev.off()
#To view the produced plot, us the following command:
shell.exec(paste("Map",i,"Passive.pdf",sep=""))

#####################################################################################
BactData <- read.csv(paste(pathToData, dataFiles[6], sep=""),stringsAsFactors=FALSE)
BactData$FullSiteID <- paste("USGS-",padVariable(as.character(BactData$Site),8),sep="")
BactData$FullSiteID[nchar(BactData$Site)>7] <- paste("USGS-",padVariable(as.character(BactData$Site[nchar(BactData$Site)>7]),9),sep="")

df <- merge(BactData, stationINFO2, by.x=c("FullSiteID"),by.y=c("fullSiteID"))
df[,seq(4,20,2)] <- 100*df[,seq(4,20,2)]
for(i in names(df)[seq(4,20,2)]){
  pdf(paste("Map",i,"Passive.pdf",sep=""),width=11,height=8)
  mainTitle = paste(i," [%]",sep="")
  MapColor(df,colorVar=i,
           latVar,lonVar,
           politicalBounds,hydroPolygons,hydroLines,
           xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
           labels=labelVar, 
           offsetLat=offsetLatVar, 
           offsetLon=offsetLonVar,
           offsetLineLat=offsetLineLatVar,
           offsetLineLon=offsetLineLonVar,
           xleft=xleft,xright=xright,ytop=ytop,
           ybottom=ybottom,
           units=9)
  dev.off()
  #To view the produced plot, us the following command:
  shell.exec(paste("Map",i,"Passive.pdf",sep=""))
}

statClassSummary <- function(dataByClass){
  
  sites <- unique(dataByClass$site)
  
  classes <- unique(pcodeINFO$class)
  classes <- classes[!is.na(classes)]
  
  colNames <- colnames(dataByClass)
  colNamesSplitPreffix <- sapply(strsplit(colNames, "_"),function(x)x[1])
  colNamesSplitSuffix <- sapply(strsplit(colNames, "_"),function(x)x[2])
  
  #   sites <- unique(stationINFO$station.nm)
  names(sites) <- stationINFO$fullSiteID[which(stationINFO$station.nm %in% sites)]
  
  for (i in 1:length(classes)){
    indexClass <- which(colNamesSplitSuffix == classes[i])
    indexValue <- which(colNamesSplitPreffix == "sumOfValues")
    indexPercent <- which(colNamesSplitPreffix == "percentDetected")
    indexValue <- indexClass[which(indexClass %in% indexValue)]
    indexPercent <- indexClass[which(indexClass %in% indexPercent)]
    
    #Values:
    subDF <- dataByClass[,c(1:4,indexValue, indexPercent)]
    
    DF <- subset(aggregate(subDF,by=list(subDF$site),FUN=length),select=Group.1:site)
    colnames(DF) <- c("site","count")
    DF$startDate <- aggregate(subDF$ActivityStartDateGiven,by=list(subDF$site),FUN=min, na.rm=TRUE)$x
    DF$endDate <- aggregate(subDF$ActivityStartDateGiven,by=list(subDF$site),FUN=max, na.rm=TRUE)$x
    DF$mean <- aggregate(subDF[[5]],by=list(subDF$site),FUN=mean, na.rm=TRUE)$x
    DF$max <- aggregate(subDF[[5]],by=list(subDF$site),FUN=max, na.rm=TRUE)$x
    DF$min <- aggregate(subDF[[5]],by=list(subDF$site),FUN=min, na.rm=TRUE)$x
    DF$median<- aggregate(subDF[[5]],by=list(subDF$site),FUN=median, na.rm=TRUE)$x
    DF$percentDetect <- aggregate(subDF[[6]],by=list(subDF$site),FUN=mean, na.rm=TRUE)$x
    DF$station.nm <- sites[DF$site]
    DF$class <- classes[i]
    DF$sum <- aggregate(subDF[[5]],by=list(subDF$site),FUN=sum, na.rm=TRUE)$x
    
    
    if (1 == i){
      fullDF <- DF
    } else {
      fullDF <- rbind(fullDF, DF)
    }
    
  }
  
  return(fullDF)
}

QWPortalGLRI <- QWPortalGLRI
genericCensoringValue <- function(qualifier,value, detectionLimit){
  valueToUse <- ifelse("<" == qualifier, 0, value)    
  return(valueToUse)
}
QWPull_OWC_useful <- filterBlanks(QWPortalGLRI)
wideOWC <- wideGLRIData(filterGLRIData(QWPull_OWC_useful, genericCensoringValue))
OWCdataByClass <- PCodeClassSummary(wideOWC,pcodeINFO,"parameter_cd","class",merge=TRUE)

OWCSummaryFull <- statClassSummary(OWCdataByClass)

df <- merge(OWCSummaryFull, stationINFO2, by.x=c("site"),by.y=c("fullSiteID"),all=TRUE)

labelVar <- "shortName"
offsetLatVar <- "offsetLat"
offsetLonVar <- "offsetLon"
offsetLineLatVar <- "offsetLineLat"
offsetLineLonVar <- "offsetLineLon"
latVar <- "dec.lat.va"
lonVar <- "dec.long.va"
mainTitle <- "Water OWC"

classes <- unique(df$class[!is.na(df$class)])
sites <- unique(df$shortName)

for (j in classes){
  subdf <- df[df$class == j,]
  subdf <- subdf[!is.na(subdf$sum),]
  
  if("FLAVOR/FRAGRANCE" == j) j <- "FLAVOR.FRAGRANCE"
  if("DYE/PIGMENT" == j) j <- "DYE.PIGMENT"
  
  df$shortName[df$shortName == "Saginaw2"] <- ""
  df$shortName[df$shortName == "Maumee1"] <- ""
  
  pdf(paste("Map",j,"Water.pdf",sep=""),width=11,height=8)
  mainTitle = paste(j," [ng/L]",sep="")
cat(mainTitle, "\n")
  MapColor(subdf,colorVar="sum",
           latVar,lonVar,
           politicalBounds,hydroPolygons,hydroLines,
           xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
           labels=labelVar, 
           offsetLat=offsetLatVar, 
           offsetLon=offsetLonVar,
           offsetLineLat=offsetLineLatVar,
           offsetLineLon=offsetLineLonVar,
           xleft=xleft,xright=xright,ytop=ytop,
           ybottom=ybottom,
           units=3)
  dev.off()
  shell.exec(paste("Map",j,"Water.pdf",sep=""))
  
}
