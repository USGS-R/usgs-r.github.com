### R code from vignette source 'Metals.Rnw'

###################################################
### code chunk number 1: Metals.Rnw:22-26
###################################################
# Load the restrend package and the data
library(restrend)
data(EstrendSub)
head(EstrendSub)


###################################################
### code chunk number 2: Metals.Rnw:36-47
###################################################
# Compute FLOW.
EstrendSub <- transform(EstrendSub, FLOW=coalesce(QI, QD))
# Convert, the default scheme is "booker"
EstrendSub.qw <- convert2qw(EstrendSub)
# Create the subset, the Pcolumn name is preserved
Metals <- subset(EstrendSub.qw, select=c("STAID", "DATES", "FLOW", 
                                         "PIron", "PCopper"))
# Rename metals to remove the leading P
names(Metals)[4:5] <- c("Iron", "Copper")
# Show the first few rows of the data
head(Metals)


###################################################
### code chunk number 3: Metals.Rnw:52-57
###################################################
# Subset the data and show first few lines
Metals <- subset(Metals, !(is.na(Iron) & is.na(Copper)))
head(Metals)
# Create the report
sampReport(Metals, DATES="DATES", STAID="STAID", file="MetalsSampling")


###################################################
### code chunk number 4: Metals.Rnw:71-75
###################################################
# Set up the project
setProj("metals", Metals, STAID="STAID", DATES="DATES", 
        Snames=c("Iron", "Copper"), FLOW="FLOW", 
        type="tobit", Start="1974-10-01", End="1989-10-01")


###################################################
### code chunk number 5: Metals.Rnw:93-95
###################################################
# Which are OK?
estrend.st


###################################################
### code chunk number 6: Metals.Rnw:105-107
###################################################
# Trend tests, accepting default
tobitTrends()


###################################################
### code chunk number 7: Metals.Rnw:115-117
###################################################
# Trend tests, accepting default
plotTT(Station="07297910", Sname="Iron", device="pdf")


###################################################
### code chunk number 8: Metals.Rnw:125-128
###################################################
# get the trends
metals.tnd <- getTrends()
print(metals.tnd)


###################################################
### code chunk number 9: Metals.Rnw:136-138
###################################################
# get the history
estrend.cl


