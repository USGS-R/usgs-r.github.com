library(GSHydroTools)
library(XLConnect)
setwd("\\\\igsarmewfsapa/projects/QW Monitoring Team/GLRI toxics/Data Analysis/")

SitesAll <- readWorksheet(loadWorkbook(filename="./GLRI Site Characteristics LatLon LandUse.xlsx"), sheet = "Master")
SitesAll <- subset(SitesAll,!is.na(lat.dd2))

setwd("\\\\igsarmewfsapa/projects/QW Monitoring Team/GLRI toxics/Data Analysis/Prioritization 2013/Rankings and graphics")

pSites <- readWorksheet(loadWorkbook(filename="./prioritySiteList.xlsx"), sheet = "Sheet1")
row.names(SitesAll) <- SitesAll$Station.shortname

pSites$lat <- SitesAll[pSites$Site,"lat.dd2"]
pSites$lon <- SitesAll[pSites$Site,"lon.dd2"]


politicalBounds <- shape_poliboundsClip #from GLRItcl
hydroPolygons <- subShape_hydropolyClip #from GLRItcl
hydroLines <- shape_hydrolineClip #from GLRItcl
xmin <- -96.5
xmax <- -72
ymin <- 40.5
ymax <- 49.5
plotSymbol <- 21
fillCol <- "orangered4"
mainTitle <- "Preliminary site selection for 2014"


#write.table(pSites,file="prioritySites.csv",sep=",",row.names=FALSE)

pSites <- read.csv("prioritySites.csv")
pSites$labelLat <- pSites$lat+pSites$offsetLat
pSites$labelLon <- pSites$lon+pSites$offsetLon



#pdf("test.pdf",width=11.0,height=8.5)
png("test.png",width=11.0,height=8.5,units="in",res=300)
pSites <- pSites[!is.na(pSites$lat),]

plot(politicalBounds,col="gray90",xlim=c(xmin,xmax),ylim=c(ymin,ymax))
plot(hydroPolygons,col="lightskyblue2",xlim=c(xmin,xmax),ylim=c(ymin,ymax),add=TRUE)#
lines(hydroLines,col="lightskyblue2",xlim=c(xmin,xmax),ylim=c(ymin,ymax))#
plot(politicalBounds,add=TRUE)
points(pSites[,"lon"], pSites[,"lat"],pch=plotSymbol, col="black",bg=fillCol,cex=1.2)
mtext(mainTitle,side=3,line=-4,outer=TRUE,font=2,cex=1.3)
text(x=pSites$labelLon,y=pSites$labelLat,labels=pSites$Site,cex=0.75)


dev.off()
shell.exec("test.png")
#shell.exec("test.pdf")

