#to install DVstats:
# install.packages("DVstats", repos="http://usgs-r.github.com")

library(GSHydroTools)
library(DVstats)
site <- "04085427"

INFO <- getSiteFileData(site)

sampleDates <- sampleDates

Start_extend <- as.character(as.Date(min(sampleDates$ActivityStartDateGiven, na.rm=TRUE))-60)
End_extend <- as.character(as.Date(max(sampleDates$ActivityStartDateGiven, na.rm=TRUE))+60)

#site could be a different site than where the sample was collected, and even different between getDVData and findSampleQ
Daily <- getDVData(site,'00060', Start_extend, End_extend,convert=FALSE)
sampleDates <- findSampleQ(site, sampleDates, Daily)

DA_mi <- as.numeric(INFO$drain.area.va)
if(length(DA_mi)>1){
  DA_mi <- DA_mi[!is.na(DA_mi)]
}

if (is.na(DA_mi)) {
  DA_mi <- 50
  cat("No drainage area for",i,"\n")
}

prepareHysep <- getMaxStartEnd(Daily)
naFreeDaily <- Daily[!is.na(Daily$Q),]

HYSEPReturn <- hysep(naFreeDaily$Q, naFreeDaily$Date, Start = prepareHysep$Start, 
                     End = prepareHysep$End, da=DA_mi,
                     select = "sliding", STAID = site)

sampleDates <- determineHYSEPEvents(HYSEPReturn, sampleDates, 0.8)
plotHYSEPOverview(sampleDates,Daily,INFO,site,HYSEPReturn)

library(EcoHydRology)

baseflowEcoHydRology <- BaseflowSeparation(naFreeDaily$Q, passes=3)
hydrograph(input=naFreeDaily[,c("Date","Q")],streamflow2=baseflowEcoHydRology[,1])
baseflowEcoHydRology$Dates <- naFreeDaily$Date
sampleDates$Dates <- as.Date(sampleDates$maxSampleTime)
sampleDatesNew <- mergeNearest(sampleDates, "Dates",
                right=baseflowEcoHydRology, dates.right="Dates", max.diff="1 days")

sampleDatesNew$flowCondition_EcoHydRology <- ifelse(0.8*sampleDatesNew$Discharge_cubic_feet_per_second > sampleDatesNew$bt, "Event", "Baseflow")
HYSEPReturn$EcoHydRology <- baseflowEcoHydRology[,1]
# pdf("EcoHydRology.pdf")
plotHYSEPOverview(sampleDatesNew,Daily,INFO,site,HYSEPReturn,
                  HYSEPcolNames=c("LocalMin","Fixed","EcoHydRology"),
                  baseflowColumns=c("flowConditionHYSEP_localMin","flowConditionHYSEP_Fixed",
                                    "flowCondition_EcoHydRology")
                    )
# dev.off()
