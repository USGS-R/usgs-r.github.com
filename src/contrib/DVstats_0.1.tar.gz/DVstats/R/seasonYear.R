#'Season of Year
#'
#'Create an ordered factor or numeric values from a vector of dates based on
#'the season of the year.
#'
#'The season year is allowed to overlap the calendar year, so the \code{end.month}
#'may precede the \code{start.month}.
#'
#'@param x an object of class "Date" or "POSIXt." Missing values are permitted and
#'result in corresponding missing values in the output.
#'@param start.month a charcter string indicating the starting month of the season, 
#'must match either the month name (\code{month.name}) or the month abbreviation
#'(\code{month.abb}). See \bold{Details}.
#'@param end.month a charcter string indicating the ending month of the season, 
#'must match either the month name (\code{month.name}) or the month abbreviation
#'(\code{month.abb}). See \bold{Details}.
#'@param numeric a logical value that indicates whether the returned values
#'should be numeric \code{TRUE} or an ordered factor \code{FALSE}. The default
#'value is \code{FALSE}.
#'@return An ordered factor or numeric vector corresponding to the season of the year.
#'Input data values outside of the months specified are retruned as missing values
#'\code{NA}.
#'@note The season year is defined as the period from the first day of the starting month
#'to the last day of the ending month.
#'The season year is designated by the calendar year in which it ends. Thus, the season
#'year starting December 1, 1998 and ending March 30, 1999, is the "1999 December-March season year."
#'@seealso \code{\link{month.name}}, \code{\link{month.abb}}
#'@keywords manip
#'@examples
#'
#'\dontrun{
#'library(USGSwsData)
#'data(QW05078470)
#'## Return an ordered factor
#'seasonYear(QW05078470$DATES)
#'}
#'@export
seasonYear <- function(x, start.month="June", end.month="September", numeric=FALSE) {
  ## Coding history:
  ##    2013Apr08 DLLorenz original coding
  ##
  x <- as.POSIXlt(x)
  yr <- x$year + 1900L
  mn <- x$mon + 1L
  ## adjust for season year
  if(nchar(start.month) == 3) # use month.abb
    st.mn <- which(month.abb == start.month)
  else
    st.mn <- pmatch(start.month, month.name)
  if(nchar(end.month) == 3) # use month.abb
    en.mn <- which(month.abb == end.month)
  else
    en.mn <- pmatch(end.month, month.name)
  if(en.mn == st.mn) { # only one month
     out <- mn != st.mn
     yr[out] <- NA
  }
  else if(en.mn > st.mn) { # All within the year
    out <- mn < st.mn | mn > en.mn
	yr[out] <- NA
  }
  else { # Overlap
    out <- mn > en.mn & mn < st.mn
	yr[out] <- NA
    yr <- yr + ifelse(mn < en.mn + 1L, 0L, 1L)
  }
  if(numeric)
    return(yr)
  ordered(yr)
}
