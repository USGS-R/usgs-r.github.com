### R code from vignette source 'PiperPlot.Rnw'

###################################################
### code chunk number 1: PiperPlot.Rnw:27-38
###################################################
# Load the smwrGraphs package
library(smwrGraphs)
# Generate a random sample for the ternary diagram
set.seed(2727)
# Ternary diagram data
X <- runif(25, .1, 1.)
Y <- runif(25, .1, .8)
Z <- runif(25, .3, 1.)
# Get the selected groundwqater quality date from Hem
library(smwrData)
data(MiscGW)


###################################################
### code chunk number 2: PiperPlot.Rnw:51-78
###################################################
# Transform the data. This example will ignore potassium, fluoride, and nitrate
# (carbonate is either 0 or missing and will also be ignored).
PD <- transform(MiscGW, Ca.meq = conc2meq(Calcium, "calcium"),
                    Mg.meq = conc2meq(Magnesium, "magnesium"),
		    Na.meq = conc2meq(Sodium, "sodium"),
		    Cl.meq = conc2meq(Chloride, "chloride"),
		    SO4.meq = conc2meq(Sulfate, "sulfate"),
		    HCO3.meq = conc2meq(Bicarbonate, "bicarb")) # abbreviations allowed
# The row name identifies the sample source, create a column
PD$SS <- row.names(PD)
# setSweave is a specialized function that sets up the graphics page for
# Sweave scripts. It should be replaced by a call to setPage or setPDF 
# in a regular script.
# The minimum page size for a Piper plot is 7 inches. No check is made,
#  but the axis title spacings require a graph area of at least 6 inches.
setSweave("piperplot01", 7, 7)
# For this example, a separate graph area for an explanation is not needed
#  because there are only 2 groups.
AA.pl <- with(PD, piperPlot(Ca.meq, Mg.meq, Na.meq, 
	               Cl.meq, HCO3.meq, SO4.meq,
		       Plot=list(name=SS, color=setColor(SS)),
		       zCat.title = "Sodium",
		       xAn.title = "Chloride",
		       yAn.title = "Bicarbonate"))
addExplanation(AA.pl, where="ul", title="")
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 3: PiperPlot.Rnw:80-82
###################################################
cat("\\includegraphics{piperplot01.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 4: PiperPlot.Rnw:94-99
###################################################
setSweave("piperplot02", 6, 6)
# Accept all defaults
ternaryPlot(X, Y, Z)
# Required call to close PDF output graphics 
graphics.off() 


###################################################
### code chunk number 5: PiperPlot.Rnw:101-103
###################################################
cat("\\includegraphics{piperplot02.pdf}\n")
cat("\\paragraph{}\n") 


###################################################
### code chunk number 6: PiperPlot.Rnw:114-124
###################################################
setSweave("piperplot03", 6, 6)
AA.lo <- setLayout(height=3.5, explanation=list(bottom=1.1))
setGraph(1, AA.lo)
# Accept all defaults, but subset the data for the small graph size
AA.pl <- with(PD, stiffPlot(cbind(Ca.meq, Mg.meq, Na.meq),
         cbind(Cl.meq, SO4.meq, HCO3.meq), ylabels=SS))
setGraph("explanation", AA.lo)
addExplanation(AA.pl)
# Required call to close PDF output graphics 
graphics.off() 


###################################################
### code chunk number 7: PiperPlot.Rnw:126-128
###################################################
cat("\\includegraphics{piperplot03.pdf}\n")
cat("\\paragraph{}\n") 


