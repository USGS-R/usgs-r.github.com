## ----openLibrary, echo=FALSE------------------------------
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)

## ----include=TRUE ,echo=FALSE,eval=TRUE-------------------
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, tidy=FALSE,comment="")
knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)

## ----workflow, echo=TRUE,eval=TRUE------------------------
library(EflowStats)

############################################
# Load sample data included with package:
daily_data<-dailyData


## ----USGSstatsinfo, echo=TRUE,eval=TRUE-------------------
############################################
# calculate stats for a USGS streamgage
sites <- c("02177000","02178400")
startdate <- "2009"
enddate <- "2013"
stats="magnifSeven,magStat,flowStat,durStat,timStat,rateStat,otherStat"

## ----createstatsoutput, echo=FALSE,eval=TRUE,results="hide"----
###############################################
# calculate stats for USGS streamgage(s)
statsout <- ObservedStatsUSGS(sites,startdate,enddate,stats)

## ----statsoutput, echo=TRUE,eval=FALSE--------------------
#  ###############################################
#  # calculate stats for USGS streamgage(s)
#  statsout <- ObservedStatsUSGS(sites,startdate,enddate,stats)

## ----viewData, echo=FALSE,eval=TRUE-----------------------
###############################################
# view a portion of the statsout table
statsout[,c(1,4:8,10)]

## ----saveData, echo=TRUE,eval=FALSE-----------------------
#  # save statsout to a tab-delimited file
#  output = "output.txt"
#  write.table(statsout, file = output, col.names = TRUE, row.names = FALSE,
#              quote = FALSE, sep = "\t")

## ----OtherStats, echo=TRUE,eval=FALSE---------------------
#  #############################################################
#  # calculate stats for data from your own data file
#  drain_area=54
#  site_id="Test site"
#  daily_data<-dailyData
#  stats="magnifSeven,magStat,flowStat,durStat,timStat,rateStat,otherStat"
#  statsout <- ObservedStatsOther(daily_data,drain_area,site_id,stats)

## ----OtherStatsMulti, echo=TRUE,eval=FALSE----------------
#  ###############################################################
#  # calculate stats for multiple sites in a local data directory
#  dataPath="C:/Users/jlthomps/Documents/R/JData/modeled/"
#  stats="magnifSeven,magStat,flowStat,durStat,timStat,rateStat,otherStat"
#  statsout <- ObservedStatsOtherMulti(dataPath,stats)

## ----plotMonthlyMeans, echo=TRUE,fig.cap="Monthly Average Flow at station 02178400"----
# plot monthly means for a daily discharge timeseries
qfiletempf<-sampleData
meanmonts<-monthlyMeanTs(qfiletempf)
plotMonthlyMean(meanmonts,'02178400')

## ----CompareStatsNWISlocal, echo=TRUE,eval=FALSE----------
#  #######################################################################
#  # NWIS-local
#  sites <- c("02186000","02192000","02219000","02317500","02329600")
#  startDt <- "1990"
#  endDt <- "1999"
#  stats="magnifSeven,magStat,flowStat,durStat,timStat,rateStat,otherStat"
#  dataPath="C:/Users/jlthomps/Documents/R/JData/modeled/"
#  DiffStats <- CompareStats(stats,sites=sites,dataPath=dataPath,startDt=startDt,endDt=endDt)
#  stats1 <- DiffStats[[1]]
#  stats2 <- DiffStats[[2]]
#  Diffstats <- DiffStats[[3]]
#  RegGoFstats <- DiffStats[[4]]
#  GoFstats <- DiffStats[[5]]

## ----CompareStatsNWISNWIS, echo=TRUE,eval=FALSE-----------
#  ########################################################################
#  # NWIS-NWIS
#  sites <- c("02186000","02192000","02219000","02317500","02329600")
#  startDt <- "1990"
#  endDt <- "1999"
#  startDt2 <- "2000"
#  endDt2 <- "2008"
#  stats="magnifSeven,magStat,flowStat,durStat,timStat,rateStat,otherStat"
#  DiffStats <- CompareStats(stats,sites=sites,startDt=startDt,endDt=endDt,startDt2=startDt2,endDt2=endDt2)

## ----CompareStatslocallocal, echo=TRUE,eval=FALSE---------
#  #############################################################################
#  # local-local
#  stats="magnifSeven,magStat,flowStat,durStat,timStat,rateStat,otherStat"
#  dataPath="C:/Users/jlthomps/Documents/R/JData/modeled/"
#  dataPath2="C:/Users/jlthomps/Documents/R/JData/observed/"
#  DiffStats <- CompareStats(stats,dataPath=dataPath,dataPath2=dataPath2)

## ----helpFunc,eval = FALSE--------------------------------
#  library(EflowStats)
#  ?mh19

## ----rawFunc,eval = TRUE----------------------------------
mh19

## ----installFromCran,eval = FALSE-------------------------
#  install.packages(c("zoo","chron","doBy","XML","hydroGOF","lmomco","RCurl"))
#  install.packages("EflowStats",repos="http://usgs-r.github.com",type="source")

## ----openLibraryTest, eval=FALSE--------------------------
#  library(EflowStats)

