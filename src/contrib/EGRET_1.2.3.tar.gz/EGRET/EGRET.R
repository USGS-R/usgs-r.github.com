### R code from vignette source 'C:/Users/ldecicco/Documents/R/win-library/2.15/EGRET/doc/EGRET.Rnw'

###################################################
### code chunk number 1: openLibrary
###################################################
library(xtable)
options(continue=" ")
options(width=60)
options(SweaveHooks=list(fig=function()
  par(mar=c(5.1,4.1,1.1,2.1),oma=c(0,0,0,0))))


###################################################
### code chunk number 2: openlibraries
###################################################
library(dataRetrieval)
library(EGRET)


###################################################
### code chunk number 3: colNamesDaily
###################################################
ColumnName <- c("Date", "Q", "Julian","Month","Day","DecYear","MonthSeq","Qualifier","i","LogQ","Q7","Q30")
Type <- c("Date", "number", "number","integer","integer","number","integer","string","integer","number","number","number")
Description <- c("Date", "Discharge in cms", "Number of days since January 1, 1850", "Month of the year [1-12]", "Day of the year [1-366]", "Decimal year", "Number of months since January 1, 1850", "Qualifing code", "Index", "Natural logarithm of Q", "7 day running average of Q", "30 running average of Q")
Units <- c("date", "cms","days", "months","days","years","months", "character","days","numeric","cms","cms")

DF <- data.frame(ColumnName,Type,Description,Units)

data.table <- xtable(DF, caption="Daily dataframe",label="table:Daily1")
print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 4: colNamesDaily2
###################################################
ColumnName <- c("yHat", "SE", "ConcDay","FluxDay","FNConc","FNFlux")
Type <- c("number", "number", "number","number","number","number")
Description <- c("The WRTDS estimate of the log of concentration", "The WRTDS estimate of the standard error of yHat","The WRTDS estimate of concentration", "The WRTDS estimate of flux","Flow normalized estimate of concentration", "Flow Normalized estimate of flux")
Units <- c("numeric","numeric","mg/L","kg/day","mg/L","kg/day")

DF <- data.frame(ColumnName,Type,Description,Units)

data.table <- xtable(DF, caption="Daily dataframe, post-WRTDS",label="table:Daily2")
print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 5: colNamesQW
###################################################
ColumnName <- c("Date", "ConcLow", "ConcHigh", "Uncen", "ConcAve", "Julian","Month","Day","DecYear","MonthSeq","SinDY","CosDY","Q footnote","LogQ footnote")
Type <- c("Date", "number","number","integer","number", "number","integer","integer","number","integer","number","number","number","number")
Description <- c("Date", "Lower limit of concentration", "Upper limit of concentration", "Uncensored data (1=true, 0=false)", "Average concentration","Number of days since January 1, 1850", "Month of the year [1-12]", "Day of the year [1-366]", "Decimal year", "Number of months since January 1, 1850", "Sine of DecYear", "Cosine of DecYear", "Discharge", "Natural logarithm of flow")
Units <- c("date","mg/L","mg/L","integer","mg/L","days","months","days","years","months","numeric","numeric","cms", "numeric")

DF <- data.frame(ColumnName,Type,Description, Units)

data.table <- xtable(DF, caption="Sample dataframe", label="table:Sample1")
print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht",
      sanitize.text.function=function(str)gsub("footnote","\\footnotemark[1]",str,fixed=TRUE))


###################################################
### code chunk number 6: colNamesSample2
###################################################
ColumnName <- c("yHat", "SE", "ConcHat")
Type <- c("number", "number", "number")
Description <- c("jack-knife estimate of the log of concentration", "jack-knife estimate of the standard error of yHat","jack-knife unbiased estimate of concentration")
Units <- c("numeric","numeric","mg/L")

DF <- data.frame(ColumnName,Type,Description,Units)

data.table <- xtable(DF, caption="Sample dataframe, post-WRTDS", label="table:Sample2")
print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 7: colNamesINFO2
###################################################
ColumnName <- c("bottomLogQ","stepLogQ","nVectorLogQ","bottomYear","stepYear","nVectorYear","windowY","windowQ","windowS","minNumObs","minNumUncen")
Description <- c("Lowest discharge in prediction surfaces","Step size in discharge in prediction surfaces","Number of steps in discharge, prediction surfaces","Starting year in prediction surfaces","Step size in years in prediction surfaces","Number of steps in years in prediction surfaces","Half-window width in the time dimension","Half-window width in the log discharge dimension","Half-window width in the seasonal dimension","Minimum number of observations for regression", "Minimum number of uncensored observations")
Units <- c("numeric","numeric","numeric","numeric","numeric","numeric","years","numeric","years","integer","integer")

DF <- data.frame(ColumnName,Description,Units)

data.table <- xtable(DF, caption="INFO dataframe, post-WRTDS", label="table:Info2")
print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 8: cheatSheets
###################################################
printqUnitCheatSheet()


###################################################
### code chunk number 9: cheatSheets2
###################################################
printFluxUnitCheatSheet()


###################################################
### code chunk number 10: vignette1 (eval = FALSE)
###################################################
## vignette("dataRetrieval")


###################################################
### code chunk number 11: flowHistory
###################################################
#Rio Grande at Embudo, NM
siteID <- "08279500"  
startDate <- ""
endDate <- ""

Daily <- getDVData(siteID,"00060",startDate,endDate,interactive=FALSE)
INFO <- getMetaData(siteID,"",interactive=FALSE)
INFO$shortName <- "Rio Grande at Embudo, NM"


###################################################
### code chunk number 12: paINFO
###################################################
PeriodOfAnalysis <- c("Calendar Year", "Water Year", "Winter", "September")
paStart <- c("1","10","12","9")
PaLong <- c("12","12","3","1")

DF <- data.frame(PeriodOfAnalysis,paStart,PaLong)

data.table <- xtable(DF, caption="Period of Analysis Information",label="table:paINFO")
print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 13: newChunckWinter (eval = FALSE)
###################################################
## INFO <- setPA(paStart=12,paLong=3)


###################################################
### code chunk number 14: newChunck
###################################################
INFO <- setPA()


###################################################
### code chunk number 15: istat
###################################################
istat <- c("1", "2", "3", "4","5","6","7","8")
Name <- c("1-day minimum flow","7-day minimum flow","30-day minimum flow","median flow","mean flow","30-day maximum flow", "7-day maximum flow", "1-day maximum flow")

DF <- data.frame(istat,Name)

data.table <- xtable(DF,  caption="Index of Statistics Information",label= "table:istat")

print(data.table, caption.placement="top", include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 16: newChunckAS
###################################################
annualSeries <- makeAnnualSeries()


###################################################
### code chunk number 17: plotFlow (eval = FALSE)
###################################################
## Daily <- getDVData(siteID,"00060",startDate,endDate,interactive=FALSE)
## INFO <- getMetaData(siteID,"",interactive=FALSE)
## INFO$shortName <- "Rio Grande at Embudo, NM"
## INFO <- setPA()
## annualSeries <- makeAnnualSeries()
## # plotFlowSingle(istat=5,qUnit=3)
## #identical to:
## plotFlowSingle(istat=7,qUnit="thousandCfs")
## plotSDLogQ()
## plotQTimeDaily(1990,2010,qLower=1,qUnit=3)
## plotFour(qUnit=3)
## plotFourStats(qUnit=3)


###################################################
### code chunk number 18: plotFlowSingle
###################################################
annualSeries <- makeAnnualSeries()
plotFlowSingle(istat=7,qUnit="thousandCfs")


###################################################
### code chunk number 19: figplotFlowSingle
###################################################
annualSeries <- makeAnnualSeries()
plotFlowSingle(istat=7,qUnit="thousandCfs")


###################################################
### code chunk number 20: plotSDLogQ
###################################################
plotSDLogQ()


###################################################
### code chunk number 21: figplotSDLogQ
###################################################
plotSDLogQ()


###################################################
### code chunk number 22: plotQTimeDaily
###################################################
plotQTimeDaily(1990,2010,qLower=2,qUnit=3)


###################################################
### code chunk number 23: figplotQTimeDaily
###################################################
plotQTimeDaily(1990,2010,qLower=2,qUnit=3)


###################################################
### code chunk number 24: plotFour
###################################################
annualSeries <- makeAnnualSeries()
plotFour(qUnit=3)


###################################################
### code chunk number 25: figplotFour
###################################################
annualSeries <- makeAnnualSeries()
plotFour(qUnit=3)


###################################################
### code chunk number 26: plotFourStats
###################################################
plotFourStats(qUnit=3)


###################################################
### code chunk number 27: figplotFourStats
###################################################
plotFourStats(qUnit=3)


###################################################
### code chunk number 28: plotSDRed
###################################################
siteID <- "05082500"
DailyRed <- getDVData(siteID,"00060","","",interactive=FALSE)
INFORed <- getMetaData(siteID,"",interactive=FALSE)
INFORed$shortName <- "Red River, ND"
INFORed <- setPA(paStart=6, paLong=3,localINFO = INFORed)
plotSDLogQ(localDaily = DailyRed, localINFO = INFORed, printStaName = FALSE)


###################################################
### code chunk number 29: fig3a
###################################################
siteID <- "05082500"
DailyRed <- getDVData(siteID,"00060","","",interactive=FALSE)
INFORed <- getMetaData(siteID,"",interactive=FALSE)
INFORed$shortName <- "Red River, ND"
INFORed <- setPA(paStart=6, paLong=3,localINFO = INFORed)
plotSDLogQ(localDaily = DailyRed, localINFO = INFORed, printStaName = FALSE)


###################################################
### code chunk number 30: plotSDRed2
###################################################
INFORed <- setPA(paStart=3, paLong=3)
plotSDLogQ(localDaily = DailyRed, localINFO = INFORed,printStaName = FALSE)


###################################################
### code chunk number 31: fig3b
###################################################
INFORed <- setPA(paStart=3, paLong=3)
plotSDLogQ(localDaily = DailyRed, localINFO = INFORed,printStaName = FALSE)


###################################################
### code chunk number 32: printSeries (eval = FALSE)
###################################################
## printSeries(istat=3, qUnit=3)


###################################################
### code chunk number 33: printSeries
###################################################
annualSeries <- makeAnnualSeries()
tableFlowChange(istat=3, qUnit=3,yearPoints=c(1930,1950,1970,1990,2010))


###################################################
### code chunk number 34: wrtds1
###################################################
siteID <- "01491000" #Choptank River at Greensboro, MD
startDate <- "1979-10-01"
endDate <- "2011-09-30"
param<-"00631"
Daily <- getDVData(siteID,"00060",startDate,endDate)
INFO<- getMetaData(siteID,param,interactive=FALSE)
INFO$shortName <- "Choptank River"
Sample <- getSampleData(siteID,param,startDate,endDate)
Sample <- mergeReport()


###################################################
### code chunk number 35: plotList (eval = FALSE)
###################################################
## boxConcMonth()
## boxQTwice()
## plotLogConcTime()
## plotConcTime()
## plotConcQ()
## plotLogConcQ()
## plotLogFluxQ()
## multiPlotDataOverview()


###################################################
### code chunk number 36: boxConcMonth
###################################################
boxConcMonth()


###################################################
### code chunk number 37: figboxConcMonth
###################################################
boxConcMonth()


###################################################
### code chunk number 38: boxQTwice
###################################################
boxQTwice()


###################################################
### code chunk number 39: figboxQTwice
###################################################
boxQTwice()


###################################################
### code chunk number 40: plotConcTime
###################################################
plotConcTime()


###################################################
### code chunk number 41: figplotConcTime
###################################################
plotConcTime()


###################################################
### code chunk number 42: plotLogConcTime
###################################################
plotLogConcTime()


###################################################
### code chunk number 43: figplotLogConcTime
###################################################
plotLogConcTime()


###################################################
### code chunk number 44: plotConcQ
###################################################
plotConcQ()


###################################################
### code chunk number 45: figplotConcQ
###################################################
plotConcQ()


###################################################
### code chunk number 46: plotLogConcQ
###################################################
plotLogConcQ()


###################################################
### code chunk number 47: figplotLogConcQ
###################################################
plotLogConcQ()


###################################################
### code chunk number 48: plotLogFluxQ
###################################################
plotLogFluxQ()


###################################################
### code chunk number 49: figplotLogFluxQ
###################################################
plotLogFluxQ()


###################################################
### code chunk number 50: multiPlotDataOverview
###################################################
multiPlotDataOverview()


###################################################
### code chunk number 51: figmultiPlotDataOverview
###################################################
multiPlotDataOverview()


###################################################
### code chunk number 52: flowDuration
###################################################
flowDuration()


###################################################
### code chunk number 53: wrtds2 (eval = FALSE)
###################################################
## modelEstimation()


###################################################
### code chunk number 54: wrtds3 (eval = FALSE)
###################################################
## AnnualResults<-setupYears()


###################################################
### code chunk number 55: wrtds4 (eval = FALSE)
###################################################
## savePath <- "C:/Users/ldecicco/WRTDS_Output"
## saveResults(savePath) 


###################################################
### code chunk number 56: plotWRTDSList (eval = FALSE)
###################################################
## #All plotting functions post-modelEstimation:
## 
## yearStart <- 2008
## yearEnd <- 2010
## 
## #Require Sample + INFO:
## boxResidMonth()
## plotConcTimeDaily(yearStart, yearEnd)
## plotFluxTimeDaily(yearStart, yearEnd)
## plotConcPred()
## plotFluxPred()
## plotLogConcPred()
## plotLogFluxPred()
## plotResidPred()
## plotResidQ()
## plotResidTime()
## fluxBiasMulti()
## 
## #Require annualResults + INFO:
## AnnualResults <- setupYears()
## plotConcHist()
## plotFluxHist()
## 
## #Contour plots:
## qBottom<-0.1
## qTop<-100
## clevel<-seq(0,2,0.5)
## maxDiff<-0.8
## plotContours(yearStart,yearEnd,qBottom,qTop, contourLevels = clevel)
## plotDiffContours(year0=2000,yearEnd,qBottom,qTop,maxDiff)
## 
## # Multi-line plots:
## date1 <- "2000-09-01"
## date2 <- "2005-09-01"
## date3 <- "2009-09-01"
## plotLogConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2, concMin=0.1)
## plotConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2)
## 
## q1 <- 10
## q2 <- 25
## q3 <- 75
## centerDate <- "07-01"
## plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)


###################################################
### code chunk number 57: boxResidMonth
###################################################
Sample <- exSample
Daily <- exDaily
INFO <- exINFO
AnnualResults <- setupYears()
surfaces <- exsurfaces
qBottom<-0.1
qTop<-100
clevel<-seq(0,2,0.5)
maxDiff<-0.8
yearStart <- 2008
yearEnd <- 2010
date1 <- "2000-09-01"
date2 <- "2005-09-01"
date3 <- "2009-09-01"
q1 <- 10
q2 <- 25
q3 <- 75
centerDate <- "07-01"
boxResidMonth()


###################################################
### code chunk number 58: figboxResidMonth
###################################################
Sample <- exSample
Daily <- exDaily
INFO <- exINFO
AnnualResults <- setupYears()
surfaces <- exsurfaces
qBottom<-0.1
qTop<-100
clevel<-seq(0,2,0.5)
maxDiff<-0.8
yearStart <- 2008
yearEnd <- 2010
date1 <- "2000-09-01"
date2 <- "2005-09-01"
date3 <- "2009-09-01"
q1 <- 10
q2 <- 25
q3 <- 75
centerDate <- "07-01"
boxResidMonth()


###################################################
### code chunk number 59: plotConcTimeDaily
###################################################
plotConcTimeDaily(yearStart,yearEnd)


###################################################
### code chunk number 60: figplotConcTimeDaily
###################################################
plotConcTimeDaily(yearStart,yearEnd)


###################################################
### code chunk number 61: plotFluxTimeDaily
###################################################
plotFluxTimeDaily(yearStart, yearEnd)


###################################################
### code chunk number 62: figplotFluxTimeDaily
###################################################
plotFluxTimeDaily(yearStart, yearEnd)


###################################################
### code chunk number 63: plotConcPred
###################################################
plotConcPred()


###################################################
### code chunk number 64: figplotConcPred
###################################################
plotConcPred()


###################################################
### code chunk number 65: plotFluxPred
###################################################
plotFluxPred()


###################################################
### code chunk number 66: figplotFluxPred
###################################################
plotFluxPred()


###################################################
### code chunk number 67: plotLogConcPred
###################################################
plotLogConcPred()


###################################################
### code chunk number 68: figplotLogConcPred
###################################################
plotLogConcPred()


###################################################
### code chunk number 69: plotLogFluxPred
###################################################
plotLogFluxPred()


###################################################
### code chunk number 70: figplotLogFluxPred
###################################################
plotLogFluxPred()


###################################################
### code chunk number 71: plotResidPred
###################################################
plotResidPred()


###################################################
### code chunk number 72: figplotResidPred
###################################################
plotResidPred()


###################################################
### code chunk number 73: plotResidQ
###################################################
plotResidQ()


###################################################
### code chunk number 74: figplotResidQ
###################################################
plotResidQ()


###################################################
### code chunk number 75: plotResidTime
###################################################
plotResidTime()


###################################################
### code chunk number 76: figplotResidTime
###################################################
plotResidTime()


###################################################
### code chunk number 77: fluxBiasMulti
###################################################
fluxBiasMulti()


###################################################
### code chunk number 78: figfluxBiasMulti
###################################################
fluxBiasMulti()


###################################################
### code chunk number 79: plotConcHist
###################################################
plotConcHist()


###################################################
### code chunk number 80: figplotConcHist
###################################################
plotConcHist()


###################################################
### code chunk number 81: plotFluxHist
###################################################
plotFluxHist()


###################################################
### code chunk number 82: figplotFluxHist
###################################################
plotFluxHist()


###################################################
### code chunk number 83: plotContours
###################################################
plotContours(yearStart,yearEnd,qBottom,qTop)


###################################################
### code chunk number 84: figplotContours
###################################################
plotContours(yearStart,yearEnd,qBottom,qTop)


###################################################
### code chunk number 85: plotDiffContours
###################################################
plotDiffContours(year0=2000,yearEnd,qBottom,qTop,maxDiff)


###################################################
### code chunk number 86: figplotDiffContours
###################################################
plotDiffContours(year0=2000,yearEnd,qBottom,qTop,maxDiff)


###################################################
### code chunk number 87: plotConcQSmooth
###################################################
plotConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2)


###################################################
### code chunk number 88: figplotConcQSmooth
###################################################
plotConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2)


###################################################
### code chunk number 89: plotLogConcQSmooth
###################################################
plotLogConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2, concMin=0.1)


###################################################
### code chunk number 90: figplotLogConcQSmooth
###################################################
plotLogConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2, concMin=0.1)


###################################################
### code chunk number 91: plotConcTimeSmooth
###################################################
plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)


###################################################
### code chunk number 92: figplotConcTimeSmooth
###################################################
plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)


###################################################
### code chunk number 93: tableResults1
###################################################
tableResults()


###################################################
### code chunk number 94: tableResults1 (eval = FALSE)
###################################################
## tableOut <- tableResults(returnDataFrame = TRUE)
## 
## data.table <- xtable(tableOut, caption="Table created from tableResults function",label="table:tableResults")
## print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 95: tableChange1
###################################################
tableChange()


###################################################
### code chunk number 96: tableChange2 (eval = FALSE)
###################################################
## changeOutput <- tableChangeSingle(fluxUnit=3, flux=TRUE,
##         yearPoints=c(2002,2004,2006), returnDataFrame = TRUE)
## 
## data.table <- xtable(changeOutput, caption="Table created from tableChangeSingle function",label="table:tableChangeSingle")
## print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 97: helpFunc (eval = FALSE)
###################################################
## ?getJulian


###################################################
### code chunk number 98: rawFunc
###################################################
getJulian


###################################################
### code chunk number 99: installFromCran (eval = FALSE)
###################################################
## install.packages(c("zoo","survival","methods","fields","spam"))
## install.packages("dataRetrieval", repos="http://usgs-r.github.com/", 
##                  type="source")
## install.packages("EGRET", repos="http://usgs-r.github.com/", 
##                  type="source")


###################################################
### code chunk number 100: openLibraryTest (eval = FALSE)
###################################################
## library(dataRetrieval)
## library(EGRET)


###################################################
### code chunk number 101: gitInstal (eval = FALSE)
###################################################
## library(devtools)
## install_github("dataRetrieval", "USGS-R")
## install_github("EGRET", "USGS-R")


###################################################
### code chunk number 102: openLibrary (eval = FALSE)
###################################################
## library(dataRetrieval)
## library(EGRET)


