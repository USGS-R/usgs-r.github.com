# Normal workflow:
library(GLRIRegression)
library(dataRetrieval)

siteTable <- siteTable

AustinList <- c("00940","00608","00613","00631","62855","00671","00665","80154","00618")

for (i in siteTable$shortName[c(-16)]){
  cat(i, "\n")
  
  pathToSave <- paste("M:/QW Monitoring Team/GLRI Nutrients/GLRI nutrients/Regressions/DataForModels2/",i,sep="")
  dir.create(file.path(pathToSave), showWarnings = FALSE)
  
  siteID <- siteTable$siteID[which(siteTable$shortName == i)]
  siteINFO <-  getSiteFileData(siteID, interactive=FALSE)
  UVcodes <- whatUVNew(siteID)
  
  QWcodes <- whatQW(siteID, minCount=20, endDate="2012-06-01",ignoreGroups="Information")
  QWcodes <- QWcodes[which(QWcodes$parameter_cd %in% AustinList),]
  
  UVPList <- c("00010", "00060", "00095", "00400", "63680", "00300")
  UVP <- unique(UVcodes$parameter_cd[which(UVcodes$parameter_cd %in% UVPList)])
  
  #   BeginDate <- max(UVcodes$StartDate[which(UVcodes$pCode %in% UVP)])
  #   BeginDate <- max(availableData$startDate[which(availableData$parameter_cd %in% UVP)])
  BeginDate <- "2011-02-01"
  QW <- importNWISqw(siteID, params=AustinList, begin.date=BeginDate)
  QW$datetime <- as.POSIXct(paste(QW$sample_dt," ",QW$sample_tm, ":00",sep=""),tz="UTC")
  
  possibleError <- tryCatch(
    UV <- getMultipleUV(siteID, "2011-02-01", UVP),
    error=function(e) e
  )
  
  if(!inherits(possibleError, "error")){
    #REAL WORK
    mergeReturn <- mergeDatasets(QW, UV, QWcodes)
    DTComplete <- mergeReturn$DTComplete
    QWcodes <- mergeReturn$QWcodes
    
    save(QW,file=paste(pathToSave,"QW.RData",sep="/"))
    save(UV,file=paste(pathToSave,"UV.RData",sep="/"))
    save(QWcodes,file=paste(pathToSave,"QWcodes.RData",sep="/"))
    save(DTComplete,file=paste(pathToSave,"DTComplete.RData",sep="/"))
    save(siteINFO,file=paste(pathToSave,"siteINFO.RData",sep="/"))
    write.csv(UV, file=paste(pathToSave,"UV.csv",sep="/"))
    
    for (j in QWcodes$colName){
      pathToSaveNew <- paste(pathToSave,j,sep="/")
      dir.create(file.path(pathToSaveNew), showWarnings = FALSE)   
      
      transformResponse <- "lognormal"
      DT <- DTComplete[c(j,getPredictVariables(names(UV)), "decYear","sinDY","cosDY","datetime")]
      DT <- na.omit(DT)
      
      pdf(paste(pathToSaveNew,"/",j,"_InitialQQGraphs.pdf",sep=""))
      plotQQTransforms(DT,j)
      predictVariableScatterPlots(DT,j)
      dev.off()
      
      predictVariables <- names(DT)[-which(names(DT) %in% j)]
      predictVariables <- predictVariables[which(predictVariables != "datetime")]
      
      kitchenSink <- createFullFormula(DT,j)
      
      returnPrelim <- prelimModelDev(DT,j,kitchenSink,
                                     "AIC", #Other option is "BIC"
                                     transformResponse)
      
      steps <- returnPrelim$steps
      modelResult <- returnPrelim$modelStuff
      modelReturn <- returnPrelim$DT.mod
      
      if(nrow(steps) > 1){ 
        #Save plotSteps to file:
        pdf(paste(pathToSaveNew,"/",j,"_plotSteps.pdf",sep=""))
        plotSteps(steps,DT,transformResponse)
        dev.off()
        
        pdf(paste(pathToSaveNew,"/",j,"_analyzeSteps.pdf",sep=""))
        analyzeSteps(steps, j, siteINFO, xCorner = 0.01)
        dev.off()
        
        choices <- generateParamChoices(predictVariables,modelReturn,pathToSaveNew,save=TRUE)
        
        pdf(paste(pathToSaveNew,"/",j,"_summaryPlots.pdf",sep=""), paper="a4r", width=10.5)
        resultPlots(DT,modelReturn,siteINFO)
        dev.off()
        
        pdf(paste(pathToSaveNew,"/",j,"_summaryResidPlots.pdf",sep=""), paper="a4r", width=10.5)
        resultResidPlots(DT,modelReturn,siteINFO)
        dev.off()
        
        pdf(paste(pathToSaveNew,"/",j,"_prediction.pdf",sep=""))
        possibleError <- tryCatch(
          predictionPlot(UV,DT,modelReturn,transformResponse,siteINFO),
          error=function(e) e
        )
        
        if(!inherits(possibleError, "error")){
          #REAL WORK
        } else {
          plot(1:10)
        }
        dev.off()
        
        fileName <- paste(pathToSaveNew,"/", j,"Summary.txt", sep="")
        summaryPrintout(modelReturn, siteINFO, saveOutput=TRUE,fileName)
      }
      
      #######################################
      pathToSaveNewNoWQ <- paste(pathToSave,j,"withoutWQ",sep="/")
      dir.create(file.path(pathToSaveNewNoWQ), showWarnings = FALSE)
      
      transformResponse <- "lognormal"
      DT <- DTComplete[c(j,"Flow", "decYear","sinDY","cosDY","datetime")]
      DT <- na.omit(DT)
      
      predictVariables <- names(DT)[-which(names(DT) %in% j)]
      predictVariables <- predictVariables[which(predictVariables != "datetime")]
      
      kitchenSink <- createFullFormula(DT,j)
      
      returnPrelim <- prelimModelDev(DT,j,kitchenSink,
                                     "AIC", #Other option is "BIC"
                                     transformResponse)
      
      steps <- returnPrelim$steps
      modelResult <- returnPrelim$modelStuff
      modelReturn <- returnPrelim$DT.mod
      
      if(nrow(steps) > 1){      
        #Save plotSteps to file:
        pdf(paste(pathToSaveNewNoWQ,"/",j,"_plotSteps.pdf",sep=""))
        plotSteps(steps,DT,transformResponse)
        dev.off()
        
        pdf(paste(pathToSaveNewNoWQ,"/",j,"_analyzeSteps.pdf",sep=""))
        analyzeSteps(steps, j, siteINFO, xCorner = 0.01)
        dev.off()
      
      
        choices <- generateParamChoices(predictVariables,modelReturn,pathToSaveNewNoWQ,save=TRUE)
        
        pdf(paste(pathToSaveNewNoWQ,"/",j,"_summaryPlots.pdf",sep=""), paper="a4r", width=10.5)
        resultPlots(DT,modelReturn,siteINFO)
        dev.off()
        
        pdf(paste(pathToSaveNewNoWQ,"/",j,"_summaryPlotsResid.pdf",sep=""), paper="a4r", width=10.5)
        resultResidPlots(DT,modelReturn,siteINFO)
        dev.off()
        
        pdf(paste(pathToSaveNewNoWQ,"/",j,"_prediction.pdf",sep=""))
        possibleError <- tryCatch(
          predictionPlot(UV,DT,modelReturn,transformResponse,siteINFO),
          error=function(e) e
        )
        
        if(!inherits(possibleError, "error")){
          #REAL WORK
        } else {
          plot(1:10)
        }
        dev.off()
        
        fileName <- paste(pathToSaveNewNoWQ,"/", j,"Summary.txt", sep="")
        summaryPrintout(modelReturn, siteINFO, saveOutput=TRUE,fileName)
      #########################################
      }
    }
    
  }

}


##############################################################################
for (i in siteTable$shortName[c(-1:-30)]){
  cat(i, "\n")
  
  pathToSave <- paste("M:/QW Monitoring Team/GLRI Nutrients/GLRI nutrients/Regressions/DataForModels2/",i,sep="")
  load(paste(pathToSave,"QW.RData",sep="/"))
  load(paste(pathToSave,"UV.RData",sep="/"))
  load(paste(pathToSave,"QWcodes.RData",sep="/"))
  load(paste(pathToSave,"siteINFO.RData",sep="/"))
  load(paste(pathToSave,"DTComplete.RData",sep="/"))

  
  for (j in QWcodes$colName){
    pathToSaveNew <- paste(pathToSave,j,sep="/")
    
    transformResponse <- "lognormal"
    DT <- DTComplete[c(j,getPredictVariables(names(UV)), "decYear","sinDY","cosDY","datetime")]
    DT <- na.omit(DT)
    
    pathToSaveOld <- paste("M:/QW Monitoring Team/GLRI Nutrients/GLRI nutrients/Regressions/DataForModels/",i,sep="")
    pathToParam <- paste(pathToSaveOld,"/",j,"/",j,"ModelParams.csv",sep="")
    choicesNew <- read.csv(pathToParam)
    newFormula <-createFormulaFromDF(choicesNew)
    
    modelReturn <- censReg(paste(j," ~ ", newFormula, sep=""), dist=transformResponse, data=DT)
    
    
    pdf(paste(pathToSaveNew,"/",j,"_summaryPlotsWithOldChoices.pdf",sep=""), paper="a4r", width=10.5)
    resultPlots(DT,modelReturn,siteINFO)
    dev.off()
    
    pdf(paste(pathToSaveNew,"/",j,"_summaryResidPlotsWithOldChoices.pdf",sep=""), paper="a4r", width=10.5)
    resultResidPlots(DT,modelReturn,siteINFO)
    dev.off()
    
    pdf(paste(pathToSaveNew,"/",j,"_predictionWithOldChoices.pdf",sep=""))
    possibleError <- tryCatch(
      predictionPlot(UV,DT,modelReturn,transformResponse,siteINFO),
      error=function(e) e
    )
    
    if(!inherits(possibleError, "error")){
      #REAL WORK
    } else {
      plot(1:10)
    }
    dev.off()
    
    fileName <- paste(pathToSaveNew,"/", j,"SummaryWithOldChoices.txt", sep="")
    summaryPrintout(modelReturn, siteINFO, saveOutput=TRUE,fileName)

    
  }
  
}






