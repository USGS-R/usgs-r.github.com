
## @knitr openLibrary, echo=FALSE
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)



## @knitr include=TRUE ,echo=FALSE,eval=TRUE
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, tidy=FALSE,comment="")
knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)


## @knitr start,eval = FALSE
## library(USGSwsQWSR)
## library(dataRetrieval)
## # Simple workflow
## site <- "04027000"
## siteName <- "Bad"
## siteINFO <-  getSiteFileData(site, interactive=FALSE)
## UVcodes <- whatUV(site)
## QWcodes <- whatQW(site, minCount=20, endDate="2012-06-01",ignoreGroups="Information")
## qwPCodes <- c("00940","00608","00613","00631","62855","00671","00665","80154","00618")
## QWcodes <- QWcodes[which(QWcodes$parameter_cd %in% qwPCodes),]
## uvPCodes <- c("00010", "00060", "00095", "00400", "63680", "00300")
## UVP <- unique(UVcodes$pCode[which(UVcodes$pCode %in% uvPCodes)])
## BeginDate <- max(UVcodes$StartDate[which(UVcodes$pCode %in% uvPCodes)])
## 
## QW <- importNWISqw(site, params=qwPCodes, begin.date=BeginDate)
## QW$datetime <- as.POSIXct(paste(QW$sample_dt," ",QW$sample_tm, ":00",sep=""),tz="UTC")
## 
## 
## UV <- getMultipleUV(site, BeginDate, UVP)
## 
## mergeReturn <- mergeDatasets(QW, UV, QWcodes)
## DTComplete <- mergeReturn$DTComplete
## QWcodes <- mergeReturn$QWcodes
## 


## @knitr helpFunc,eval = FALSE
## library(USGSwsQWSR)
## ?plotSteps


## @knitr rawFunc,eval = FALSE
## plotSteps


## @knitr installFromCran,eval = FALSE
## install.packages(c("XML", "lubridate", "akima",
##                    "leaps", "car", "mvtnorm",
##                    "relimp", "BSDA", "RODBC"),
##                  dependencies=TRUE)
## install.packages(c("USGSwsBase","USGSwsData",
##                    "USGSwsGraphs","USGSwsStats",
##                    "USGSwsQW"), repos="http://usgs-r.github.com")


## @knitr openLibraryTest, eval=FALSE
## library(USGSwsQWSR)


