
## ----openLibrary, echo=FALSE---------------------------------------------
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)



## ----include=TRUE ,echo=FALSE,eval=TRUE----------------------------------
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, tidy=FALSE,comment="")
knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)


## ----start,eval = FALSE--------------------------------------------------
## library("USGSwsQWSR")
## 
## #Sample data included with package:
## DTComplete <- DTComplete
## UV <- UV
## QWcodes <- QWcodes
## siteINFO <- siteINFO
## 
## investigateResponse <- "SuspSed"
## transformResponse <- "lognormal"
## 
## DT <- DTComplete[c(investigateResponse,
##                    getPredictVariables(names(UV)),
##                    "decYear","sinDY","cosDY","datetime")]
## DT <- na.omit(DT)
## 
## 
## predictVariables <- names(DT)[-which(names(DT) %in% investigateResponse)]
## predictVariables <- predictVariables[which(predictVariables != "datetime")]
## predictVariables <- predictVariables[which(predictVariables != "decYear")]
## 
## #Check predictor variables
## predictVariableScatterPlots(DT,investigateResponse)
## 
## # Create 'kitchen sink' formula:
## kitchenSink <- createFullFormula(DT,investigateResponse)
## 
## #Run stepwise regression with "kitchen sink" as upper bound:
## returnPrelim <- prelimModelDev(DT,investigateResponse,kitchenSink,
##                                "BIC", #Other option is "AIC"
##                                transformResponse)
## 
## steps <- returnPrelim$steps
## modelResult <- returnPrelim$modelStuff
## modelReturn <- returnPrelim$DT.mod
## 
## # Analyze steps found:
## plotSteps(steps,DT,transformResponse)
## analyzeSteps(steps, investigateResponse,siteINFO)
## 
## # Analyze model produced from stepwise regression:
## resultPlots(DT,modelReturn,siteINFO)
## resultResidPlots(DT,modelReturn,siteINFO)
## 


## ----helpFunc,eval = FALSE-----------------------------------------------
## library(USGSwsQWSR)
## ?plotSteps


## ----rawFunc,eval = FALSE------------------------------------------------
## plotSteps


## ----installFromCran,eval = FALSE----------------------------------------
## install.packages(c("XML", "lubridate", "akima",
##                    "leaps", "car", "mvtnorm",
##                    "relimp", "BSDA", "RODBC"),
##                  dependencies=TRUE)
## install.packages(c("USGSwsBase","USGSwsData",
##                    "USGSwsGraphs","USGSwsStats",
##                    "USGSwsQW"), repos="http://usgs-r.github.com")


## ----openLibraryTest, eval=FALSE-----------------------------------------
## library(USGSwsQWSR)


