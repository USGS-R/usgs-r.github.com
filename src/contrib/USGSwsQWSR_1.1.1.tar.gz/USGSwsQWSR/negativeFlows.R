
siteTable <- siteTable

site <- "IndianaCanal"
# site <- "Clinton"
pathToSave <- paste("M:/QW Monitoring Team/GLRI Nutrients/GLRI nutrients/Regressions/DataForModels2/",site,sep="")

load(file=paste(pathToSave,"QW.RData",sep="/"))
load(file=paste(pathToSave,"UV.RData",sep="/"))
load(file=paste(pathToSave,"QWcodes.RData",sep="/"))
load(file=paste(pathToSave,"DTComplete.RData",sep="/"))
load(file=paste(pathToSave,"siteINFO.RData",sep="/"))

negativeFlows <- DTComplete[DTComplete$Flow <= 0 & !is.na(DTComplete$Flow),]

#This vector sets up moving back and forth from the flow that matched with the sample
increments <- as.vector(rbind(seq(1,1000), seq(-1,-1000)))

for(i in 1:nrow(negativeFlows)){

  #This finds the index of the nearest flow at the sample time
  index1 <- which(abs(UV$datetime-negativeFlows$datetime[i])==min(abs(UV$datetime-negativeFlows$datetime[i])))
  
  flowTemp <- 1
  j <- 1
  
  #Loops through the increments vector, stopping when the sum of the flows is greater than 1:
  while(flowTemp <= 1 & j < 2000){
    newIndex <- index1 + increments[j]
    flowToAdd <- UV$Flow[newIndex]
    flowToAdd <- ifelse(is.na(flowToAdd),0,flowToAdd)
    flowTemp <- flowTemp + flowToAdd
    j <- j + 1
  }

  negativeFlows$Flow2[i] <- flowTemp
  
}

transformResponse <- "lognormal"
DTComplete$Flow[DTComplete$Flow < 0 & !is.na(DTComplete$Flow)] <- negativeFlows$Flow2

for (j in QWcodes$colName){
  
  DT <- DTComplete[c(j,getPredictVariables(names(UV)), "decYear","sinDY","cosDY","datetime")]
  DT <- na.omit(DT)
  
  predictVariables <- names(DT)[-which(names(DT) %in% j)]
  predictVariables <- predictVariables[which(predictVariables != "datetime")]
  
  kitchenSink <- createFullFormula(DT,j)
  
  returnPrelim <- prelimModelDev(DT,j,kitchenSink,
                                 "BIC", 
                                 transformResponse)
  
  steps <- returnPrelim$steps
  modelResult <- returnPrelim$modelStuff
  modelReturn <- returnPrelim$DT.mod
}
