View <- function(x) {
  xn <- deparse(substitute(x))
  vf <- get("View", pos=3, mode="function")
  invisible(vf(format(x), title=xn))
}

library(dataRetrieval)
library(USGSwsQWSR)
# Data Retrieval:
# Only do this for a new site:
##########################
# Required Inputs:
siteTable <- siteTable
site <- siteTable$siteID[1]
# site <- "04193490"
# siteName <- "Maumee"
##########################

siteINFO <-  getSiteFileData(site, interactive=FALSE)
UVcodesLorenz <- whatUV(site)
UVcodesLaura <- getDataAvailability(site)
UVcodesLaura <- UVcodesLaura[UVcodesLaura$service == "uv",]

# The reported end date in NWIS must be later than the endDate in the function below or it filters it out 
#(so we aren't retrieving data that ended before the real-time sensors went on line):
QWcodes <- whatQW(site, minCount=20, endDate="2012-06-01",ignoreGroups="Information")
QWcodesLaura <- getDataAvailability(site)
QWcodesLaura <- QWcodesLaura[QWcodesLaura$service == "qw",]

# To output to csv a table of parameters for a given site
#fileToSave <- paste(pathToSave, "manitowocQW.csv",sep="/")
#write.table(QWcodes, fileToSave, row.names=FALSE, sep=",")

AustinList <- c("00940","00608","00613","00631","62855","00671","00665","80154","00618")
# AustinList <- c("00940","00530","00665","50468","31616")  #MMSD Realtime sites
QWcodes <- QWcodes[which(QWcodes$parameter_cd %in% AustinList),]


UVPList <- c("00010", "00060", "00095", "00400", "63680", "00300") # 63675 is an incorrect pcode
# UVPList <- c("00010", "00060", "00095", "63680", "00300")   #MMSD Realtime sites
UVP <- unique(UVcodesLaura$parameter_cd[which(UVcodesLaura$parameter_cd %in% UVPList)])

BeginDate <- max(UVcodesLaura$startDate[which(UVcodesLaura$parameter_cd %in% UVP)])
EndDate <- ""
QWLorenz <- importNWISqw(site, params=AustinList, begin.date=as.Date(BeginDate))
QWLorenz$datetime <- as.POSIXct(paste(QWLorenz$sample_dt," ",QWLorenz$sample_tm, ":00",sep=""),tz="UTC")

QWLauraRaw <- retrieveNWISqwData(site,AustinList,as.character(BeginDate),"",expanded=TRUE)
QWLaura <- makeQWObjects(QWLauraRaw)


library(rbenchmark)

res <- benchmark(retrieveNWISqwData(site,AustinList,"2010-01-01","",expanded=TRUE),
                 importNWISqw(site, params=AustinList, begin.date=as.Date("2010-01-01")), replications=2)

# UV not worth doing it seems. 
UVLorenz <- getMultipleUV(site, as.character(BeginDate), EndDate, UVP)
UVLaura <- getMultipleUVdataRetrieval(site, as.character(BeginDate), EndDate, UVP)

res2 <- benchmark(getMultipleUV(site, as.character(BeginDate), EndDate, UVP),
                  getMultipleUVdataRetrieval(site, as.character(BeginDate), EndDate,UVP), replications=1)


mergeReturn <- mergeDatasets(QWLaura, UVLorenz, QWcodesLaura)
DTComplete <- mergeReturn$DTComplete
QWcodes <- mergeReturn$QWcodes

j <- "SuspSed"
DT <- DTComplete[c(j,getPredictVariables(names(UVLorenz)), "decYear","sinDY","cosDY","datetime")]
DT <- na.omit(DT)

mergeReturn <- mergeDatasets(QWLorenz, UVLorenz, QWcodes)
DTComplete <- mergeReturn$DTComplete
QWcodes <- mergeReturn$QWcodes
DT2 <- DTComplete[c(j,getPredictVariables(names(UVLorenz)), "decYear","sinDY","cosDY","datetime")]
DT2 <- na.omit(DT2)


#Differences are in analyte name SuspSed vs Suspended sediment concentration (SSC)

predictVariables <- names(DT)[-which(names(DT) %in% investigateResponse)]
predictVariables <- predictVariables[which(predictVariables != "datetime")]
predictVariables <- predictVariables[which(predictVariables != "decYear")]

kitchenSink <- createFullFormula(DT,j)

returnPrelim <- prelimModelDev(DT,j,kitchenSink,
                               "BIC", #Other option is "AIC"
                               transformResponse)

steps <- returnPrelim$steps
modelResult <- returnPrelim$modelStuff
modelReturn <- returnPrelim$DT.mod

