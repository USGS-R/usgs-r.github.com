#'internalStudentRes
#'
#'Compute internally Studentized residuals
#'
#'@param DT DTframe that includes all response and predictor variables
#'@param modelCoefList named list of model coefficients
#'@param transformResponse string can be "normal" or "lognormal", perhaps try to generalize this more in future
#'@return StRes.all
#'@keywords studentized residuals
#'@export
#'@examples
#' DTComplete <- StLouisDT
#' UV <- StLouisUV
#' response <- "Ammonia.N"
#' siteINFO <- StLouisInfo
#' DT <- DTComplete[c(response,getPredictVariables(names(UV)), "decYear","sinDY","cosDY","datetime")]
#' DT <- na.omit(DT)
#' kitchenSink <- createFullFormula(DT,response)
#' returnPrelim <- prelimModelDev(DT,response,kitchenSink)
#' modelReturn <- returnPrelim$DT.mod
#' modelCoef <- modelReturn$PARAML
#' names(modelCoef) <- c(dimnames(modelReturn$XLCAL)[[2]],"logSigma")
#' modelCoefList <- list()
#' modelCoefList[[rownames(attributes(modelReturn$terms)$factors)[1]]] <- modelCoef
#' intStudent <- internalStudentRes(DT,modelCoefList,TRUE)
internalStudentRes <- function(localDT, modelCoefList,transformResponse="lognormal"){
  StRes.all <- nrow(localDT)
  h <- numeric()
  StRes <- numeric()
  responseVariables <- names(modelCoefList)
  
  if (is.list(modelCoefList)) {
    indexVector <- responseVariables
  } else {
    indexVector <- c(1)
  }
  
  for (i in indexVector){

    m2Coef <- modelCoefList[[i]]
    modelvars <- names(m2Coef)[-c(1,length(m2Coef))]
    
    rawDTNames <- sapply(strsplit(modelvars,"log"),function(x)x[1])  # Obviously could do more transforms
    
    logDTNames <- sapply(strsplit(modelvars,"log"),function(x)x[2])
    logDTNames <- substring(logDTNames,2,nchar(logDTNames)-1)
    
    logData <- as.data.frame(sapply(localDT[,logDTNames[!is.na(logDTNames)]], function(x) log(x)))
    colnames(logData) <- paste("log",logDTNames[!is.na(logDTNames)],sep="")
    
    DT <- cbind(DT, logData)
    
    rawDTNames["" == rawDTNames] <- colnames(logData)
    
    if(length(m2Coef)>1){
 
      dat200 <- as.data.frame(localDT[,rawDTNames]) #Generate DT frame with only variables from the current model
      names(dat200) <- rawDTNames
      
      #Compute residuals
      responseVariable <- i
#       y<-log(as.numeric(DT[,responseVariable])+1) #generalize this for censored DT--optional transformation (probably just log)
      responseValue <- localDT[,responseVariable]@.Data[,2]       
      y <- responseValue
      
      if ("lognormal" == transformResponse){
        y<-log(responseValue) #add 1?
      }
      
      
      X <- as.matrix(cbind(rep(1,nrow(dat200)),dat200))
      Beta <- m2Coef[-length(m2Coef)]
      predictions <- X%*%Beta
      residuals <- predictions - y
      
      #Compute H matrix of leverage values
      H <- X%*%(ginv((t(X)%*%X)))%*%t(X)
      for (j in 1:nrow(X)) h[j] <- H[j,j] #leverage values on the diagonal of the matrix are used to compute studentized residuals
      
      s <- sqrt(sum(residuals^2)/(nrow(X)-length(Beta)))
      for (j in 1:nrow(X)) StRes[j] <- residuals[j]/(s/(sqrt(1-h[j]))) #Compute studentized residuals
      StRes.all <- cbind(StRes.all,StRes) #Add studentized residuals to DT frame for current model
    }
  }
  StRes.all <- StRes.all[,-1]
  if(is.matrix(StRes.all)) colnames(StRes.all) <- responseVariables
  return(StRes.all)
}