sitesCA <- getNWISSites(stateCd="CA",outputDataTypeCd="dv",
                        hasDataTypeCd="dv",siteOutput="Expanded")


sitesCA <- getRDB1Data("http://waterservices.usgs.gov/nwis/site/?format=rdb&stateCd=ca&seriesCatalogOutput=true&outputDataTypeCd=dv&hasDataTypeCd=dv",asDateTime = FALSE)


# Get sites:
library(dplyr)

allData <- getGeneralWQPData(siteid="USGS-04085435")
characteristics <- unique(allData$CharacteristicName)

df <- group_by(allData, CharacteristicName)
summary <- summarise(df, 
                     startDate = min(ActivityStartDate, na.rm = TRUE),
                     endDate = max(ActivityStartDate, na.rm = TRUE),
                     count = n()
                     )