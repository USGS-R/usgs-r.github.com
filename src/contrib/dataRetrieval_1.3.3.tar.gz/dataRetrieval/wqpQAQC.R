getWQPSites <- function(...){
  
  matchReturnNames <- match.call()
  namesToCall <- names(matchReturnNames[-1])
  
  matchReturn <-  do.call("call", 
                          c(list(as.character(match.call()[[1]])),
                            lapply(as.list(match.call())[-1],eval)))[-1]
  
  matchReturn <-  as.character(matchReturn)
  
  options <- c("bBox","lat","long","within","countrycode",
               "statecode","countycode","siteType","organization",
               "siteNumber","huc","sampleMedia","characteristicType",
               "characteristicName","pCode","activityId",
               "startDateLo","startDateHi","mimeType","Zip",
               "providers")
  
  if(!all(namesToCall %in% options)) 
    warning(matchReturn[!(namesToCall %in% options)],
            "is not a valid query parameter 
            to the Water Quality Portal")
  
  values <- sapply(matchReturn, 
                   function(x) URLencode(as.character(paste(x,collapse="",sep=""))))
  
  urlCall <- paste(paste(namesToCall,values,sep="="),collapse="&")
  
  
  baseURL <- "http://www.waterqualitydata.us/Station/search?"
  urlCall <- paste(baseURL,
                   urlCall,
                   "&mimeType=tsv",sep = "")
  h <- basicHeaderGatherer()
  
  suppressWarnings(retval <- read.delim(urlCall, 
                                        header = TRUE, quote="\"", dec=".", sep='\t', 
                                        colClasses=c('character'), fill = TRUE))
  return(retval)
}

getWQPData <- function(...){
  
  matchReturn <- match.call()
  
  options <- c("bBox","lat","long","within","countrycode","statecode","countycode","siteType","organization",
               "siteNumber","huc","sampleMedia","characteristicType","characteristicName","pCode","activityId",
               "startDateLo","startDateHi","mimeType","Zip","providers")
  
  if(!all(names(matchReturn[-1]) %in% options)) warning(matchReturn[!(names(matchReturn[-1]) %in% options)],"is not a valid query parameter to the Water Quality Portal")
  
  values <- sapply(matchReturn[-1], function(x) URLencode(as.character(paste(x,collapse="",sep=""))))
  
  urlCall <- paste(paste(names(values),values,sep="="),collapse="&")
  
  
  baseURL <- "http://www.waterqualitydata.us/Result/search?"
  urlCall <- paste(baseURL,
                   urlCall,
                   "&mimeType=tsv",sep = "")
  #   h <- basicHeaderGatherer()
  #   doc <- getURI(url, headerfunction = h$update)
  
  suppressWarnings(retval <- read.delim(urlCall, header = TRUE, quote="\"", dec=".", sep='\t', colClasses=c('character'), fill = TRUE))
  return(retval)
}

setInternet2(use=NA)
setInternet2(use=FALSE)
setInternet2(use=NA)
options(timeout=120)

siteListAll <- getWQPSites(characteristicName="pH")

# pH request took longer than R could handle. Do it from the web....
# dataAll <- getWQPData(characteristicName="pH")

# This crapped out too:
# temp <- tempfile()
# download.file("http://www.waterqualitydata.us/Result/search?characteristicName=pH&mimeType=csv&zip=yes",temp)
# allData <- read.table(unz(temp, "a1.dat"))

# allData <- read.table(unzip("D:\\LADData\\WQP","Result.zip"))

allData <- read.csv("D:/LADData/WQP/Result.csv",stringsAsFactors=FALSE)

#Check for bad data:
badRows <- which(allData$ResultMeasureValue > 14 | allData$ResultMeasureValue < 0)

#Subset bad data out:
badData <- allData[badRows,]

#Save:
write.csv(badData,file="badPH.csv",row.names=FALSE)

#Load:
badData <- read.csv(file="badPH.csv")

length(unique(allData$MonitoringLocationIdentifier[badRows]))
allData$ResultMeasureValue[badRows]

badDataSmall <-

countSum <- aggregate(badData,by=list(badData$MonitoringLocationIdentifier),FUN=length)[1:2]

bad


