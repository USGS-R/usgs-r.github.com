#Mac only ?:
# install.packages(c('dataRetrieval','USGSHydroTools'),
#                  repos=c("http://usgs-r.github.com",
#                          "http://www.stats.ox.ac.uk/pub/RWin",
#                          "http://cran.us.r-project.org"),
#                  dependencies=TRUE)

library(dataRetrieval)
library(USGSHydroTools)

#####################################################
# User input:
parameter <- "Chloride"
state <- "US:55" #WI

minVal <- 0
maxVal <- 1000
######################################################
#####################################################
# User input:
parameter <- "Chloride"
state <- "US:33" #NH

minVal <- 0
maxVal <- 1000
######################################################
#####################################################
# User input:
# parameter <- "Dissolved+oxygen+(DO);Dissolved+oxygen"
# state <- "US:34" #NJ
# 
# minVal <- 0
# maxVal <- 50
######################################################

sitesReturned <- getWQPSites(statecode=state, characteristicName=parameter)
dataReturned <- getGeneralWQPData(statecode=state, characteristicName=parameter)

unique(dataReturned$ResultMeasure.MeasureUnitCode)

#####################################################
# User input:
# Chloride
# Let's build a conversion table:
# we'll get everything in mg/l
# cFactor <- c(1, 1, 1, 1, 0.001, 0.001, 1, 0.001)
# names(cFactor) <- unique(dataReturned$ResultMeasure.MeasureUnitCode)
######################################################

cFactor <- c(1, 1, 1, 1, 0.001, 0.001)
names(cFactor) <- unique(dataReturned$ResultMeasure.MeasureUnitCode)


#####################################################
# User input:
# DO
# Let's build a conversion table:
# we'll get everything in mg/l
# 
# dataReturned$ResultMeasure.MeasureUnitCode[dataReturned$ResultMeasure.MeasureUnitCode == ""] <- "noUnit"
# 
# cFactor <- c(1, 1, 1, 1,0.0001, 1, 1)
# names(cFactor) <- unique(dataReturned$ResultMeasure.MeasureUnitCode)
######################################################

dataReturned$ResultMeasureValue <- as.numeric(dataReturned$ResultMeasureValue)*cFactor[dataReturned$ResultMeasure.MeasureUnitCode]
dataReturned$ActivityStartDate <- as.Date(dataReturned$ActivityStartDate)

summaryDF <- summarizedataDF(dataReturned, "MonitoringLocationIdentifier", "ResultMeasureValue", "ActivityStartDate")

lat <- as.numeric(sitesReturned$LatitudeMeasure)
lon <- as.numeric(sitesReturned$LongitudeMeasure)
names(lat) <- sitesReturned$MonitoringLocationIdentifier
names(lon) <- sitesReturned$MonitoringLocationIdentifier

summaryDF$lat <- lat[summaryDF$MonitoringLocationIdentifier]
summaryDF$lon <- lon[summaryDF$MonitoringLocationIdentifier]


hist(dataReturned$ResultMeasureValue,
     main="Histogram of all reported values",xlab="Reported Value")

hist(dataReturned$ResultMeasureValue[dataReturned$ResultMeasureValue < maxVal],
     main=paste("Histogram of reported values < ",maxVal,sep=""),xlab="Reported Value")

boxplot(dataReturned$ResultMeasureValue,ylim = c(0,maxVal),main="Boxplot of all reported values")
boxplot(dataReturned$ResultMeasureValue,ylim = c(0,100),main="Boxplot of all reported values")

sum(dataReturned$ResultMeasureValue[!is.na(dataReturned$ResultMeasureValue)] > 250)
sum(dataReturned$ResultMeasureValue[!is.na(dataReturned$ResultMeasureValue)] > maxVal)

sizeVar <- "count"
colorVar <- "mean"
latVar <- "lat"
lonVar <- "lon"
mainTitle <- paste("Concentration of ", parameter,sep="")

######################################################
# User input, could use max/min lat/lon, but looks better when done by hand:
mainTitle <- "Chloride"
#Wisconsin:
# xmin <- -96.25
# xmax <- -85
# ymin <- 42
# ymax <- 47.5
# #legend upper left corner:
# xleft <- xmin + 0.2
# ytop <- .5+(ymin + ymax)/2 
######################################################

######################################################
#NH:
xmin <- min(summaryDF$lon)-3
xmax <- max(summaryDF$lon)+1
ymin <- min(summaryDF$lat)-.5
ymax <- max(summaryDF$lat)+.5


#legend upper left corner:
xleft <- xmin + 0.2
ytop <- 0.85*(ymax-ymin) + ymin
######################################################

######################################################
#New Jersey:
# xmin <- min(summaryDF$lon)-3
# xmax <- max(summaryDF$lon)+1
# ymin <- min(summaryDF$lat)-.5
# ymax <- max(summaryDF$lat)+.5
# 
# 
# #legend upper left corner:
# xleft <- xmin + 0.2
# ytop <- 0.85*(ymax-ymin) + ymin
######################################################

sizeThresh1 <- 2
sizeThresh2 <- 20

pdf("Concentration.pdf")
MapSizeColor(summaryDF,colorVar,sizeVar,latVar,lonVar,sizeThresh1,sizeThresh2,
             unit=1,titlePos=-2,
             xmin,xmax,ymin,ymax,xleft=xleft,ytop=ytop,
             mainTitle=mainTitle,includeLabels=FALSE)
dev.off()
shell.exec("Concentration.pdf")
# system("open Concentration.pdf.pdf")  #Mac?

#Map of sites with values over max or under min:
subSummaryDF <- summarizedataDF(dataReturned[dataReturned$ResultMeasureValue > maxVal | dataReturned$ResultMeasureValue < minVal,],
                                "MonitoringLocationIdentifier", "ResultMeasureValue", "ActivityStartDate")
subSummaryDF$lat <- lat[subSummaryDF$MonitoringLocationIdentifier]
subSummaryDF$lon <- lon[subSummaryDF$MonitoringLocationIdentifier]
mainTitle <- paste("Concentration outside user-defined range\n",parameter,sep="")

pdf("Outliers.pdf")
MapSizeColor(subSummaryDF,colorVar,sizeVar,latVar,lonVar,sizeThresh1,sizeThresh2,
             unit=1,titlePos=-4,
             xmin,xmax,ymin,ymax,xleft=xleft,ytop=ytop,
             mainTitle=mainTitle,includeLabels=FALSE)
dev.off()
shell.exec("Outliers.pdf")
# system("open Outliers.pdf")  #Mac?





