library(dataRetrieval)
library(survival)

runSurvReg<-function(estPtYear,estPtLQ,localSample = Sample,windowY=10,windowQ=2,
                     windowS=0.5,minNumObs=100,minNumUncen=50,interactive=TRUE) {
  numEstPt<-length(estPtYear)
  resultSurvReg<-array(0,c(numEstPt,3))
  
  printUpdate <- floor(seq(1,numEstPt,numEstPt/100))
  
  if (minNumUncen >= nrow(localSample)) stop('minNumUncen is greater than total number of samples')
  if (minNumObs >= nrow(localSample)) stop('minNumObs is greater than total number of samples')
  
  if (interactive) cat("Survival regression (% complete):\n")
  
  #   options(warn=1) #warn=0 is default
  warningFlag <- 0
  
  for (i in 1:numEstPt) {
    
    # This loop takes us through all the estimation points
    # We always reset the window widths to their starting values, because they may
    #   have been widened in the process
    tempWindowY<-windowY
    tempWindowQ<-windowQ
    tempWindowS<-windowS
    estY<-estPtYear[i]
    estLQ<-estPtLQ[i]
    
    repeat{
      #  We subset the sample frame by time, to narrow the set of data to run through in the following steps
      
      Sam<-subset(localSample,abs(DecYear-estY)<=tempWindowY)
      diffY<-abs(Sam$DecYear-estY)
      weightY<-triCube(diffY,tempWindowY)
      weightQ<-triCube(Sam$LogQ-estLQ,tempWindowQ)
      diffUpper<-ceiling(diffY)
      diffLower<-floor(diffY)
      diffSeason<-pmin(abs(diffUpper-diffY),abs(diffY-diffLower))
      weightS<-triCube(diffSeason,tempWindowS)
      Sam$weight<-weightY*weightQ*weightS
      Sam<-subset(Sam,weight>0)
      numPosWt<-length(Sam$weight)
      numUncen<-sum(Sam$Uncen)
      tempWindowY<-tempWindowY*1.1
      tempWindowQ<-tempWindowQ*1.1
      # the next line is designed so that if the user sets windowS so it includes
      # data from all seasons, the widening process leaves it alone      
      tempWindowS<-if(windowS<=0.5) min(tempWindowS*1.1,0.5) else windowS
      if(numPosWt>=minNumObs&numUncen>=minNumUncen) break
    }
    
    
    # now we are ready to run Survival Regression
    weight<-Sam$weight
    aveWeight<-sum(weight)/numPosWt
    weight<-weight/aveWeight
    Sam <- data.frame(Sam)
    
    x <- tryCatch({
      survModel<-survreg(Surv(log(ConcLow),log(ConcHigh),type="interval2") ~ 
                           DecYear+LogQ+SinDY+CosDY,data=Sam,weights=weight,dist="gaus")
      
    }, warning=function(w) {
      #       message("Survival regression model did not converge at iteration: ", i)
      return(NULL)
    }, finally={
      new<-data.frame(DecYear=estY,LogQ=estLQ,SinDY=sin(2*pi*estY),CosDY=cos(2*pi*estY))
      #   extract results at estimation point
      yHat<-predict(survModel,new)
      SE<-survModel$scale
      bias<-exp((SE^2)/2)
      resultSurvReg[i,1]<-yHat
      resultSurvReg[i,2]<-SE
      resultSurvReg[i,3]<-bias*exp(yHat)
      
      if (i %in% printUpdate & interactive) cat(floor(i*100/numEstPt),"\t")
    })
    
    if(is.null(x)){
      warningFlag <- warningFlag + 1
    }
  }
  
  if (warningFlag > 0){
    message(warningFlag, " out of ", numEstPt, " did not properly converge. This is generally acceptable, but you may want to check for outliers, repeated values on a single date, or something else unusal about the data.")
  }
  #   options(warn=0) 
  if (interactive) cat("\nSurvival regression: Done")
  
  return(resultSurvReg)
}

estSurfaces<-function(localDaily = Daily, localSample = Sample, windowY=10,windowQ=2,windowS=0.5,minNumObs=100,minNumUncen=50){
  originalColumns <- names(localSample)
  
  bottomLogQ<-min(localDaily$LogQ) - 0.05
  topLogQ<-max(localDaily$LogQ) + 0.05
  stepLogQ<-(topLogQ-bottomLogQ)/13
  vectorLogQ<-seq(bottomLogQ,topLogQ,stepLogQ)
  stepYear<-1/16
  bottomYear<-floor(min(localDaily$DecYear))
  topYear<-ceiling(max(localDaily$DecYear))
  vectorYear<-seq(bottomYear,topYear,stepYear)
  nVectorYear<-length(vectorYear)
  estPtLogQ<-rep(vectorLogQ,nVectorYear)
  estPtYear<-rep(vectorYear,each=14)
  
  colToKeep <- c("ConcLow","ConcHigh","Uncen","DecYear","SinDY","CosDY","LogQ")
  
  localSampleMin <- localSample[,which(originalColumns %in% colToKeep)]
  
  resultSurvReg<-runSurvReg(estPtYear,estPtLogQ,localSampleMin,windowY,windowQ,windowS,minNumObs,minNumUncen)
  
  surfaces<-array(0,dim=c(14,nVectorYear,3))
  
  for(iQ in 1:14) {
    for(iY in 1:nVectorYear){ 
      k<-(iY-1)*14+iQ
      surfaces[iQ,iY,]<-resultSurvReg[k,]
    }
  }
  
  return(surfaces)
}

modelEstimation<-function(localDaily = Daily,localSample = Sample, localINFO = INFO, 
                          windowY=10, windowQ=2, windowS=0.5,minNumObs=100,minNumUncen=50, 
                          env=parent.frame(),localSurface=NA,localAnnualResults=NA){
  cat("\n first step running estCrossVal may take about 1 minute")
#   Sample1<-estCrossVal(localSample = localSample, windowY, windowQ, windowS, minNumObs, minNumUncen)
  
  surfaceIndexParameters<-surfaceIndex(localDaily = localDaily)
  localINFO$bottomLogQ<-surfaceIndexParameters[1]
  localINFO$stepLogQ<-surfaceIndexParameters[2]
  localINFO$nVectorLogQ<-surfaceIndexParameters[3]
  localINFO$bottomYear<-surfaceIndexParameters[4]
  localINFO$stepYear<-surfaceIndexParameters[5]
  localINFO$nVectorYear<-surfaceIndexParameters[6]
  localINFO$windowY<-windowY
  localINFO$windowQ<-windowQ
  localINFO$windowS<-windowS
  localINFO$minNumObs<-minNumObs
  localINFO$minNumUncen<-minNumUncen
  cat("\nNext step running  estSurfaces with survival regression:\n")
  surfaces1<-estSurfaces(localDaily = localDaily, localSample = localSample, windowY, windowQ, windowS, minNumObs, minNumUncen)
  
  Daily1<-estDailyFromSurfaces(localDaily = localDaily, localINFO = localINFO, localsurfaces = surfaces1)
  
  matchReturn <- match.call(expand.dots = FALSE) # This doesn't return the default arguments
  #   fcall <- mget(names(formals()),sys.frame(sys.nframe()))
  
  if (is.null(matchReturn$localDaily)){
    env$Daily<-Daily1
  } else {
    assign(as.character(matchReturn$localDaily), Daily1, envir=env)
  }
  
  if (is.null(matchReturn$localINFO)){
    env$INFO<-localINFO
  } else {
    assign(as.character(matchReturn$localINFO), localINFO, envir=env)
  }
  
#   if (is.null(matchReturn$localSample)){
#     env$Sample<-Sample1
#   } else {
#     assign(as.character(matchReturn$localSample), Sample1, envir=env)
#   }
  
  
  if(is.na(localSurface)){
    env$surfaces <- surfaces1
  } else {
    assign(as.character(matchReturn$localSurface), surfaces1, envir=env)
  }
  
  annualResults1 <- setupYears(paLong = 12, paStart = 10, localDaily = Daily1)
  if(is.na(localAnnualResults)){
    env$AnnualResults <- annualResults1 
  } else {
    assign(as.character(matchReturn$localAnnualResults), annualResults1 , envir=env)
  }
  
  cat("\nDone with modelEstimation,\nThe AnnualResults data frame that has been created is for water years.  If you want a data frame of results for some other period of analysis then give the command:\n
      AnnualResults <- setupYears(paLong,paStart)\n")
  
}

triCube<-function(d,h) {
  #  triCube is Tukey tricubed weight function
  #    first argument, d, is a vector of the distances between the observations and the estimation point
  #    second argument, h, is the half window width
  #    it returns a vector of weights (w) for the observations in the vector, d
  n<-length(d)
  zero<-rep(0,n)
  ad<-abs(d)
  w<-(1-(ad/h)^3)^3
  w<-pmax(zero,w)
  return(w)
}

surfaceIndex<-function(localDaily = Daily){
  bottomLogQ<-min(localDaily$LogQ) - 0.05
  topLogQ<-max(localDaily$LogQ) + 0.05
  stepLogQ<-(topLogQ-bottomLogQ)/13
  vectorLogQ<-seq(bottomLogQ,topLogQ,stepLogQ)
  stepYear<-1/16
  bottomYear<-floor(min(localDaily$DecYear))
  topYear<-ceiling(max(localDaily$DecYear))
  vectorYear<-seq(bottomYear,topYear,stepYear)
  nVectorYear<-length(vectorYear)
  surfaceIndexParameters<-c(bottomLogQ,stepLogQ,14,bottomYear,stepYear,nVectorYear)
  return(surfaceIndexParameters)
}

Sample<-getSampleData("01189995","00955","1973-10-01","2013-09-30")
Daily <- getDVData("01189995","00060","1973-10-01","2013-09-30")
INFO <- getMetaData("01189995","00955",interactive=FALSE)
INFO$shortname <- "Farmington"
Sample <- mergeReport()

modelEstimation()

# Exploring the results:
localSample <- Sample
localDaily <- Daily

minNumObs<-100
minNumUncen<-50

originalColumns <- names(localSample)

bottomLogQ<-min(localDaily$LogQ) - 0.05
topLogQ<-max(localDaily$LogQ) + 0.05
stepLogQ<-(topLogQ-bottomLogQ)/13
vectorLogQ<-seq(bottomLogQ,topLogQ,stepLogQ)
stepYear<-1/16
bottomYear<-floor(min(localDaily$DecYear))
topYear<-ceiling(max(localDaily$DecYear))
vectorYear<-seq(bottomYear,topYear,stepYear)
nVectorYear<-length(vectorYear)
estPtLQ<-rep(vectorLogQ,nVectorYear)
estPtYear<-rep(vectorYear,each=14)

tempWindowY<- INFO$windowY
tempWindowQ<-INFO$windowQ
tempWindowS<-INFO$windowS

#Now, let's look at a weird regressions:
i <- 3695

estY<-estPtYear[i]
estLQ<-estPtLQ[i]

repeat{
  #  We subset the sample frame by time, to narrow the set of data to run through in the following steps
  
  Sam<-subset(localSample,abs(DecYear-estY)<=tempWindowY)
  diffY<-abs(Sam$DecYear-estY)
  weightY<-triCube(diffY,tempWindowY)
  weightQ<-triCube(Sam$LogQ-estLQ,tempWindowQ)
  diffUpper<-ceiling(diffY)
  diffLower<-floor(diffY)
  diffSeason<-pmin(abs(diffUpper-diffY),abs(diffY-diffLower))
  weightS<-triCube(diffSeason,tempWindowS)
  Sam$weight<-weightY*weightQ*weightS
  Sam<-subset(Sam,weight>0)
  numPosWt<-length(Sam$weight)
  numUncen<-sum(Sam$Uncen)
  tempWindowY<-tempWindowY*1.1
  tempWindowQ<-tempWindowQ*1.1
  # the next line is designed so that if the user sets windowS so it includes
  # data from all seasons, the widening process leaves it alone      
  tempWindowS<-if(INFO$windowS<=0.5) min(tempWindowS*1.1,0.5) else INFO$windowS
  if(numPosWt>=minNumObs&numUncen>=minNumUncen) break
}

weight<-Sam$weight
aveWeight<-sum(weight)/numPosWt
weight<-weight/aveWeight
Sam <- data.frame(Sam)

survModel<-survreg(Surv(log(ConcLow),log(ConcHigh),type="interval2")~DecYear+LogQ+SinDY+CosDY,data=Sam,weights=weight,dist="gaus",score=TRUE)
survModel$score

multiPlotDataOverview(localSample=Sam)
# vs:
multiPlotDataOverview()

# Here's one that does converge:
i <- 3696
tempWindowY<- INFO$windowY
tempWindowQ<-INFO$windowQ
tempWindowS<-INFO$windowS
estY<-estPtYear[i]
estLQ<-estPtLQ[i]

repeat{
  #  We subset the sample frame by time, to narrow the set of data to run through in the following steps
  
  Sam<-subset(localSample,abs(DecYear-estY)<=tempWindowY)
  diffY<-abs(Sam$DecYear-estY)
  weightY<-triCube(diffY,tempWindowY)
  weightQ<-triCube(Sam$LogQ-estLQ,tempWindowQ)
  diffUpper<-ceiling(diffY)
  diffLower<-floor(diffY)
  diffSeason<-pmin(abs(diffUpper-diffY),abs(diffY-diffLower))
  weightS<-triCube(diffSeason,tempWindowS)
  Sam$weight<-weightY*weightQ*weightS
  Sam<-subset(Sam,weight>0)
  numPosWt<-length(Sam$weight)
  numUncen<-sum(Sam$Uncen)
  tempWindowY<-tempWindowY*1.1
  tempWindowQ<-tempWindowQ*1.1
  # the next line is designed so that if the user sets windowS so it includes
  # data from all seasons, the widening process leaves it alone      
  tempWindowS<-if(INFO$windowS<=0.5) min(tempWindowS*1.1,0.5) else INFO$windowS
  if(numPosWt>=minNumObs&numUncen>=minNumUncen) break
}

weight<-Sam$weight
aveWeight<-sum(weight)/numPosWt
weight<-weight/aveWeight
Sam <- data.frame(Sam)

survModel<-survreg(Surv(log(ConcLow),log(ConcHigh),type="interval2")~DecYear+LogQ+SinDY+CosDY,data=Sam,weights=weight,dist="gaus",score=TRUE)
survModel$score

multiPlotDataOverview(localSample=Sam)
survModel
# vs:
multiPlotDataOverview()

# Not a huge difference in the plots.  The model results aren't that different, but the Loglik, Chisq, and p are
# different (as I would assume since it didn't converge).
# Playing around a bit, there are many that converge with the one outlier point, so it's not just that
# The other ones:
i <- 3919
i <- 3933
i <- 3947

# I guess the point is, the user would have to dig in a bit more than this to figure out exactly what is going on
# with those particular iterations.

