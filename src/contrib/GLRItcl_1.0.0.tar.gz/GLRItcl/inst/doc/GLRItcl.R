
## ----openLibrary, echo=FALSE---------------------------------------------
library(knitr)
options(continue=" ")
options(width=60)




## ----include=TRUE ,echo=FALSE,eval=TRUE----------------------------------
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, tidy=FALSE,comment="")
knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)


## ----workflow,eval = TRUE------------------------------------------------
library(GLRItcl)


## ----helpFunc,eval = FALSE-----------------------------------------------
## ?getGLRIData


## ----rawFunc,eval = TRUE-------------------------------------------------
getGLRIData


