#############################################################
# # Only do once:
# install.packages(c("rloadest","USGSwsQW"), 
#                  repos=c("http://usgs-r.github.com",
#                          "http://cran.us.r-project.org"),
#                  dependencies=TRUE)
#############################################################

library(EGRET)
library(dataRetrieval)
library(rloadest)
library(survival)

siteid <- "01491000"
pcode <- "00631"
startDate <- "1979-10-24"
endDate <- "2011-09-29"

Daily <- getNWISDaily(siteid,"00060",startDate,endDate)
Sample <- getNWISSample(siteid,pcode,startDate,endDate)
Sample <- mergeReport()
Sample <- Sample[!duplicated(Sample$Date),]
INFO <- getNWISInfo(siteid,pcode,interactive=FALSE)
modelEstimation()


loadestModel <- loadReg(Surv(ConcLow, ConcHigh, type="interval2")
                        ~ model(9), 
                        data = Sample, 
                        flow = "Q", dates = "Date",
                        flow.units="cms",
                        conc.units="mg/l",
                        station=INFO$station.nm)
print(loadestModel, brief=FALSE, load.only=FALSE)

# Make DailyLoadest
DailyLoadest <- Daily[,which(!(names(Daily) %in% 
                                 c("ConcDay","FluxDay","FNConc","FNFlux","SE","yHat")))]

concs <- predConc(loadestModel,DailyLoadest, by="day")
flux <- predLoad(loadestModel,DailyLoadest, by="day")

predictResp <- fitted(loadestModel$cfit, type='response')
predictResp_mean <- fitted(loadestModel$cfit, type='mean')

DailyLoadest$ConcDay <- concs$Conc
DailyLoadest$FluxDay <- DailyLoadest$ConcDay*86.4*DailyLoadest$Q
DailyLoadest$SE <- concs$Std.Err

# Make SampleLoadest

SampleLoadest <- Sample[,which(!(names(Sample) %in% 
                                   c("yHat","SE","ConcHat")))]

SampleLoadest$SE <- concs$Std.Err[
  which(concs$Date %in% SampleLoadest$Date)]
SampleLoadest$yHat <-predictResp
SampleLoadest$ConcHat <- predictResp_mean

fluxBiasMulti(localSample = SampleLoadest,
              localDaily=DailyLoadest,
              moreTitle="LoadEst")

