NWCCompare
==========


install this package using the following code:

install.packages("NWCCompare",repos="http://usgs-r.github.com",type="source")
