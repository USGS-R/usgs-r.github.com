#' This is data to be included in my package
#'
#' @name obs_data
#' @docType data
#' @author Jessica Thompson \email{jlthomps@@usgs.gov}
#' @keywords data
#' @name mod_data
#' @docType data
#' @author Jessica Thompson \email{jlthomps@@usgs.gov}
#' @keywords data
#' @name qfiletempf
#' @docType data
#' @author Jessica Thompson \email{jlthomps@@usgs.gov}
#' @keywords data
#' @name dailyData
#' @docType data
#' @author Jessica Thompson \email{jlthomps@@usgs.gov}
#' @keywords data
#' @name sampleData
#' @docType data
#' @author Jessica Thompson \email{jlthomps@@usgs.gov}
#' @keywords data
NULL