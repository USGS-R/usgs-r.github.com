# Do once:
install.packages(c("XML","RCurl"))
install.packages("D:/LADData/RCode/EnDDaT_1.0.1.tar.gz", repos=NULL,type="source")

# Do everytime:
library("EnDDaT")

#Helps R deal with bigger requests:
setInternet2(use=NA)
setInternet2(use=FALSE)
setInternet2(use=NA)

fileName <- "RedArrowParams.csv"
filePath <- "D:/LADData/EnDDaT Documents/rEnDDaT"
totalParams <- getParamsFromFile(filePath, fileName)

# General beach info - optional:
beachName <- 'Random Beach'
tzone <- '-6_CST' # Options: ('-6_CST', '0_GMT', '-5_CDT','-5_EST', etc)...basically 'hours offset_abbrievation'
lake <- 'michigan' # Required if requesting GLCFS data ('michigan','erie','huron','ontario','superior')
gap <- 6 # If there is processing done, this is the number of hours back to look for data

# Time Range required:
##############################################
# Very important:
# Only do one year at a time especially for GLCFS data!
# Precip
##############################################
endPosition <- as.character(Sys.Date())
beginPosition <-  as.character(Sys.Date()-7)

# Optional:
#go to http://cida.usgs.gov/enddat/DataList.jsp, upload Times, and paste Filter file ID here
# filterID <- "c8a200ca-11ca-4d30-b9c9-3fe0dee5ca48"
# baseReturn <- generateBaseUrl(beginPosition, endPosition,
#                               beachName=beachName, tzone=tzone,
#                               lake=lake,gap=gap,filter=filterID)

baseReturn <- generateBaseUrl(beginPosition, endPosition,
                              beachName=beachName, tzone=tzone,
                              lake=lake,gap=gap)

EnDDaTData <- getEnDDaTData(totalParams, baseReturn, archive=FALSE,endPostion,beginPosition)

# Or separately:
NWISData <- getNWISData(totalParams, baseReturn)
GLCFSData <- getGLCFSData(totalParams, baseReturn)
GDPData <- getGDPData(totalParams, baseReturn, archive=FALSE,endPostion,beginPosition)
PrecipPointData <- getPRECIPData(totalParams, baseReturn)
