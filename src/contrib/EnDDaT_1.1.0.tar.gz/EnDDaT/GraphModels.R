#library(glmnet) # for LASSO--not needed yet, but possibly will in the future
library(censReg)

setwd("M:/QW Monitoring Team/GLRI beaches/Modeling/EnDDaT modeling results/R Codes/2013")

paramFile <- read.csv("M:/QW Monitoring Team/GLRI beaches/Modeling/Models for 2013 season/Model Development Performance/paramFile.csv",stringsAsFactor=FALSE)


beaches  <- unique(paramFile$Beach)
names(beaches) <- c("Hika","Kreher","Maslowski","Neshotah", "Point","Recalibration","Thompson")

beaches <- beaches["RA" != beaches]

regressionType <- unique(paramFile$Method)
regType <- c("lm", "censReg","censReg","lm","lm","lm","censReg","lm")
names(regType) <- regressionType

pdf("SuperGraphs.pdf")

for (k in 1:length(beaches)){
  
  # for a single beach:
  
  beach <- beaches[k]
  beachParams <- paramFile[which(paramFile$Beach == beach),]
  
  methodsAvailable <- unique(beachParams$Method)
  methodsAvailable <- methodsAvailable["RECAL" != methodsAvailable]
  
  for (z in 1:length(methodsAvailable)){
  
    method <- methodsAvailable[z]
    params <- beachParams[which(beachParams$Method == method),]
    
    
    #Read beach data file
    filetype <- params$file[1]
    filePath <- paste("M:/QW Monitoring Team/GLRI beaches/Modeling/Models for 2013 season/Datasets/",
                      names(beach),"/",beach,"2.0.",filetype,".csv",sep="")
    df <- read.csv(filePath)
    
    beachRegType <- as.character(regType[method])
    
    #Define response variable
    response <- "log_beach_EColi"
    set.seed(100)
    randomIndex <- unique(sample(1:nrow(df),size=nrow(df),replace=FALSE))
    
    # EPAthresh <- log10(235)
    # thresh <- 2.25
    EPAthresh <- 10^(log10(235))
    thresh <- 10^(2.25)
    fsize <- 0.8
    
    addLabel <- function(labelString, x=0.10, y=0.93) {
      x1 <- grconvertX(x, from="npc", to="user")
      y1 <- grconvertY(y, from="npc", to="user")  
      text(x=x1, y=y1, labelString, cex=.7)
    }
    
    ylims <- c(1,2000)
    yadd <- 0.0001
    
    # With Crossvalidation:
    if (beachRegType == "lm"){
      
      numWindows <- 5
      fraction <- 1/numWindows
      fullColors <- vector()
      fullSens <-  vector()
      fullSpec <-  vector()
      
      for (i in 1:numWindows){
        
        numObs <- nrow(df)
        minToRemove <- floor(numObs*fraction*(i-1))+i
        maxToRemove <- floor(numObs*fraction*i)+i
        indexToRemove <- randomIndex[minToRemove:maxToRemove]
        indexToRemove <- indexToRemove[!is.na(indexToRemove)]
        
        modelvars <- as.character(params$Variable)
        modelvars <- gsub(pattern=" ",replacement="", modelvars)
        modelvars <- modelvars["intercept" != modelvars]
        modelvars <- modelvars["(Intercept)" != modelvars]
        
        form <- formula(paste("y~",paste(modelvars,collapse="+"),sep=""))
        y <- df[-indexToRemove,response] + yadd
        m2<-lm(form,data=df[-indexToRemove,]) 
      
        if(length(coef(m2))>1){
          
          par(mar=c(5,4,8,8))
              
          intercept <- coef(m2)[1]
          df.model <- df[indexToRemove,modelvars]
      
          predictions <- as.numeric(predict.lm(object=m2,newdata=df.model))
          
          predictions <- 10^(predictions)
          y <- 10^(df[indexToRemove,response] + yadd)
    
          colors <- ifelse(y>EPAthresh & predictions>thresh,"blue","skyblue")
          colors <- ifelse(y>EPAthresh & predictions<thresh,"darkorange1",colors)
          colors <- ifelse(y<EPAthresh & predictions<thresh,"springgreen4",colors)
          colors <- ifelse(y<EPAthresh & predictions>thresh,"purple1",colors)
          fullColors <- append(fullColors,colors)
          sensitivity <- sum(sum(fullColors=="blue")/sum(y>EPAthresh))
          specificity <- sum(sum(fullColors=="springgreen4")/sum(y<EPAthresh))
        
          fullSens <- append(fullSens, sensitivity)
          fullSpec <- append(fullSpec, specificity)
          
          if (1 == i){
            plot(predictions~y,xlab="Observations (MPN/100mL)",ylab="Predictions (MPN/100mL)",
                 pch=20,ylim=ylims,xlim=ylims,col=colors, log="xy")
            abline(h=thresh,v=EPAthresh,lty=3,col="blue")
          } else {
            points(predictions~y, pch=20,col=colors)        
          }
        }
    
      }
      
      coefSign <- ifelse(coef(m2)[modelvars]>0,"+","-")
      
      for (j in length(modelvars):1){
        k<-length(modelvars)-j+1
        mtext(paste(coefSign[j],modelvars[j],sep=""),side=3,line=fsize*k,adj=0,cex=fsize)
      }
      
      fullSens <- sum(fullSens)/numWindows
      fullSpec <- sum(fullSpec)/numWindows
      mtext(paste(names(beach),", Model: ", method,": ",response,sep=""),line=0.,side=3,font=2)
      mtext(paste("Sensitivity =",round(fullSens,2)),side=4,line=2)
      mtext(paste("Specificity =",round(fullSens,2)),side=4,line=1)
      
      addLabel(paste("False pos =",sum(fullColors=="purple1")), x=0.15, y=.93)
      addLabel(paste("Correct pos =",sum(fullColors=="blue")), x=0.85, y=.93)
      addLabel(paste("Correct neg =",sum(fullColors=="springgreen4")), x=0.15, y=.05)
      addLabel(paste("False neg =",sum(fullColors=="darkorange1")), x=0.85, y=.05)
      
    }
    
    
    if (beachRegType == "censReg"){
    
      numWindows <- 5
      fraction <- 1/numWindows
      fullColors <- vector()
      fullSens <-  vector()
      fullSpec <-  vector()
      
      for (i in 1:numWindows){
        
        numObs <- nrow(df)
        minToRemove <- floor(numObs*fraction*(i-1))+i
        maxToRemove <- floor(numObs*fraction*i)+i
        indexToRemove <- randomIndex[minToRemove:maxToRemove]
        indexToRemove <- indexToRemove[!is.na(indexToRemove)]
      
        modelvars <- as.character(params$Variable)
        modelvars <- gsub(pattern=" ",replacement="", modelvars)
        modelvars <- modelvars["(Intercept)" != modelvars]
        modelvars <- modelvars["logSigma" != modelvars]
        
        form <- formula(paste("y~",paste(modelvars,collapse="+"),sep=""))
        y <- df[-indexToRemove,response] + yadd
    
        m2<-censReg(form,left=log(yadd),right=round(log10(2419.6),3),dat=df[-indexToRemove,]) #left and right censored regression
        
      
        if(length(coef(m2))>1){
      
          par(mar=c(5,4,8,8))
          
          y <- 10^(df[indexToRemove,response] + yadd)
          intercept <- coef(m2)[1]
          df.model <- df[indexToRemove,modelvars]
          
          predictions <- as.matrix(df.model) %*% coef(m2)[modelvars] + intercept
          
          predictions <- 10^(predictions)
          residuals.Cens <- predictions-y
          colors <- ifelse(y>EPAthresh & predictions>thresh,"blue","skyblue")
          colors <- ifelse(y>EPAthresh & predictions<thresh,"darkorange1",colors)
          colors <- ifelse(y<EPAthresh & predictions<thresh,"springgreen4",colors)
          colors <- ifelse(y<EPAthresh & predictions>thresh,"purple1",colors)
    
          if (1 == i){
            plot(predictions~y,xlab="Observations (MPN/100mL)",ylab="Predictions (MPN/100mL)",
                 pch=20,ylim=ylims,xlim=ylims,col=colors, log="xy")
            abline(h=thresh,v=EPAthresh,lty=3,col="blue")
          } else {
            points(predictions~y,pch=20,col=colors)
          }
          fullColors <- append(fullColors,colors)
          sensitivity <- sum(sum(fullColors=="blue")/sum(y>EPAthresh))
          specificity <- sum(sum(fullColors=="springgreen4")/sum(y<EPAthresh))
          
          fullSens <- append(fullSens, sensitivity)
          fullSpec <- append(fullSpec, specificity)
        }
      }
        
      coefSign <- ifelse(coef(m2)[modelvars]>0,"+","-")
      for (j in length(modelvars):1){
        k<-length(modelvars)-j+1
        mtext(paste(coefSign[j],modelvars[j],sep=""),side=3,line=fsize*k,adj=0,cex=fsize)
      }
      
      mtext(paste(names(beach),", Model: ", method,": ",response,sep=""),line=0.,side=3,font=2)
      
      fullSens <- sum(fullSens)/numWindows
      fullSpec <- sum(fullSpec)/numWindows
      mtext(paste(names(beach),", Model: ", method,": ",response,sep=""),line=0.,side=3,font=2)
      mtext(paste("Sensitivity =",round(fullSens,2)),side=4,line=2)
      mtext(paste("Specificity =",round(fullSens,2)),side=4,line=1)
      
      addLabel(paste("False pos =",sum(fullColors=="purple1")), x=0.15, y=.93)
      addLabel(paste("Correct pos =",sum(fullColors=="blue")), x=0.85, y=.93)
      addLabel(paste("Correct neg =",sum(fullColors=="springgreen4")), x=0.15, y=.05)
      addLabel(paste("False neg =",sum(fullColors=="darkorange1")), x=0.85, y=.05)
        
    }
  }
}
dev.off()

##################################################################################
##################################################################################
##################################################################################
pdf("modelSummary3.pdf")

modeltype <- "Recalibrated"
if(modeltype == "Recalibrated"){
#   pdf("RecalibratedTest.pdf")
  
  method <- "Recalibrated"
  modelID <- "recalibrated"
  modelvars <- as.character(params$Variable.header[which(modelID == params$Model.ID)])
  
  coefficients <- as.numeric(as.character(params$coeffcient[which(modelID == params$Model.ID)]))
  names(coefficients) <- modelvars
  
  modelvars <- modelvars["intercept" != modelvars]
  
  par(mar=c(5,4,8,8))
  df.model <- as.data.frame(df[,modelvars])
  
  predictions <- as.matrix(df.model) %*% coefficients[modelvars] + coefficients["intercept"]
  predictions <- 10^(predictions)
  
  colors <- ifelse(y>EPAthresh & predictions>thresh,"blue","skyblue")
  colors <- ifelse(y>EPAthresh & predictions<thresh,"darkorange1",colors)
  colors <- ifelse(y<EPAthresh & predictions<thresh,"springgreen4",colors)
  colors <- ifelse(y<EPAthresh & predictions>thresh,"purple1",colors)
  sensitivity <- sum(sum(colors=="blue")/sum(y>EPAthresh))
  specificity <- sum(sum(colors=="springgreen4")/sum(y<EPAthresh))
  
#   ylims <- round(range(c(y,predictions)*2)+c(0,0.5),0)/2
#   ylims <- c(0,3.5)
  ylims <- c(1,1000)
  plot(predictions~y,xlab="Observations (MPN/100mL)",ylab="Predictions (MPN/100mL)",
       pch=20,ylim=ylims,xlim=ylims,col=colors, log="xy")
  abline(h=thresh,v=EPAthresh,lty=3,col="blue")
  #        abline(0,1)
  coefSign <- ifelse(coefficients[modelvars]>0,"+","-")
  for (j in length(modelvars):1){
    k<-length(modelvars)-j+1
    mtext(paste(coefSign[j],modelvars[j],sep=""),side=3,line=fsize*k,adj=0,cex=fsize)
  }
  mtext(paste(method,": ",response,sep=""),line=0.,side=3,font=2)
  
  addLabel(paste("False pos =",sum(colors=="purple1")), x=0.1, y=.93)
  addLabel(paste("Correct pos =",sum(colors=="blue")), x=0.85, y=.93)
  addLabel(paste("Correct neg =",sum(colors=="springgreen4")), x=0.1, y=.05)
  addLabel(paste("False neg =",sum(colors=="darkorange1")), x=0.85, y=.05)
  
  mtext(paste("Sensitivity =",round(sensitivity,2)),side=4,line=2)
  mtext(paste("Specificity =",round(specificity,2)),side=4,line=1)
  
  
#   dev.off()
}


modeltype <- "Persistance"
if(modeltype == "Persistance"){

#   pdf("PersistanceTest.pdf")
  
  method <- "Persistance"
  par(mar=c(5,4,8,8))
  
  predictions <- y[-1]
  observation <- y[-length(y)]

  colors <- ifelse(observation>EPAthresh & predictions>thresh,"blue","skyblue")
  colors <- ifelse(observation>EPAthresh & predictions<thresh,"darkorange1",colors)
  colors <- ifelse(observation<EPAthresh & predictions<thresh,"springgreen4",colors)
  colors <- ifelse(observation<EPAthresh & predictions>thresh,"purple1",colors)
  sensitivity <- sum(sum(colors=="blue")/sum(y>EPAthresh))
  specificity <- sum(sum(colors=="springgreen4")/sum(y<EPAthresh))
#   ylims <- round(range(c(observation,predictions)*2)+c(0,0.5),0)/2
  plot(predictions~observation,xlab="Observations (MPN/100mL)",ylab="Predictions (MPN/100mL)",
       pch=20,ylim=ylims,xlim=ylims,col=colors, log="xy")
  abline(h=thresh,v=EPAthresh,lty=3,col="blue")

  mtext(paste(method,": ",response,sep=""),line=0.,side=3,font=2)
  
  addLabel(paste("False pos =",sum(colors=="purple1")), x=0.1, y=.93)
  addLabel(paste("Correct pos =",sum(colors=="blue")), x=0.85, y=.93)
  addLabel(paste("Correct neg =",sum(colors=="springgreen4")), x=0.1, y=.05)
  addLabel(paste("False neg =",sum(colors=="darkorange1")), x=0.85, y=.05)
  
  mtext(paste("Sensitivity =",round(sensitivity,2)),side=4,line=2)
  mtext(paste("Specificity =",round(specificity,2)),side=4,line=1)
  
#   dev.off()

}

modeltype <- "CEN"
if(modeltype == "CEN"){
  
  y <- df[,response]
  yadd <- 1
  
  
  
  modelID <- "CEN-script"
  modelvars <- as.character(params$Variable.header[which(modelID == params$Model.ID)])
  modelvars <- modelvars["intercept" != modelvars]
  
  form <- formula(paste("y~",paste(modelvars,collapse="+"),sep=""))

  m2<-censReg(form,left=log(yadd),right=round(log10(2419.6),3),dat=df) #left and right censored regression
  

#   pdf("CenTest.pdf")
  if(length(coef(m2))>1){
    method <- "Censored"
    par(mar=c(5,4,8,8))
    
    y <- 10^(y)
    intercept <- coef(m2)[1]
    df.model <- as.data.frame(df[,modelvars])

    predictions <- as.matrix(df.model) %*% coef(m2)[modelvars] + intercept
    
    predictions <- 10^(predictions)
    residuals.Cens <- predictions-y
    colors <- ifelse(y>EPAthresh & predictions>thresh,"blue","skyblue")
    colors <- ifelse(y>EPAthresh & predictions<thresh,"darkorange1",colors)
    colors <- ifelse(y<EPAthresh & predictions<thresh,"springgreen4",colors)
    colors <- ifelse(y<EPAthresh & predictions>thresh,"purple1",colors)
    sensitivity <- sum(sum(colors=="blue")/sum(y>EPAthresh))
    specificity <- sum(sum(colors=="springgreen4")/sum(y<EPAthresh))
    
#     ylims <- round(range(c(y,predictions)*2)+c(0,0.5),0)/2
    plot(predictions~y,xlab="Observations (MPN/100mL)",ylab="Predictions (MPN/100mL)",
         pch=20,ylim=ylims,xlim=ylims,col=colors, log="xy")
    abline(h=thresh,v=EPAthresh,lty=3,col="blue")
    #        abline(0,1)
    coefSign <- ifelse(coef(m2)[modelvars]>0,"+","-")
    for (j in length(modelvars):1){
      k<-length(modelvars)-j+1
      mtext(paste(coefSign[j],modelvars[j],sep=""),side=3,line=fsize*k,adj=0,cex=fsize)
    }
    mtext(paste(method,": ",response,sep=""),line=0.,side=3,font=2)
   
    addLabel(paste("False pos =",sum(colors=="purple1")), x=0.1, y=.93)
    addLabel(paste("Correct pos =",sum(colors=="blue")), x=0.85, y=.93)
    addLabel(paste("Correct neg =",sum(colors=="springgreen4")), x=0.1, y=.05)
    addLabel(paste("False neg =",sum(colors=="darkorange1")), x=0.85, y=.05)
    
    mtext(paste("Sensitivity =",round(sensitivity,2)),side=4,line=2)
    mtext(paste("Specificity =",round(specificity,2)),side=4,line=1)
    
  }
#   dev.off()
}

dev.off()



# if(modeltype == "OLS"){
#   
#   form <- formula(paste("y~",paste(Modelvars,collapse="+"),sep=""))
#   m2<-lm(form,dat=df) #Ordinary Least Squares model
#   
#   # Graph traditional OLS Stepwise regression results
#   if(length(coef(m2))>1){
#     method <- "OLS"
#     par(mar=c(5,4,8,8))
#     intercept <- coef(m2)[1]
#     df.model <- as.data.frame(testdf[,modelvars])
#     df.predict <- as.data.frame(df.model)
#     predictions <- as.matrix(df.model) %*% coef(m2)[modelvars] + intercept
#     residuals.ols <- predictions-y
#     colors <- ifelse(y>EPAthresh & predictions>thresh,"blue","skyblue")
#     colors <- ifelse(y>EPAthresh & predictions<thresh,"darkorange1",colors)
#     colors <- ifelse(y<EPAthresh & predictions<thresh,"springgreen4",colors)
#     colors <- ifelse(y<EPAthresh & predictions>thresh,"purple1",colors)
#     sensitivity <- sum(sum(colors=="blue")/sum(y>EPAthresh))
#     specificity <- sum(sum(colors=="springgreen4")/sum(y<EPAthresh))
#     #        ylims <- round(range(c(y,predictions)*2)+c(0,0.5),0)/2
#     plot(predictions~y,xlab="Observations (gc/L)",ylab="Predictions (gc/L)",
#          pch=20,ylim=ylims,xlim=ylims,col=colors)
#     abline(h=thresh,v=EPAthresh,lty=3,col="blue")
#     #        abline(0,1)
#     coefSign <- ifelse(coef(m2)[modelvars]>0,"+","-")
#     for (j in length(modelvars):1){
#       k<-length(modelvars)-j+1
#       mtext(paste(coefSign[j],modelvars[j],sep=""),side=3,line=fsize*k,adj=0,cex=fsize)
#     }
#     mtext(paste(method,": ",response[i],sep=""),line=0.1,side=3,font=2)
#     text(x=ylims[2],y=ylims[2],labels=paste("Correct pos =",sum(colors=="blue")),adj=c(0.9,0.5,1))
#     text(x=ylims[1],y=ylims[2],labels=paste("False pos =",sum(colors=="purple1")),adj=c(0.1,0.5,1))
#     text(x=ylims[1],y=ylims[1],labels=paste("Correct neg =",sum(colors=="springgreen4")),adj=c(0.1,0.5,1))
#     text(x=ylims[2],y=ylims[1],labels=paste("False neg =",sum(colors=="darkorange1")),adj=c(0.9,0.5,1))
#     mtext(paste("Sensitivity =",round(sensitivity,2)),side=4,line=2)
#     mtext(paste("Specificity =",round(specificity,2)),side=4,line=1)
#     
#   }
# }