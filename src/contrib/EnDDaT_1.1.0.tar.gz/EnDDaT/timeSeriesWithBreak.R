library(censReg)
library(plotrix)

#Set WD for development
setwd("M:/QW Monitoring Team/GLRI beaches/Modeling/EnDDaT modeling results/R Codes/2013")

beach  <- "TH2.0"
filetype <- c("MaxRowsTurb")  #,"MaxCols","MaxRows","EnDDaT")
filenm <- paste(beach,filetype,"csv",sep=".")
#load("TH2.0.MaxRowsTurbModelObjects.Rdata")

#Read beach data file
df <- read.csv(filenm)
params <- read.csv("modelParameters.csv")


#Define response variable
response <- "log_beach_EColi"
y <- df[,response]
yadd <- 1


EPAthresh <- log10(235)
thresh <- 2.25
fsize <- 0.8

addLabel <- function(labelString, x=0.10, y=0.93) {
  x1 <- grconvertX(x, from="npc", to="user")
  y1 <- grconvertY(y, from="npc", to="user")  
  text(x=x1, y=y1, labelString, cex=.7)
}


plotSeasonBreak <- function(predictions,dateToPlot,method,y,EPAthresh=log10(235),thresh=2.25){
  
  predictions <- 10^(predictions)
  EPAthresh <- 10^(EPAthresh)
  thresh <- 10^(thresh)
  y <- 10^(y)
  
#   ylims <- c(0,3.5)
  ylims <- c(1, 1000)
  
  numberOfDays <- as.POSIXlt(dateToPlot)
  numberOfDays <- numberOfDays$yday
  
  colors <- ifelse(y>EPAthresh & predictions>thresh,"blue","skyblue")
  colors <- ifelse(y>EPAthresh & predictions<thresh,"darkorange1",colors)
  colors <- ifelse(y<EPAthresh & predictions<thresh,"springgreen4",colors)
  colors <- ifelse(y<EPAthresh & predictions>thresh,"purple1",colors)
  
#   x <- seq(1:length(predictions))
  
  index <- dateToPlot<as.POSIXct("2011",format='%Y')
  indexCount <- (numberOfDays[index]- min(numberOfDays[index]))+1
  
  newIndex <- (dateToPlot < as.POSIXct("2012",format='%Y') & dateToPlot > as.POSIXct("2011",format='%Y'))
  newCount <- (numberOfDays[newIndex]-min(numberOfDays[newIndex]) + max(indexCount))+1
    
  newIndex2 <- (dateToPlot > as.POSIXct("2012",format='%Y'))
  lastCount <- (numberOfDays[newIndex2]-min(numberOfDays[newIndex2]) + max(newCount))+1
  
  x <- c(indexCount,newCount,lastCount)
  
  firstZig <- x[min(which(newIndex))]
  secondZig<- x[max(which(newIndex))]
         
  
  plot(predictions[index]~ x[index],xlab="Beach Season",ylab="Predictions (MPN/100mL)",
       pch=20,ylim=ylims, xlim=c(0,max(x)),col=colors[index],axes=FALSE,log="y")
  
  
  points(predictions[newIndex] ~ x[newIndex],
         pch=20,ylim=ylims, xlim=c(0,length(predictions)),col=colors[newIndex])  
  
  points(predictions[newIndex2] ~ x[newIndex2],
         pch=20,ylim=ylims, xlim=c(0,length(predictions)),col=colors[newIndex2])  
  
  box()
  axis(2, at=c(1,10,100,1000),labels=c(1,10,100,1000))
#   axis(2, at=seq(0,3.5,length=8),labels=seq(0,3.5,length=8))

  axis(1, at=c(firstZig/2,(secondZig+firstZig)/2,(max(x)+secondZig)/2),labels=c("2010","2011","2012"))
  
  axis.break(axis=1, firstZig, style="slash",brw=0.03)
  axis.break(axis=1, secondZig, style="slash",brw=0.03)
  
  abline(h=thresh,lty=2,col="blue")
  abline(v=firstZig,lty=2,col="black")
  abline(v=secondZig,lty=2,col="black")  
  mtext(method, line=-1.5,side=3,cex=0.8)  
}

pdf("timeSeriesSummary10_new.pdf")
layout(matrix(c(1,2,3),nrow=3,ncol=1))
par(oma=c(4,0.1,3,0.1),mar=c(2,4,1,1))
ylims <- c(0,3.5)


modeltype <- "Recalibrated"
if(modeltype == "Recalibrated"){
  #   pdf("RecalibratedTest.pdf")
  
  method <- "Recalibrated"
  modelID <- "recalibrated"
  modelvars <- as.character(params$Variable.header[which(modelID == params$Model.ID)])
  
  coefficients <- as.numeric(as.character(params$coeffcient[which(modelID == params$Model.ID)]))
  names(coefficients) <- modelvars
  
  modelvars <- modelvars["intercept" != modelvars]
  
  #   par(mar=c(5,4,8,8))
  df.model <- as.data.frame(df[,modelvars])
  
  predictions <- as.matrix(df.model) %*% coefficients[modelvars] + coefficients["intercept"]
  
  dateToPlot <- as.POSIXct(sapply(strsplit(as.character(df$surveyDatetime)," "), function(x) x[1]),format='%m/%d/%Y')
  
  plotSeasonBreak(predictions, dateToPlot, method, y)
  
  x1 <- grconvertX(.86, from="npc", to="user")
  y1 <- grconvertY(.99, from="npc", to="user") 
  
  legend(x1,y1,
         c("False Positive", "False Negative", "True Positive", "True Negative"),
         col=c("purple1","darkorange1","blue","springgreen4"),pch=20,bg="white",cex=0.9)

  #   dev.off()
}


modeltype <- "Persistance"
if(modeltype == "Persistance"){
  
  #   pdf("PersistanceTest.pdf")
  
  method <- "Persistance"
  #   par(mar=c(5,4,8,8))
  
  predictions <- y[-1]
  observation <- y[-length(y)]
    
  dateToPlot <- as.POSIXct(sapply(strsplit(as.character(df$surveyDatetime)," "), function(x) x[1]),format='%m/%d/%Y')
  dateToPlot <- dateToPlot[-length(dateToPlot)]
  
  plotSeasonBreak(predictions, dateToPlot, method, observation)
  
  #   dev.off()
  
}

modeltype <- "CEN"
if(modeltype == "CEN"){
  
  modelID <- "CEN-script"
  modelvars <- as.character(params$Variable.header[which(modelID == params$Model.ID)])
  modelvars <- modelvars["intercept" != modelvars]
  
  form <- formula(paste("y~",paste(modelvars,collapse="+"),sep=""))
  m2<-censReg(form,left=log(yadd),right=round(log10(2419.6),3),dat=df) #left and right censored regression
  
  dateToPlot <- as.POSIXct(sapply(strsplit(as.character(df$surveyDatetime)," "), function(x) x[1]),format='%m/%d/%Y')
  
  #   pdf("CenTest.pdf")
  if(length(coef(m2))>1){
    method <- "Censored"
    #     par(mar=c(5,4,8,8))
    intercept <- coef(m2)[1]
    df.model <- as.data.frame(df[,modelvars])
    
    predictions <- as.matrix(df.model) %*% coef(m2)[modelvars] + intercept
    
    plotSeasonBreak(predictions, dateToPlot, method,y)
    mtext("Beach Season", side=1, line=2.5,cex=0.8)

  }
  #   dev.off()
}

title("Thompson",outer=TRUE)
# title("Thompson",outer=TRUE)
dev.off()
