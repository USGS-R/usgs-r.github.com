library("EnDDaT")
library("rjson")

fileName <- "MA_PRESS.csv"
filePath <- "//igsarmewfsapa/projects/QW Monitoring Team/GLRI beaches/Modeling/Models for 2013 season/2013 Models/Current"

totalParams <- getParamsFromFile(filePath, fileName)

beachName <- totalParams$Descriptor['BEACH' == totalParams$Source]
beachID <- beachKey$BEACH_ID[beachName == beachKey$BEACH_NAME]
lake <- beachKey$lake[beachName == beachKey$BEACH_NAME]
tzone <- '-6_CST'
gap <- 6
rmseValue <- totalParams$Coefficient['RMSE' == totalParams$Source]
threshValue <- totalParams$Coefficient['THRESHOLD' == totalParams$Source]
biasValue <- totalParams$Coefficient['BIAS' == totalParams$Source]
fileValue <- totalParams$Descriptor['FILE' == totalParams$Source]
emailList <- totalParams$Descriptor['EMAIL' == totalParams$Source]

termSet <- totalParams[('NWIS' == totalParams$Source) | 
                         ('GLCFS' == totalParams$Source) | 
                         ('GEN' == totalParams$Source) |
                         ('GDP' == totalParams$Source) |
                         ('INTERCEPT' == totalParams$Source),]

terms <- list()

for (i in 1:nrow(termSet)){
  c <- termSet$Coefficient[i]
  type <- termSet$Source[i]  
  
  transform <- termSet$Transform[i]
  stat <- termSet$Statistic[i]
  time <- termSet$Hours[i]
  descText <- termSet$Description[i]
  varName <- termSet$colName[i]
  typeName <- switch(type,
                     GLCFS = "GLCFS data:",
                     NWIS = "NWIS data",
                     GDP = "GDP data",
                     GEN = "Manually entered data:")
  
  if ("GEN" == type){
    if ("LOG" == transform){
      configText <- "Log10:Log10::${"
    } else {
      configText <- "Literal:Literal::${"
    }
  }
  
  
  x <- switch(type,
              GLCFS = list(ds = "GRID",
                           config=sapply(strsplit(unlist(dataRequest(termSet[i,])['GLCFSCalls'],use.names=FALSE),"="), function(x) x[2]),
                           base=list(paste("Lake=",lake,sep="")),
                           postProc = transform
                           ),
              NWIS = list(ds = "NWIS",
                          config=sapply(strsplit(unlist(dataRequest(termSet[i,])['NWISCalls'],use.names=FALSE),"="), function(x) x[2]),
                          postProc = transform
                          ),
              GDP = list(ds = "GDP",
                         config=paste("precip4",stat,time,sep=":"),
                         base=c("gdpId=ancrfcqpe_w_meta.ncml:MEAN:", paste("shapefile=upload:", termSet[i,"Shapefile"],sep=""),"shapefileFeature=AREA")
                         ),
              GEN = list(ds= "GEN",
                         config=paste(configText,"XXXXXXXXXXXXXXX","}",sep="")
                         ),
              INTERCEPT = list(lit = 1)
              
              )
  
  description <- list(name = typeName,
                      description = descText,
                      variableName = varName,
                      hours = time,
                      transform = transform
                )
  
  terms[[i]] <- list(c=c,x=x,description=description)
}

headerList <- list(name = beachName,
                   beachID = beachID,
                   outputName = "logEC",
                   rmse = rmseValue,
                   threshold = threshValue,
                   bias = biasValue,
                   runDateTime = "${surveyDateTime}",
                   fileName = fileValue,
                   resultRecipients = emailList,
                   terms=terms)
setwd(filePath)
sink(paste(beachName,".txt",sep=""))
cat(toJSON(headerList))
sink()
