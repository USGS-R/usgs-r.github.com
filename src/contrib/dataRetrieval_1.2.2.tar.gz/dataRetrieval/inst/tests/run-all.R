library(testthat)
library(dataRetrieval)

test_package("dataRetrieval")