## ----openLibrary, echo=FALSE------------------------------
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)



## ----include=TRUE ,echo=FALSE,eval=TRUE-------------------
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, concordance=TRUE,tidy=FALSE,comment="")
knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)

## ----workflow,eval = TRUE---------------------------------
library(geoknife)

## ----workflowNotRun,eval = FALSE,echo=TRUE----------------
#  # create geoknife object w/ defaults
#  geoknife <- geoknife()
#  # give this geoknife object a linear ring as the
#  # feature of interest (will be adding multiple rings in the future)
#  linearRing = bufferPoint(c(-111.48,36.95))
#  geoknife <- setFeature(geoknife,list(LinearRing=linearRing))
#  
#  # get a list of available processing algorithms
#  getAlgorithms(geoknife)
#  
#  # set processing algorithm to feature weighted grid statistics
#  # feature weighted:
#  geoknife <- setAlgorithm(geoknife,getAlgorithms(geoknife)[4])
#  
#  # set the post inputs for the processing dataset
#  geoknife <- setProcessInputs(geoknife,
#     list('DATASET_ID'='Downward_longwave_radiation_flux_surface',
#     'DATASET_URI'='dods://igsarm-cida-thredds1.er.usgs.gov:8081/qa/thredds/dodsC/nldas/best',
#     'TIME_START'='2010-01-01T00:00:00Z',
#     'TIME_END'='2010-01-01T23:00:00Z',
#     'DELIMITER'='TAB'))
#  
#  # printing geoknife object displays the important properties in a readable way
#  geoknife
#  # is the same as
#  print(geoknife)
#  
#  # kick off your request
#  geoknife <- startProcess(geoknife)
#  
#  status.geoknife <- checkProcess(geoknife)
#  
#  cat('checking status of GDP request.
#      Large complex requests take longer to process.\n')
#  
#  repeat{
#    if (!is.null(status.geoknife$URL) | status.geoknife$status!=""){
#      break
#    }
#    cat('checking process...\n')
#    Sys.sleep(10)
#    if (is.null(status.geoknife$URL)){
#      status.geoknife <- checkProcess(geoknife)
#    }
#  }
#  
#  if (status.geoknife$status=='Process successful'){
#    cat(paste(status.geoknife$status,
#              '\nDownload available at: ',status.geoknife$URL,sep=''))
#  } else {
#    cat(status.geoknife$status)
#  }

