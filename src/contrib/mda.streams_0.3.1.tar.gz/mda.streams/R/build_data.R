# runs on package build. Need to fix for windows...
if (file.exists('~/Documents/R/mda.streams/inst/init_data.R')){
  source('~/Documents/R/mda.streams/inst/init_data.R')
}
