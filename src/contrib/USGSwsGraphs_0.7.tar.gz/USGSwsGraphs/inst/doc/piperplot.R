### R code from vignette source 'piperplot.Rnw'

###################################################
### code chunk number 1: piperplot.Rnw:23-43
###################################################
# Load the USGSwsGraphs package
library(USGSwsGraphs)
# Generate a random sample for the piper plot. The first 15 points
#  are dominated by sodium chloride, the second 12 are dominated by
#  calcium bicarbonate. The example will only use 3 cations and
#  3 anions instead of the usual sets. And no effort is made to construct
#  an ion balance.
set.seed(2727)
# Piper plot and Stiff diagram data
PD <- data.frame(Ca = c(runif(15, 10, 30), runif(12, 20, 50)),
                 Mg = c(runif(15, 5, 15), runif(12, 8, 20)),
		 Na = c(runif(15, 30, 50), runif(12, 8, 20)),
		 Cl = c(runif(15, 35, 60), runif(12, 10, 25)),
		 SO4 = c(runif(15, 5, 15), runif(12, 5, 10)),
		 HCO3 = c(runif(15, 30, 50), runif(12, 50, 90)),
		 Type = rep(c("NaCl", "CaHCO3"), c(15, 12)))
# Ternary diagram data
X <- runif(25, .1, 1.)
Y <- runif(25, .1, .8)
Z <- runif(25, .3, 1.)


###################################################
### code chunk number 2: piperplot.Rnw:56-79
###################################################
PD <- transform(PD, Ca.meq = conc2meq(Ca, "calcium"),
                    Mg.meq = conc2meq(Mg, "magnesium"),
		    Na.meq = conc2meq(Na, "sodium"),
		    Cl.meq = conc2meq(Cl, "chloride"),
		    SO4.meq = conc2meq(SO4, "sulfate"),
		    HCO3.meq = conc2meq(HCO3, "bicarb")) # abbreviations allowed
# setSweave is a specialized function that sets up the graphics page for
# Sweave scripts. It should be replaced by a call to setPage or setPDF 
# in a regular script.
# The minimum page size for a Piper plot is 7 inches. No check is made,
#  but the axis title spacings require a graph area of at least 6 inches.
setSweave("piperplot01", 7, 7)
# For this example, a separate graph area for an explanation is not needed
#  because there are only 2 groups.
AA.pl <- with(PD, piperPlot(Ca.meq, Mg.meq, Na.meq, 
	               Cl.meq, HCO3.meq, SO4.meq,
		       Plot=list(name=Type, color=setColor(Type)),
		       zCat.title = "Sodium",
		       xAn.title = "Chloride",
		       yAn.title = "Bicarbonate"))
addExplanation(AA.pl, where="ul", title="")
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 3: piperplot.Rnw:81-83
###################################################
cat("\\includegraphics{piperplot01.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 4: piperplot.Rnw:95-100
###################################################
setSweave("piperplot02", 6, 6)
# Accept all defaults
ternaryPlot(X, Y, Z)
# Required call to close PDF output graphics 
graphics.off() 


###################################################
### code chunk number 5: piperplot.Rnw:102-104
###################################################
cat("\\includegraphics{piperplot02.pdf}\n")
cat("\\paragraph{}\n") 


###################################################
### code chunk number 6: piperplot.Rnw:115-125
###################################################
setSweave("piperplot03", 6, 6)
AA.lo <- setLayout(height=3.5, explanation=list(bottom=1))
setGraph(1, AA.lo)
# Accept all defaults, but subset the data for the small graph size
AA.pl <- with(PD[c(1,2,3,21,22), ], stiffPlot(cbind(Ca.meq, Mg.meq, Na.meq),
         cbind(Cl.meq, SO4.meq, HCO3.meq)))
setGraph("explanation", AA.lo)
addExplanation(AA.pl)
# Required call to close PDF output graphics 
graphics.off() 


###################################################
### code chunk number 7: piperplot.Rnw:127-129
###################################################
cat("\\includegraphics{piperplot02.pdf}\n")
cat("\\paragraph{}\n") 


