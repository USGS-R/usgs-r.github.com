library(Rainmaker)
#Rainmaker examples

RDB <- CedarRRain[-3]
names(RDB)[2] <- "UVRain"

#Convert RDB dates/times to POSIXct with RMprep
RDB2 <- RMprep(RDB,prep.type=1,date.type=1,dates.in="CST.Time",tz="CST6CDT")


#RMevents function: Determine rainfall with specified interevent period and rain threshold
#Choose interevent period of 6 hours and rain threshold of 5 mm (0.2 in) for this example
event.list <- RMevents(df=RDB2,
                       ieHr=6,
                       rainthresh=5,
                       rain="UVRain")

#This results in a "list" with two dataframes. One with all storms and one with
#only events > 0.2 inches. 
names(event.list)

#Extract dataframe for storms > 0.2 inches
events5 <- event.list$storms2

#Extract dataframe for all storms
events.all <- event.list$storms

#RMeventsSamples function:  Compute rainfall event variables based on time 
#series of rain data with only one rain gage or one mean radar rain column, 
#and the beginning and ending dates of sampling periods
#load("M:/QW Monitoring Team/R_fxns/R_class/Packages/Rainmaker/data/cedarSamples.RData")
#source('M:/QW Monitoring Team/R_fxns/R_class/Packages/Rainmaker/R/RMeventsSamples.R')

cedarSamples <- cedarSamples
event.list.samples <- RMeventsSamples(df=RDB2,
                                      ieHr=6,
                                      rain="UVRain",
                                      dfsamples=cedarSamples,
                                      bdate="pSstart",
                                      edate="pSend")

events.0.2 <- event.list$storms2


#RMIntense: Define maximum X-minute rainfall intensities for rainfall events 
#Choose 5-min, 15-min, and 30-min intensities
intensities <- RMIntense(df=RDB2,
                         date="pdate",
                         rain="UVRain",
                         events5,
                         sdate="StartDate",
                         edate="EndDate",
                         depth="rain",
                         xmin=c(5,15,30))

#ARFrain: Define antecedent rainfall for specified dates and times
#Use the beginning of each rainfall event period for this example
#Define antecedent rain for 1-, 3-, and 5-day time windows
ARFrain <- RMarf(df=RDB2,
                 date="pdate",
                 rain="UVRain",
                 df.events=intensities,
                 sdate="StartDate",
                 days=c(1,3,5),
                 varnameout="ARF")

#Graph rainfall event depths, one plot per event
pdf("events.pdf")

RMevents.plot(RDB2,date="pdate",
              rain="UVRain",
              df.events=events5,
              sdate="StartDate",
              "EndDate",
              depth= "rain",
              plot.buffer=2,
              site.name="Example Site")

dev.off()
shell.exec("events.pdf")




dfQ <- cedarq
dfQ <- RMprep(dfQ,prep.type=1,date.type=3,tz="CST6CDT")
site.name <- "Example Site"
pdf(paste(site.name,"_events.pdf",sep=""))
RMevents.plotQ(df=RDB2,
               dfQ=dfQ,
               rain="UVRain",
               df.events=events5,
               erain="rain",
               plot.buffer=10,
               logy="y",
               site.name=site.name)
dev.off()
shell.exec(paste(site.name,"_events.pdf",sep=""))



#NEXT FUNCTION IN RAINMAKER IS IN DEVELOPMENT:
#RMeventsSamples
#
## Function RMevents

#Compute rainfall event variables based on time series of rain data with only one rain
#gage or one mean radar rain column. Use beginning and ending dates specified for
#storm periods (defined by hydrograph or sample collection times
#


#DO NOT USE MATERIAL BELOW THIS

source("fxn_RMeventsSamples.R")
##########################################################################################
## Function RMevents

#Compute rainfall event variables based on time series of rain data with only one rain
#gage or one mean radar rain column. Use beginning and ending dates specified for
#storm periods (defined by hydrograph or sample collection times
#
# Usage: RMeventsSamples  (df,             # Data frame with rainfall
#                  ieHr=6,          # Interevent period in hours
#                  rain="rain",     # column of rainfall unit values
#                  time="pdate"     # column with POSIX date
#                  dfsamples,       # data frame with begin and end dates/times of hydrograph
#                 bdate="bpdate",   # begin date column name in dfsamples
#                 edate="epdate")   # end date column name in dfsamples
