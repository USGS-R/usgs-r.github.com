
source("fxn_RMeventsSamples.R")
##########################################################################################
## Function RMevents

#Compute rainfall event variables based on time series of rain data with only one rain
#gage or one mean radar rain column. Use beginning and ending dates specified for
#storm periods (defined by hydrograph or sample collection times
#
# Usage: RMeventsSamples  (df,             # Data frame with rainfall
#                  ieHr=6,          # Interevent period in hours
#                  rain="rain",     # column of rainfall unit values
#                  time="pdate"     # column with POSIX date
#                  dfsamples,       # data frame with begin and end dates/times of hydrograph
#                 bdate="bpdate",   # begin date column name in dfsamples
#                 edate="epdate")   # end date column name in dfsamples


#                  ) 
bdates <- as.POSIXct(c("2007-07-04 04:00","2007-08-07 00:05"),tz="CST6CDT")
bdates <- as.POSIXct(c("2007-07-04 04:00","2007-08-07 00:05"),format="%Y-%m-%d %H:%M",tz="CST6CDT")
edates <- as.POSIXct(c("2007-07-06 23:00","2007-08-09 23:55"),tz="CST6CDT")

dfsamples <- data.frame(bdates,edates)

RMeventsSamples(df=RDB2,
                ieHr=6,
                rain="UVRain",
                time="pdate",
                dfsamples=dfsamples,
                bdate="bdates",
                edate="edates")

df<-RDB2
ieHr<-6
rain<-"UVRain"
time="pdate"
dfsamples<-dfsamples
bdate<-"bdates"
edate<-"edates"


RMeventsSamples  (df,              # Data frame with rainfall
                  ieHr=6,          # Interevent period in hours
                  rainthresh=25    # minimum event depth in units of the rain column
                  # default is given as 5.1 assuming millimeters (0.2")
                  rain="rain",     # column of rainfall unit values
                  time="pdate"     # column with POSIX date
) 

