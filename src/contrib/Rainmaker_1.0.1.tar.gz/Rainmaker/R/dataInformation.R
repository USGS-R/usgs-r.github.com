#' cedarq
#'
#' Example data cedarq. Needs more info.
#'
#' @name cedarq
#' @docType data
#' @author Steve Corsi \email{srcorsi@@usgs.gov}
#' @keywords rainmaker
NULL

#' CedarRRain
#'
#' Example data CedarRRain. Needs more info.
#'
#' @name CedarRRain
#' @docType data
#' @author Steve Corsi \email{srcorsi@@usgs.gov}
#' @keywords rainmaker
NULL

#' cedarSamples
#'
#' Example data cedarSamples. Needs more info.
#'
#' @name cedarSamples
#' @docType data
#' @author Steve Corsi \email{srcorsi@@usgs.gov}
#' @keywords rainmaker
NULL

#' Rainmaker
#'
#' \tabular{ll}{
#' Package: \tab Rainmaker\cr
#' Type: \tab Package\cr
#' Version: \tab 1.0.0\cr
#' Date: \tab 2014-01-10\cr
#' License: \tab Unlimited for this package, dependencies have more restrictive licensing.\cr
#' Copyright: \tab This software is in the public domain because it contains materials
#' that originally came from the United States Geological Survey, an agency of
#' the United States Department of Interior. For more information, see the
#' official USGS copyright policy at
#' http://www.usgs.gov/visual-id/credit_usgs.html#copyright\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' Collection of functions..
#'
#' @name Rainmaker-package
#' @docType package
#' @author Steve Corsi \email{srcorsi@@usgs.gov}
NULL