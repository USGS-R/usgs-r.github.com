

install.packages("M:/QW Monitoring Team/R_fxns/R_class/Packages/Rainmaker.tar.gz",repos=NULL, type="source")

install.packages("GSHydroTools", repo="http://usgs-r.github.com")
