#'Plot 
#'
#'Create diagnostic plots for selected hypothesis tests.
#'
#'The \code{ppw} method for \code{plot} creates 2 graphs on a single page.
#'The first graph is the scaled differences from the PPT test with the mean
#'difference shown by a blue line. The second
#'graph is the actual differences in the paird values, assuming that the 
#'true minimum for left-censored data is 0. The median difference is shown
#'by a blue line.
#'
#'@aliases plot.htest plot.ppw
#'@usage \method{plot}{htest}(x, which = "All", set.up = TRUE, ...)
#'
#'\method{plot}{ppw}(x, which = "All", set.up = TRUE, labels, ...)
#'@param x an object having classes "htest" and some other class for which a
#'\code{plot} method exists.
#'@param which either "All" or an number indicating which plot,
#'see \bold{Details}.
#'@param set.up set up the graphics page?
#'@param labels use supplied values for y-axis labels instead of sequence
#'number. 
#'@param \dots further arguments passed to or from other methods.
#'@return The object \code{x} is returned invisibly.
#'@keywords hplot
#'@export
plot.htest <- function(x, which="All", set.up = TRUE, ...)
  ## Coding history:
  ##    2013Jan06 DLLorenz Initial Coding and start ppw
  ##    2013Jan21          This version
  NextMethod("plot")

#'@export
plot.ppw <- function(x, which="All", set.up = TRUE, labels, ...) {
  ## Identify which plots to do:
  ## 1: 2 graphs actual diffs and score diffs
  ## 
  ## Set up graphics page
  if(set.up) 
    setGD("PPW")
  ## Set up to do the plots, ignore which
  if(missing(labels))
    labels <- as.character(seq(nrow(x$PPWmat)))
  ## Guess at y-axis margin needed
  yleft <- (max(nchar(labels)) + 1) * .5 + 1.5
  AA.lo <- setLayout(num.cols=2, shared.y=1, yleft=yleft)
  Ord <- order(x$PPWmat[, 3L])
  AA.gr <- setGraph(1, AA.lo)
  dotPlot(x$PPWmat[Ord, 3L], labels[Ord], xtitle="PPW Scaled Difference",
          xlabels=5, margin=AA.gr)
  refLine(vertical=0)
  refLine(vertical=mean(x$PPWmat[, 3L]), Plot=list(color="blue"))
  AA.gr <- setGraph(2, AA.lo)
  mind <- x$PPWmat[Ord, 4L]
  maxd <- x$PPWmat[Ord, 5L]
  dotPlot(as.mcens(mind, maxd), labels[Ord], xtitle="Computed Difference",
          xlabels=5, margin=AA.gr)
  refLine(vertical=0)
  refLine(vertical=median(as.mcens(mind, maxd)), Plot=list(color="blue"))
  invisible(x)
}
