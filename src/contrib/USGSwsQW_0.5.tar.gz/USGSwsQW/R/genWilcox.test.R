#'Test for difference in left-censored samples
#'
#'This function tests for differences in left-censored samples from 2
#'groups.
#'
#'@param x the samples from each group. Forced to class "lcens." Missing values
#'are removed before the analysis.
#'@param y either another set of samples or a group identifier with exactly
#'two groups. Missing values are removed before the analysis.
#'@param alternative character string describing the alternative hypothesis.
#'Must be one of "two.sided, "greater," or "less."
#'@param data.names character string to be used to explain the data. Default
#'names are derived from the data arguments.
#'@return An object of class "htest."
#'@note The \code{genWilcox.test} 
#'function uses the \code{survfit} function. Helsel (2012) describes flipping
#'the left-censored data so that small values become large and left-censored
#'values become right-censored values and adapt nonparametric techniques from
#'survival analysis.\cr
#'
#'@section Null Hypothesis: The null hypothesis is that the
#'distributions are not different from one another.
#'@seealso \code{\link{survdiff}}, \code{\link{survfit}},
#'\code{\link{lcens-class}}
#'@references Gehan, E.A., 1965, A generalized Wilcoxon test for comparing
#'arbitraritly singly censored samples: Biometrika, v. 52, p. 203-223.\cr
#'
#'Harrington, D.P., and Fleming, T.R., 1982, A class of rank test procedures
#'for censored survival data: Biometrika, v. 69, p. 553-566.\cr
#'
#'Helsel, D.R. 2012, Statistics for Censored Environmental Data Using Minitab
#'and R: New York, Wiley, 324 p.\cr
#'
#'Peto, R., and Peto, J., 1972, Asymptotically efficient rank invariant test
#'procedures (with discussion): Journal of the Royal Statistical Society,
#'Series A v. 135, p. 185-206.\cr
#'
#'Prentice, R.L. 1978, Linear rank tests with right-censored data: Biometika, v
#'65, p 167-179.\cr
#'
#'Prentice, R.L., and Marke, P., 1979, A qualitative discrepancy between
#'censored data rank tests: Biometrika, v. 35, p. 861-867.\cr
#'
#'@keywords censored htest
#'@examples
#'
#'# Compare uncensored results
#'# First for grouped data
#'set.seed(69)
#'Xu <- rlnorm(22, 0, 1)
#'Yu <- rlnorm(22, .6, 1)
#'genWilcox.test(Xu, Yu)
#'wilcox.test(Xu, Yu)
#'# Compare effect of censoring
#'genWilcox.test(as.lcens(Xu, 1), Yu)
#'genWilcox.test(as.lcens(Xu, 1), as.lcens(Yu, 1))
#'
#'@export
genWilcox.test <- function(x, y, alternative="two.sided", data.names) {
  ## Coding history:
  ##    2005Mar08 DLLorenz Initial Coding.
  ##    2005Jul14 DLLorenz Fixed date
  ##    2007Jan29 DLLorenz Modified to fail on infoRich coding
  ##    2012Aug13 DLLorenz Conversion to R and split ppw test
  ##    2013Jan01 DLLorenz Roxygenized
  ##    2013Jan01          This version
  ##
  ## Error checks:
  if(missing(data.names)) {
    if(class(y) == "factor") {
      data.names <- levels(y)
      data.names <- paste(data.names[1], "and", data.names[2], sep=" ")
    } else if(class(y) == "character") {
      data.names <- unique(y)
      data.names <- paste(data.names[1], "and", data.names[2], sep=" ")
    } else # get names from x and y
    data.names <- paste(deparse(substitute(x)), "and",
                        deparse(substitute(y)), sep=" ")
  }
  x <- as.lcens(x)
  ## Remove missings
  keep <- !(is.na(x) | is.na(y))
  x <- x[keep]
  y <- y[keep]
  ## Create stacked data and group column
  if(is.numeric(y)) {
    y <- as.lcens(y)
    group = factor(c(rep('x', length(x)), rep('y', length(y))), levels=c('x', 'y'))
    data <- c(as.lcens(x), y)
  }
  else {
    data <- x
    group <- as.factor(y) # make it a factor
    if(length(levels(group)) != 2)
      stop("y must have exactly two levels")
  }
  ## Data must be rounded for computations within survfit
  data <- signif(data, 9)
  alternative <- pmatch(alternative, c('two.sided', 'greater', 'less'))
  if(is.na(alternative))
    stop("Invalid choice for alternative, must match 'two.sided', 'greater', or 'less'")
  ## define the tests:
  PetoPrentice.test <- function(values, cenflag, group) {
    ## Perform the kaplan meier analysis.
    ## required adjustment to values
    adjust <- min(diff(sort(unique(values))))/10.
    values <- ifelse(cenflag, values-adjust, values)
    df <- data.frame(values=-values, cenflag=!cenflag)
    kmout <- survfit(Surv(values, cenflag) ~ 1, data=df, na.action=na.exclude)
    kmout$time <- - kmout$time # convert back to actual values
    ## Define the link between the observed data and the kaplan meier table
    ## and compute needed stats.
    link <- match(values, kmout$time)
    St <- kmout$surv[link]
    Stm1 <- c(1,kmout$surv) # dummy to create valid value for t=1
    Stm1 <- Stm1[link] # now associated with correct value
    U <- ifelse(cenflag, Stm1 - 1, St + Stm1 - 1)
    nums <- tapply(U, group, length)
    retval <- list(W=tapply(U, group, sum, na.rm=T),
                   VarW=sum(U^2)*nums[1]*nums[2]/length(U)/(length(U)-1),
                   Ngroup=nums)
    ## retval is the computed W and the variance of W.
    return(retval)
  } # End of P-P.test
  ret1 <- PetoPrentice.test(data@.Data[,1], data@censor.codes, group)
  stat <- ret1$W[1] / sqrt(ret1$VarW)
  names(stat) <- "Peto-Prentice Z"
  meth <- "Peto-Prentice generalized Wilcoxon test"
  param <- ret1$Ngroup
  names(param) <- c("n", "m")
  ## add finishing touches
  if(alternative == 1)
    pvalue <- (1. - pnorm(abs(stat))) * 2.
  else if(alternative == 2)
    pvalue <- 1. - pnorm(stat)
  else # alternative is less than
    pvalue <- pnorm(stat)
  mu <- 0
  names(mu) <- "difference"
  retval <- list(statistic = stat, parameters = param,
                 p.value = pvalue, null.value = mu,
                 alternative = c('two.sided', 'greater', 'less')[alternative],
                 method = meth, data.name = data.names)
  oldClass(retval) <- 'htest'
  return(retval)
}
