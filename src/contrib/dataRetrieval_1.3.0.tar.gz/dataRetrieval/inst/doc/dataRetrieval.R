
## ----openLibrary, echo=FALSE---------------------------------------------
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)



## ----include=TRUE ,echo=FALSE,eval=TRUE----------------------------------
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, tidy=FALSE,comment="")
knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)


## ----workflow, echo=TRUE,eval=FALSE--------------------------------------
## library(dataRetrieval)
## # Site ID for Choptank River near Greensboro, MD
## siteNumber <- "01491000"
## ChoptankInfo <- getSiteFileData(siteNumber)
## parameterCd <- "00060"
## 
## #Raw daily data:
## rawDailyData <- retrieveNWISData(siteNumber,parameterCd,
##                       "1980-01-01","2010-01-01")
## # Data compiled for EGRET analysis
## Daily <- getDVData(siteNumber,parameterCd,
##                       "1980-01-01","2010-01-01")
## 
## # Sample data Nitrate:
## parameterCd <- "00618"
## Sample <- getSampleData(siteNumber,parameterCd,
##                       "1980-01-01","2010-01-01")
## 
## # Metadata on site and nitrate:
## INFO <- getMetaData(siteNumber,parameterCd)
## 
## # Merge discharge and nitrate data to one dataframe:
## Sample <- mergeReport()
## 


## ----tableParameterCodes, echo=FALSE,results='asis'----------------------
pCode <- c('00060', '00065', '00010','00045','00400')
shortName <- c("Discharge [cfs]","Gage height [ft]","Temperature [C]", "Precipitation [in]", "pH")

data.df <- data.frame(pCode, shortName, stringsAsFactors=FALSE)

xtable(data.df,label="tab:params",
                     caption="Common USGS Parameter Codes")



## ----tableParameterCodesDataRetrieval------------------------------------
library(dataRetrieval)
parameterCdFile <-  parameterCdFile
names(parameterCdFile)

# Sorting out some common values:
subset(parameterCdFile,parameter_cd %in% c("00060","00010","00400"))


## ----tableStatCodes, echo=FALSE,results='asis'---------------------------
StatCode <- c('00001', '00002', '00003','00008')
shortName <- c("Maximum","Minimum","Mean", "Median")

data.df <- data.frame(StatCode, shortName, stringsAsFactors=FALSE)

xtable(data.df,label="tab:stat",
                     caption="Commonly used USGS Stat Codes")



## ----getSite, echo=TRUE--------------------------------------------------

# Site ID for Choptank River near Greensboro, MD
siteNumber <- "01491000" 
ChoptankInfo <- getSiteFileData(siteNumber)


## ----siteNames2, echo=TRUE-----------------------------------------------
ChoptankInfo$station.nm


## ----getSiteExtended, echo=TRUE------------------------------------------
# Continuing from the previous example:
# This pulls out just the daily data:

ChoptankAvailableData <- getDataAvailability(siteNumber)

ChoptankDailyData <- subset(ChoptankAvailableData,
                            "dv" == service)

# This pulls out the mean:
ChoptankDailyData <- subset(ChoptankDailyData,
                            "00003" == statCd)



## ----tablegda, echo=FALSE,results='asis'---------------------------------
tableData <- with(ChoptankDailyData, 
      data.frame( srsname=srsname, 
      startDate=as.character(startDate), 
      endDate=as.character(endDate), 
      count=as.character(count),
      units=parameter_units)
      )


xtable(tableData,label="tab:gda",
    caption="Daily mean data availabile at the Choptank River near Greensboro, MD. Some columns deleted for space considerations.")



## ----label=getPCodeInfo, echo=TRUE---------------------------------------
# Using defaults:
parameterCd <- "00618" 
parameterINFO <- getParameterInfo(parameterCd)
colnames(parameterINFO)


## ----siteNames, echo=TRUE------------------------------------------------
parameterINFO$parameter_nm


## ----label=getNWISDaily, echo=TRUE, eval=TRUE----------------------------

# Continuing with our Choptank River example
parameterCd <- "00060"  # Discharge (cfs)
startDate <- ""  # Will request earliest date
endDate <- "" # Will request latest date

discharge <- retrieveNWISData(siteNumber, 
                    parameterCd, startDate, endDate)
names(discharge)


## ----label=getNWIStemperature, echo=TRUE---------------------------------

parameterCd <- c("00010","00060")  # Temperature and discharge
statCd <- c("00001","00003")  # Mean and maximum
startDate <- "2012-01-01"
endDate <- "2012-05-01"

temperatureAndFlow <- retrieveNWISData(siteNumber, parameterCd, 
        startDate, endDate, StatCd=statCd)



## ----label=renameColumns, echo=TRUE--------------------------------------
names(temperatureAndFlow)

temperatureAndFlow <- renameColumns(temperatureAndFlow)
names(temperatureAndFlow)


## ----getNWIStemperaturePlot, echo=TRUE, fig.cap="Temperature and discharge plot of Choptank River in 2012.",out.width='1\\linewidth',out.height='1\\linewidth',fig.show='hold'----
par(mar=c(5,5,5,5)) #sets the size of the plot window

with(temperatureAndFlow, plot(
  datetime, Temperature_water_degrees_Celsius_Max_01,
  xlab="Date",ylab="Max Temperature [C]"
  ))
par(new=TRUE)
with(temperatureAndFlow, plot(
  datetime, Discharge_cubic_feet_per_second,
  col="red",type="l",xaxt="n",yaxt="n",xlab="",ylab="",axes=FALSE
  ))
axis(4,col="red",col.axis="red")
mtext("Mean Discharge [cfs]",side=4,line=3,col="red")
title(paste(ChoptankInfo$station.nm,"2012",sep=" "))
legend("topleft", c("Max Temperature", "Mean Discharge"), 
       col=c("black","red"),lty=c(NA,1),pch=c(1,NA))


## ----label=getNWISUnit, echo=TRUE----------------------------------------

parameterCd <- "00060"  # Discharge (cfs)
startDate <- "2012-05-12" 
endDate <- "2012-05-13" 
dischargeToday <- retrieveUnitNWISData(siteNumber, parameterCd, 
        startDate, endDate)


## ----dischargeData, echo=FALSE-------------------------------------------
head(dischargeToday)


## ----label=getQW, echo=TRUE----------------------------------------------
 
# Dissolved Nitrate parameter codes:
parameterCd <- c("00618","71851")
startDate <- "1979-10-11"
endDate <- "2012-12-18"

dissolvedNitrate <- getRawQWData(siteNumber, parameterCd, 
      startDate, endDate)

dissolvedNitrateSimple <- getQWData(siteNumber, parameterCd, 
        startDate, endDate)
names(dissolvedNitrateSimple)


## ----getQWtemperaturePlot, echo=TRUE, fig.cap="Nitrate plot of Choptank River."----
with(dissolvedNitrateSimple, plot(
  dateTime, value.00618,
  xlab="Date",ylab = paste(parameterINFO$srsname,
      "[",parameterINFO$parameter_units,"]")
  ))
title(ChoptankInfo$station.nm)


## ----label=getQWData, echo=TRUE------------------------------------------
specificCond <- getWQPData('WIDNR_WQX-10032762','Specific conductance','','')
head(specificCond)


## ----label=geturl, echo=TRUE, eval=FALSE---------------------------------
## # Dissolved Nitrate parameter codes:
## pCode <- c("00618","71851")
## startDate <- "1964-06-11"
## endDate <- "2012-12-18"
## url_qw <- constructNWISURL(siteNumber,pCode,startDate,endDate,'qw')
## url_dv <- constructNWISURL(siteNumber,"00060",startDate,endDate,
##                            'dv',statCd="00003")
## url_uv <- constructNWISURL(siteNumber,"00060",startDate,endDate,'uv')


## ----ThirdExample--------------------------------------------------------
parameterCd <- "00618"
INFO <-getMetaData(siteNumber,parameterCd, interactive=FALSE)


## ----firstExample--------------------------------------------------------
siteNumber <- "01491000"
startDate <- "2000-01-01"
endDate <- "2013-01-01"
# This call will get NWIS (cfs) data , and convert it to cms:
Daily <- getDVData(siteNumber, "00060", startDate, endDate)


## ----colNamesDaily, echo=FALSE,results='asis'----------------------------
ColumnName <- c("Date", "Q", "Julian","Month","Day","DecYear","MonthSeq","Qualifier","i","LogQ","Q7","Q30")
Type <- c("Date", "number", "number","integer","integer","number","integer","string","integer","number","number","number")
Description <- c("Date", "Discharge in cms", "Number of days since January 1, 1850", "Month of the year [1-12]", "Day of the year [1-366]", "Decimal year", "Number of months since January 1, 1850", "Qualifing code", "Index of days, starting with 1", "Natural logarithm of Q", "7 day running average of Q", "30 day running average of Q")
Units <- c("date", "cms","days", "months","days","years","months", "character","days","numeric","cms","cms")

DF <- data.frame(ColumnName,Type,Description,Units)

xtable(DF, caption="Daily dataframe")



## ----secondExample-------------------------------------------------------
parameterCd <- "00618"
Sample <-getSampleData(siteNumber,parameterCd,
      startDate, endDate)


## ----STORET,echo=TRUE,eval=FALSE-----------------------------------------
## site <- 'WIDNR_WQX-10032762'
## characteristicName <- 'Specific conductance'
## Sample <-getSTORETSampleData(site,characteristicName,
##       startDate, endDate)


## ----label=tab:exampleComplexQW, echo=FALSE, eval=TRUE,results='asis'----
cdate <- c("2003-02-15","2003-06-30","2004-09-15","2005-01-30","2005-05-30","2005-10-30")
rdp <- c("", "<","<","","","")
dp <- c(0.02,0.01,0.005,NA,NA,NA)
rpp <- c("", "","<","","","")
pp <- c(0.5,0.3,0.2,NA,NA,NA)
rtp <- c("","","","","<","<")
tp <- c(NA,NA,NA,0.43,0.05,0.02)

DF <- data.frame(cdate,rdp,dp,rpp,pp,rtp,tp,stringsAsFactors=FALSE)

xtable(DF, caption="Example data",digits=c(0,0,0,3,0,3,0,3),label="tab:exampleComplexQW")



## ----thirdExample,echo=FALSE---------------------------------------------
  compressedData <- compressData(DF)
  Sample <- populateSampleColumns(compressedData)


## ----thirdExampleView,echo=TRUE------------------------------------------
  Sample


## ----openDaily, eval = FALSE---------------------------------------------
## fileName <- "ChoptankRiverFlow.txt"
## filePath <-  "C:/RData/"
## Daily <- getDailyDataFromFile(filePath,fileName,
##                     separator="\t")


## ----openSample, eval = FALSE--------------------------------------------
## fileName <- "ChoptankRiverNitrate.csv"
## filePath <-  "C:/RData/"
## Sample <- getSampleDataFromFile(filePath,fileName,
##                                 separator=",")


## ----openSample2, eval = FALSE-------------------------------------------
## fileName <- "ChoptankPhosphorus.txt"
## filePath <-  "C:/RData/"
## Sample <- getSampleDataFromFile(filePath,fileName,
##                                 separator="\t")


## ----mergeExample--------------------------------------------------------
siteNumber <- "01491000"
parameterCd <- "00631"  # Nitrate
startDate <- "2000-01-01"
endDate <- "2013-01-01"

Daily <- getDVData(siteNumber, "00060", startDate, endDate)
Sample <- getSampleData(siteNumber,parameterCd, startDate, endDate)
Sample <- mergeReport()
head(Sample)


## ----egretEx, echo=TRUE, eval=TRUE, fig.cap="Default multiPlotDataOverview"----
# Continuing Choptank example from the previous sections
library(EGRET)
multiPlotDataOverview()


## ----helpFunc,eval = FALSE-----------------------------------------------
## ?removeDuplicates


## ----rawFunc,eval = TRUE-------------------------------------------------
removeDuplicates


## ----seeVignette,eval = FALSE--------------------------------------------
## vignette(dataRetrieval)


## ----installFromCran,eval = FALSE----------------------------------------
## install.packages(c("zoo","XML","RCurl","plyr"))
## install.packages("dataRetrieval", repos="http://usgs-r.github.com")


## ----openLibraryTest, eval=FALSE-----------------------------------------
## library(dataRetrieval)


## ----label=getSiteApp, echo=TRUE-----------------------------------------
availableData <- getDataAvailability(siteNumber)
dailyData <- availableData["dv" == availableData$service,]
dailyData <- dailyData["00003" == dailyData$statCd,]

tableData <- with(dailyData, 
      data.frame(
        shortName=srsname, 
        Start=startDate, 
        End=endDate, 
        Count=count,
        Units=parameter_units)
      )
tableData


## ----label=saveData, echo=TRUE, eval=FALSE-------------------------------
## write.table(tableData, file="tableData.tsv",sep="\t",
##             row.names = FALSE,quote=FALSE)


