library(animation)

library(dataRetrieval)
library(EGRET)

Daily <- ChopDaily
Sample <- ChopSample
INFO <- ChopINFO
surfaces <- exsurfaces

maxDiff<-2
qBottom<-1
qTop<-5000

ani.options(interval=.05)

saveGIF({
  
  for (i in 2001:2010){
    plotDiffContours(year0=2000,i,qBottom,qTop,maxDiff,qUnit=1)
  }
})