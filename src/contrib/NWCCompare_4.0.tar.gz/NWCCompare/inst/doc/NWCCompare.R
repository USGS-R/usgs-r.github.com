## ----openLibrary, echo=FALSE------------------------------
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)

## ----include=TRUE ,echo=FALSE,eval=TRUE-------------------
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, tidy=FALSE,comment="")
knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)

## ----workflow, echo=TRUE,eval=TRUE------------------------
library(EflowStats)
library(NWCCompare)


## ----modelStatsprep, echo=TRUE,eval=TRUE------------------
############################################
# Run stats and differences on USGS observed and modeled daily discharge data
model_url="http://cida.usgs.gov/nwc/thredds/sos/watersmart/stats/stats-SE-DENSE2-2.03.nc?request=GetObservation&service=SOS&version=1.0.0&offering"
diffInputsv <- diffInputs(model_url)
startdate <- diffInputsv[[1]]
enddate <- diffInputsv[[2]]
x_urls <- diffInputsv[[3]]
d_urls <- diffInputsv[[4]]
m_urls <- diffInputsv[[5]]
sites <- diffInputsv[[6]]

## ----modelStatschunk, echo=FALSE,eval=TRUE----------------
############################################
startdate <- startdate
enddate <- enddate
x_urls <- x_urls[1:5]
d_urls <- d_urls[1:5]
m_urls <- m_urls[1:5]
sites <- sites[1:5]

## ----createstatsoutput, echo=FALSE,eval=TRUE,results="hide"----
###############################################
# calculate statsout
statsout <- calculateStatsDiffs(sites, startdate, enddate, getXMLWML1.1Data, x_urls, getDrainageArea, d_urls, SWE_CSV_IHA, m_urls)

## ----statsoutput, echo=TRUE,eval=FALSE--------------------
#  ###############################################
#  # calculate statsout
#  statsout <- calculateStatsDiffs(sites, startdate, enddate, getXMLWML1.1Data, x_urls, getDrainageArea, d_urls, SWE_CSV_IHA, m_urls)

## ----viewData, echo=FALSE,eval=TRUE-----------------------
###############################################
# view a portion of the statsout table
statsout[,c(1,4,39,74,109,111,115)]

## ----saveData, echo=TRUE,eval=FALSE-----------------------
#  # save statsout to a tab-delimited file
#  output = "output.txt"
#  write.table(statsout, file = output, col.names = TRUE, row.names = FALSE,
#              quote = FALSE, sep = "\t")

## ----OtherStats, echo=TRUE,eval=FALSE---------------------
#  #############################################################
#  # calculate stats for data from your own data file
#  drain_area=54
#  site_id="Test site"
#  daily_data<-dailyData
#  stats="magnifSeven,magStat,flowStat,durStat,timStat,rateStat,otherStat"
#  statsout <- ObservedStatsOther(daily_data,drain_area,site_id,stats)

## ----justStats, echo=TRUE, eval=FALSE---------------------
#  # Run stats on USGS observed daily discharge data
#  sites <- '02177000,02178400'
#  startdate <- "2008-10-01"
#  enddate <- "2013-09-29"
#  stats<-"rateStat,magnifSeven,magStat,flowStat,durStat,timStat,otherStat"
#  nwisDvUrl <- "http://waterservices.usgs.gov/nwis/dv/?format=waterml,1.1&sites="
#  offering <- "00003"
#  property <- "00060"
#  drainage_url <- "http://waterservices.usgs.gov/nwis/site/?siteOutput=Expanded&site="
#  sites<-read.csv(header=F,colClasses=c("character"),text=sites)
#  x_urls<-paste(nwisDvUrl, sites, "&startDT=", startdate, "&endDT=", enddate, "&statCd=", offering, "&parameterCd=", property, sep = "")
#  d_urls<-paste(drainage_url, sites, sep = "")
#  statsout <- calculateStatsGroups(stats, sites, startdate, enddate, getXMLWML1.1Data, x_urls, getDrainageArea, d_urls)

## ----helpFunc,eval = FALSE--------------------------------
#  library(NWCCompare)
#  ?RegionalGoF

## ----rawFunc,eval = TRUE----------------------------------
RegionalGoF

## ----installFromCran,eval = FALSE-------------------------
#  install.packages(c("zoo","chron","doBy","XML","hydroGOF","lmomco","RCurl"))
#  install.packages(c("EflowStats","NWCCompare"),repos="http://usgs-r.github.com",type="source")

## ----openLibraryTest, eval=FALSE--------------------------
#  library(EflowStats)
#  library(NWCCompare)

