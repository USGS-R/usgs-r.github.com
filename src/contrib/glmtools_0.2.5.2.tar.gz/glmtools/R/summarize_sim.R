#'@title creates GLM simulation summary outputs
#'
#'@param file a string with the path to the netcdf output from GLM
#'@return a data.frame with DateTime and temperature at depth 
#'@keywords methods
#'@author
#'Jordan S. Read, Luke A. Winslow
summarize_sim <- function(file){
  
  return(FALSE)
}