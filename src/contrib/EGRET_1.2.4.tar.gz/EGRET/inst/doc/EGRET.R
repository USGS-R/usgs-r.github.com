
## @knitr openLibrary, echo=FALSE
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)



## @knitr include=TRUE ,echo=FALSE,eval=TRUE
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, concordance=TRUE,tidy=FALSE,comment="")

knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)



## @knitr workflow, echo=TRUE,eval=FALSE
## library(dataRetrieval)
## library(EGRET)
## 
## ############################
## # Gather discharge data:
## siteID <- "01491000" #Choptank River at Greensboro, MD
## startDate <- "" #Gets earliest date
## endDate <- "2011-09-30"
## Daily <- getDVData(siteID,"00060",startDate,endDate)
## 
## # Gather sample data:
## parameter_cd<-"00631" #5 digit USGS code
## Sample <- getSampleData(siteID,parameter_cd,startDate,endDate)
## 
## # Gather site and parameter information:
## INFO<- getMetaData(siteID,parameter_cd,interactive=FALSE)
## INFO$shortName <- "Choptank River at Greensboro, MD"
## INFO <- setPA()
## 
## # Merge discharge with sample data:
## Sample <- mergeReport()
## ############################
## 
## ############################
## # Check flow history data:
## annualSeries <- makeAnnualSeries()
## plotFlowSingle(istat=7,qUnit="thousandCfs")
## plotSDLogQ()
## plotQTimeDaily(1990,2010,qLower=1,qUnit=3)
## plotFour(qUnit=3)
## plotFourStats(qUnit=3)
## ############################
## 
## ############################
## # Check sample data:
## boxConcMonth()
## boxQTwice()
## plotLogConcTime()
## plotConcTime()
## plotConcQ()
## plotLogConcQ()
## plotLogFluxQ()
## multiPlotDataOverview()
## ############################
## 
## ############################
## # Run WRTDS model:
## modelEstimation()
## ############################
## 
## ############################
## #Check model results:
## yearStart <- 2000
## yearEnd <- 2010
## 
## #Require Sample + INFO:
## plotConcTimeDaily(yearStart, yearEnd)
## plotFluxTimeDaily(yearStart, yearEnd)
## plotConcPred()
## plotFluxPred()
## plotLogConcPred()
## plotLogFluxPred()
## plotResidPred()
## plotResidQ()
## plotResidTime()
## boxResidMonth()
## boxConcThree()
## 
## #Require annualResults + INFO:
## plotConcHist()
## plotFluxHist()
## 
## # Multi-line plots:
## date1 <- "2000-09-01"
## date2 <- "2005-09-01"
## date3 <- "2009-09-01"
## qBottom<-100
## qTop<-5000
## plotLogConcQSmooth(date1, date2, date3, qBottom, qTop,
##                    concMax=2, concMin=0.1,qUnit=1)
## plotConcQSmooth(date1, date2, date3, qBottom, qTop,
##                    concMax=2,qUnit=1)
## q1 <- 10
## q2 <- 25
## q3 <- 75
## centerDate <- "07-01"
## plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)
## 
## # Multi-plots:
## fluxBiasMulti()
## 
## #Contour plots:
## clevel<-seq(0,2,0.5)
## maxDiff<-0.8
## plotContours(yearStart,yearEnd,qBottom,qTop,
##              contourLevels = clevel,qUnit=1)
## plotDiffContours(year0=2000,yearEnd,
##                  qBottom,qTop,maxDiff,qUnit=1)
## 


## @knitr openlibraries, echo=TRUE,eval=TRUE
library(dataRetrieval)
library(EGRET)


## @knitr cheatSheets,echo=TRUE,eval=TRUE,results='markup'
printqUnitCheatSheet()


## @knitr cheatSheets2,echo=TRUE,eval=TRUE,results='markup'
printFluxUnitCheatSheet()


## @knitr vignette1, eval=FALSE, echo=TRUE
## vignette("dataRetrieval")


## @knitr flowHistory,echo=TRUE,eval=TRUE
siteID <- "14105700"  
startDate <- ""
endDate <- ""

Daily <- getDVData(siteID,"00060",startDate,endDate)
INFO <- getMetaData(siteID,"",interactive=FALSE)
INFO$shortName <- "Columbia River at The Dalles, OR"


## @knitr newChunckWinter, echo=TRUE,eval=FALSE
## INFO <- setPA(paStart=12,paLong=3)


## @knitr newChunck, echo=TRUE,eval=TRUE
INFO <- setPA()


## @knitr newChunckAS, echo=TRUE,eval=TRUE
annualSeries <- makeAnnualSeries()


## @knitr plotSingleandSD, echo=TRUE, fig.cap="Discharge statistics",fig.subcap=c("plotFlowSingle(istat=5,qUnit='thousandCfs')","plotSDLogQ()"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotFlowSingle(istat=5,qUnit="thousandCfs")
plotSDLogQ()


## @knitr plotFour, echo=TRUE, fig.cap="plotFour(qUnit=3)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
plotFour(qUnit=3)


## @knitr plotFourStats,echo=TRUE, fig.cap="plotFourStats(qUnit=3)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
plotFourStats(qUnit=3)


## @knitr Merced, echo=TRUE,eval=TRUE,fig.cap="Merced River Winter Trend",fig.subcap=c("Water Year", "Dec-Feb"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
sta<-"11264500"
Daily <-getDVData(sta,"00060",StartDate="",EndDate="")
INFO <- getMetaData(sta,"",interactive=FALSE)
INFO$shortName <- "Merced River at Happy Isles Bridge, CA"
INFO <- setPA()
annualSeries <- makeAnnualSeries()
plotFlowSingle(istat=5)

INFO<-setPA(paStart=12,paLong=3)
annualSeries<-makeAnnualSeries()
plotFlowSingle(istat=5)



## @knitr Mississippi, echo=TRUE,eval=TRUE,fig.cap="Mississippi River at Keokuk Iowa",fig.subcap=c("Water Year", "Dec-Feb"),out.width='1\\linewidth',out.height='1\\linewidth',fig.show='hold'
sta<-"05474500"
Daily <-getDVData(sta,"00060",StartDate="",EndDate="")
INFO <- getMetaData(sta,"",interactive=FALSE)
INFO$shortName <- "Mississippi River at Keokuk Iowa"
INFO <- setPA()

plotQTimeDaily(startYear=1880,endYear=2010,qUnit=3,qLower=300)



## @knitr printSeries, eval=FALSE,echo=TRUE
## seriesResult <- printSeries(istat=3, qUnit=3)


## @knitr tfc, eval=TRUE,echo=TRUE
annualSeries <- makeAnnualSeries()
tableFlowChange(istat=3, qUnit=3,yearPoints=c(1890,1950,2010))


## @knitr wrtds1,eval=FALSE,echo=TRUE
## siteID <- "01491000" #Choptank River at Greensboro, MD
## startDate <- "1979-10-01"
## endDate <- "2011-09-30"
## param<-"00631"
## Daily <- getDVData(siteID,"00060",startDate,endDate)
## INFO<- getMetaData(siteID,param,interactive=FALSE)
## INFO$shortName <- "Choptank River"
## 
## Sample <- getSampleData(siteID,param,startDate,endDate)
## Sample <- mergeReport()


## @knitr wrtds2,eval=TRUE,echo=FALSE
siteID <- "01491000" #Choptank River at Greensboro, MD
startDate <- "1979-10-01"
endDate <- "2011-09-30"
param<-"00631"
Daily <- ChopDaily
Sample <- ChopSample
INFO <- ChopINFO
annualSeries <- makeAnnualSeries()


## @knitr plotBoxes, echo=TRUE, fig.cap="Concentration box plots",fig.subcap=c("boxConcMonth()","boxQTwice(qUnit=1)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
boxConcMonth()
boxQTwice(qUnit=1)


## @knitr plotConcTime,echo=TRUE, fig.cap="Concentration vs time",fig.subcap=c("plotConcTime()","plotLogConcTime()"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcTime()
plotLogConcTime()


## @knitr plotConcQ, echo=TRUE, fig.cap="Concentration vs discharge",fig.subcap=c("plotConcQ(qUnit=1)","plotLogConcQ(qUnit=1)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcQ(qUnit=1)
plotLogConcQ(qUnit=1)


## @knitr plotLogConcQ, echo=TRUE, fig.cap="plotLogFluxQ(qUnit=1)",out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotLogFluxQ(qUnit=1)


## @knitr multiPlotDataOverview, echo=TRUE, fig.cap="multiPlotDataOverview(qUnit=1)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
multiPlotDataOverview(qUnit=1)


## @knitr flowDuration, eval=TRUE, echo=TRUE
flowDuration(qUnit=1)


## @knitr wrtds3, eval=FALSE, echo=TRUE
## modelEstimation()


## @knitr wrtds4, eval=FALSE, echo=TRUE
## AnnualResults<-setupYears(paStart=12,paLong=3)


## @knitr wrtds5, eval=FALSE, echo=TRUE
## savePath <- "C:/Users/ldecicco/WRTDS_Output/"
## INFO$staAbbrev <- "Chop"
## INFO$constitAbbrev <- "nitrogen"
## saveResults(savePath)


## @knitr wrtds8, eval=FALSE, echo=TRUE
## loadPath <- "C:/Users/ldecicco/WRTDS_Output/"
## staAbbrev <- "Chop"
## constitAbbrev <- "nitrogen"
## pathToFile <- paste(loadPath,staAbbrev,".",
##                     constitAbbrev,".RData",sep="")
## load(pathToFile)


## @knitr getChopData1,echo=FALSE,eval=TRUE
Sample <- ChopSample
Daily <- ChopDaily
INFO <- ChopINFO
AnnualResults <- setupYears()
surfaces <- exsurfaces


## @knitr plotConcTimeDaily, echo=TRUE, fig.cap="Concentration and flux vs time",fig.subcap=c("plotConcTimeDaily(startYear=2008, endYear=2010)","plotFluxTimeDaily(startYear=2008, endYear=2010)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
yearStart <- 2008
yearEnd <- 2010

plotConcTimeDaily(yearStart, yearEnd)
plotFluxTimeDaily(yearStart, yearEnd)


## @knitr plotFluxPred, echo=TRUE, fig.cap="Concentration predictions",fig.subcap=c('plotConcPred()','plotLogConcPred()'),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcPred()
plotLogConcPred()


## @knitr plotLogFluxPred, echo=TRUE, fig.cap="Flux predictions",fig.subcap=c('plotFluxPred()','plotLogFluxPred()'), out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotFluxPred()
plotLogFluxPred()


## @knitr plotResidQ, echo=TRUE, fig.cap="Residuals",fig.subcap=c("plotResidPred()","plotResidQ(qUnit=1)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotResidPred()
plotResidQ(qUnit=1)


## @knitr boxResidMonth, echo=TRUE, fig.cap="Residuals with respect to time",fig.subcap=c("plotResidTime()","boxResidMonth()"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotResidTime()
boxResidMonth()


## @knitr boxConcThree, echo=TRUE, fig.cap="Default boxConcThree()",out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='asis',results='hide'
boxConcThree()


## @knitr plotFluxHist, echo=TRUE, fig.cap="Concentration and flux history",fig.subcap=c("plotConcHist()", "plotFluxHist()"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcHist()
plotFluxHist()


## @knitr plotLogConcQSmooth, echo=TRUE, fig.cap="Concentration vs. discharge",fig.subcap=c("plotConcQSmooth","plotLogConcQSmooth"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
qBottom<-5
qTop<-1000
date1 <- "2000-09-01"
date2 <- "2005-09-01"
date3 <- "2009-09-01"
plotConcQSmooth(date1, date2, date3,
                qBottom, qTop, qUnit=1)
plotLogConcQSmooth(date1, date2, date3,
                   qBottom, qTop, qUnit=1)


## @knitr plotConcTimeSmooth, echo=TRUE, fig.cap="plotConcTimeSmooth",fig.subcap=c("plotConcQSmooth","plotLogConcQSmooth(logScale=TRUE)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold',results='hide'
q1 <- 10
q2 <- 25
q3 <- 75
centerDate <- "07-01"
plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, 2010)
plotConcTimeSmooth(q1, q2, q3, centerDate, 
                   2000, 2010,logScale=TRUE)


## @knitr fluxBiasMulti, echo=TRUE, fig.cap="fluxBiasMulti(qUnit=1)",fig.show='asis',fig.width=8, fig.height=10
fluxBiasMulti(qUnit=1)


## @knitr plotContours, echo=TRUE, fig.cap="plotContours(2008,2010,1,5000,clevel,qUnit=1)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
clevel<-seq(0,2.5,0.25)
plotContours(yearStart,yearEnd,qBottom,qTop, 
             contourLevels = clevel,qUnit=1)


## @knitr plotDiffContours, echo=TRUE, fig.cap="plotDiffContours(year0=2000,yearEnd=2010,qBottom=1,qTop=5000,maxDiff=2)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
maxDiff<-1
plotDiffContours(year0=2000,yearEnd,
                 qBottom,qTop,maxDiff,qUnit=1)


## @knitr setcontours, echo=TRUE, eval=FALSE
## contourLevels = seq(0,5,0.2)


## @knitr tableResults1, echo=TRUE, eval=FALSE
## tableResults()
## returnDF <- tableResults(returnDataFrame=TRUE)


## @knitr tableResults2, echo=FALSE, eval=TRUE,results='hide'
returnDF <- tableResults(returnDataFrame=TRUE)


## @knitr tableResults3, echo=TRUE, eval=TRUE,results='markup'
head(returnDF)


## @knitr tableChange1, eval=TRUE, echo=TRUE
tableChange(yearPoints=c(2000,2005,2010))


## @knitr tableChangeSingle, eval=FALSE, echo=TRUE,results='hide'
## returnDF <- tableChangeSingle(yearPoints=c(2000,2005,2010),
##                               returnDataFrame=TRUE)


## @knitr adjustSize,echo=TRUE,eval=TRUE,fig.cap="Modifying text and point size", fig.subcap=c("plotLogConcQ(cex.axis=2,cex.main=1.5)","plotLogConcQ(cex.lab=2,cex=2)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotLogConcQ(cex.axis=2,cex.main=1.5)
plotLogConcQ(cex.lab=2,cex=2)


## @knitr plotLogConcQComparison,echo=TRUE,eval=TRUE,fig.cap="Modified plotLogConcQ", fig.subcap=c("Default","Modified"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotLogConcQ()
par(mar=c(8,8,8,8))
plotLogConcQ(customPar=TRUE,col="blue",cex=1.1,
             cex.axis=1.4,cex.main=1.5,cex.lab=1.2,pch=18,lwd=2)
grid(lwd=2)
legend(4.5,.09,"Choptank Nitrogen", pch=18, col="blue",bg="white")
arrows(3, 0.14, 1, .05,lwd=2)
text(12,.14,"Censored Value")


## @knitr easyFontChange,echo=TRUE,eval=TRUE,fig.cap="Serif font",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
# Switching to serif font:
par(family="serif")
plotFluxPred(customPar=TRUE)
mtext(side=3,line=-3,"Serif font example",cex=3)


## @knitr modifiedContour1,echo=TRUE,eval=TRUE,fig.cap="Contour plot with modified axis and color scheme",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
yearStart <- 2001
yearEnd <- 2010
qBottom <- 0.1
qTop<- 25
clevel <- seq(0,3.5,0.5)
colors <- colorRampPalette(c("white","red"))
yTicksModified <- c(.1,1,10,25)
plotContours(yearStart,yearEnd,qBottom,qTop, 
             contourLevels = clevel,
             yTicks=yTicksModified,
             color.palette=colors)  


## @knitr modifiedDiffContour,echo=TRUE,eval=TRUE,fig.cap="Difference contour plot with modifiedcolor scheme",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
colors <- colorRampPalette(c("blue","white","red"))
maxDiff<-0.5
plotDiffContours(yearStart,yearEnd,qBottom,qTop, 
             maxDiff,lwd=2,
             color.palette=colors)


## @knitr helpFunc,eval = FALSE
## ?getJulian


## @knitr rawFunc,eval = FALSE
## getJulian


## @knitr installFromCran,eval = FALSE
## install.packages(c("zoo","survival","methods","fields","spam"))
## install.packages("dataRetrieval",
##                  repos="http://usgs-r.github.com/",
##                  type="source")
## install.packages("EGRET",
##                  repos="http://usgs-r.github.com/",
##                  type="source")


## @knitr openLibraryTest, eval=FALSE
## library(dataRetrieval)
## library(EGRET)


## @knitr label=getSiteApp, echo=TRUE,eval=FALSE
## 
## tableData <- tableResults(returnDataFrame=TRUE)


## @knitr label=getSiteApp2, echo=FALSE,eval=TRUE

tableData <- tableResults(returnDataFrame=TRUE)


## @knitr label=saveData, echo=TRUE, eval=FALSE
## write.table(tableData, file="tableData.tsv",sep="\t",
##             row.names = FALSE,quote=FALSE)


## @knitr label=savePlots, echo=TRUE, eval=FALSE
## jpeg("plotFlowSingle.jpg")
## plotFlowSingle(1)
## dev.off()
## 
## png("plotFlowSingle.png")
## plotFlowSingle(1)
## dev.off()
## 
## pdf("plotFlowSingle.pdf")
## plotFlowSingle(1)
## dev.off()
## 
## postscript("plotFlowSingle.ps")
## plotFlowSingle(1)
## dev.off()
## 
## #Many plots saved to one pdf:
## pdf("manyPlots.pdf")
## plotFlowSingle(1)
## plotFlowSingle(2)
## plotFlowSingle(3)
## plotFlowSingle(4)
## dev.off()
## 


## @knitr label=savePlots2, echo=TRUE, eval=FALSE
## postscript("fluxBiasMulti.ps", height=10,width=8)
## fluxBiasMulti()
## dev.off()


