#' timeDay class
#'
#' Some details about the timeDay class
#'
#' @name timeDay-class
#' @rdname timeDay-class
#' @exportClass timeDay
setClass("timeDay", representation(time="numeric", format="character"))
