# Build the package:
library(devtools)
setwd("D:/LADData/RCode/dataRetrieval")
load_all(reset = TRUE)
document()

# export(formatCheckDate)
# export(checkStartEndDate)
# export(dateFormatCheck)
# export(formatCheckParameterCd)
# export(formatCheckSiteNumber)
build()

devtools::build_vignettes()

check()  
# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
install()


#In command line:
# Rcmd INSTALL --build dataRetrieval
# Rcmd check --as-cran dataRetrievalCRANCheck