### R code from vignette source 'app3.Rnw'

###################################################
### code chunk number 1: app3.Rnw:34-41
###################################################
# Load the rloadest package, which requires the USGSwsQW and
# other packages that contain the necessary functions
library(rloadest)
app3.qw <- importNWISqw("01646580", params="00660", 
    begin.date="2001-10-01", end.date="2010-09-30")
app3.flow <- renCol(readNWIS("01646502",
    begin.date="2001-10-01", end.date="2010-09-30"))


###################################################
### code chunk number 2: app3.Rnw:46-56
###################################################
# There are duplicated samples in this dataset. Print them
subset(app3.qw, sample_dt %in% 
  app3.qw[duplicated(app3.qw$sample_dt), "sample_dt"])
# Remove the duplicates
app3.qw <- subset(app3.qw, !duplicated(sample_dt))
# Now change the date column name and merge
names(app3.qw)[2] <- "datetime"
# Supress the plot in this merge
app3.calib <- mergeQ(app3.qw, FLOW="Flow", DATES="datetime", 
                     Qdata=app3.flow, Plot=FALSE)


###################################################
### code chunk number 3: app3.Rnw:64-69
###################################################
# Create and print the load model.
app3.lr <- loadReg(OrthoPhosphate.PO4 ~ model(9), data = app3.calib, 
  flow = "Flow", dates = "datetime",
  station="Potomac River at Chain Bridge, at Washington, DC")
print(app3.lr)


###################################################
### code chunk number 4: app3.Rnw:78-82
###################################################
# setSweave is required for the vignette.
setSweave("app3_01", 5, 5)
plot(app3.lr, which=1, set.up=FALSE)
graphics.off()


###################################################
### code chunk number 5: app3.Rnw:84-86
###################################################
cat("\\includegraphics{app3_01.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 6: app3.Rnw:93-97
###################################################
# setSweave is required for the vignette.
setSweave("app3_02", 5, 5)
plot(app3.lr, which=3, set.up=FALSE)
graphics.off()


###################################################
### code chunk number 7: app3.Rnw:99-101
###################################################
cat("\\includegraphics{app3_02.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 8: app3.Rnw:108-112
###################################################
# setSweave is required for the vignette.
setSweave("app3_03", 5, 5)
plot(app3.lr, which=4, set.up=FALSE)
graphics.off()


###################################################
### code chunk number 9: app3.Rnw:114-116
###################################################
cat("\\includegraphics{app3_03.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 10: app3.Rnw:123-127
###################################################
# setSweave is required for the vignette.
setSweave("app3_04", 5, 5)
plot(app3.lr, which=5, set.up=FALSE)
graphics.off()


###################################################
### code chunk number 11: app3.Rnw:129-131
###################################################
cat("\\includegraphics{app3_04.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 12: app3.Rnw:138-142
###################################################
# setSweave is required for the vignette.
setSweave("app3_05", 5, 5)
plot(app3.lr, which="DECTIME", set.up=FALSE)
graphics.off()


###################################################
### code chunk number 13: app3.Rnw:144-146
###################################################
cat("\\includegraphics{app3_05.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 14: app3.Rnw:155-162
###################################################
# setSweave is required for the vignette.
setSweave("app3_06", 5, 5)
timePlot(app3.calib$datetime, residuals(app3.lr),
         Plot=list(what="points"), ytitle="Residuals")
refLine(horizontal=0)
refLine(vertical=as.Date("2001-10-01") + years(0:9))
graphics.off()


###################################################
### code chunk number 15: app3.Rnw:164-166
###################################################
cat("\\includegraphics{app3_06.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 16: app3.Rnw:173-175
###################################################
mean(app3.flow$Flow)
with(app3.flow, tapply(Flow, waterYear(datetime), mean))


###################################################
### code chunk number 17: app3.Rnw:185-192
###################################################
app3.anom <- renCol(readNWIS("01646502",
                             begin.date="1999-10-01", 
                             end.date="2010-09-30"))
app3.anom <- cbind(app3.anom, anomalies(log(app3.anom$Flow), 
                                        a1yr=365))
# The head would show missing values for a1yr and HFV
tail(app3.anom)


###################################################
### code chunk number 18: app3.Rnw:197-201
###################################################
# Supress the plot in this merge and overwrite app3.calib
app3.calib <- mergeQ(app3.qw, FLOW=c("Flow", "a1yr", "HFV"),
                     DATES="datetime", 
                     Qdata=app3.anom, Plot=FALSE)


###################################################
### code chunk number 19: app3.Rnw:206-212
###################################################
app3.lra <- loadReg(OrthoPhosphate.PO4 ~ a1yr + HFV + dectime(datetime)
                    + fourier(datetime),
                    data = app3.calib, 
                   flow = "Flow", dates = "datetime",
                   station="Potomac River at Chain Bridge, at Washington, DC")
print(app3.lra)


###################################################
### code chunk number 20: app3.Rnw:220-224
###################################################
# setSweave is required for the vignette.
setSweave("app3_07", 5, 5)
plot(app3.lra, which=1, set.up=FALSE)
graphics.off()


###################################################
### code chunk number 21: app3.Rnw:226-228
###################################################
cat("\\includegraphics{app3_07.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 22: app3.Rnw:235-239
###################################################
# setSweave is required for the vignette.
setSweave("app3_08", 5, 5)
plot(app3.lra, which=3, set.up=FALSE)
graphics.off()


###################################################
### code chunk number 23: app3.Rnw:241-243
###################################################
cat("\\includegraphics{app3_08.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 24: app3.Rnw:250-254
###################################################
# setSweave is required for the vignette.
setSweave("app3_09", 5, 5)
plot(app3.lra, which=4, set.up=FALSE)
graphics.off()


###################################################
### code chunk number 25: app3.Rnw:256-258
###################################################
cat("\\includegraphics{app3_09.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 26: app3.Rnw:265-269
###################################################
# setSweave is required for the vignette.
setSweave("app3_10", 5, 5)
plot(app3.lra, which=5, set.up=FALSE)
graphics.off()


###################################################
### code chunk number 27: app3.Rnw:271-273
###################################################
cat("\\includegraphics{app3_10.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 28: app3.Rnw:280-284
###################################################
# setSweave is required for the vignette.
setSweave("app3_11", 5, 5)
plot(app3.lra, which="dectime(datetime)", set.up=FALSE)
graphics.off()


###################################################
### code chunk number 29: app3.Rnw:286-288
###################################################
cat("\\includegraphics{app3_11.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 30: app3.Rnw:298-301
###################################################
app3.est <- subset(app3.anom, datetime > as.Date("2001-09-30"))
predLoad(app3.lra, newdata = app3.est, by="water year",
         print=TRUE)


