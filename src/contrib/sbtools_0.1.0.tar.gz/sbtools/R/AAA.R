
url_base = "https://www.sciencebase.gov/catalog/"
url_items = paste0(url_base, "items/")
url_item = paste0(url_base, "item/")
url_upload = paste0(url_base, 'file/uploadAndUpsertItem/')
url_upload_create = paste0(url_base, 'file/uploadAndCreateItem/')
url_download = paste0(url_base, 'file/get/')
url_login = 'https://my.usgs.gov/josso/signon/usernamePasswordLogin.do'


