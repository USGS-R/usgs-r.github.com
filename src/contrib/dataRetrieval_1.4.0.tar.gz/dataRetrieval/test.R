install.packages("dataRetrieval", 
                 repos=c("http://usgs-r.github.com","http://cran.us.r-project.org"),
                 dependencies=TRUE)

sitesCA <- getNWISSites(stateCd="CA",outputDataTypeCd="dv",
                        hasDataTypeCd="dv")


dataCA <- getNWISData(stateCd="WI",
                      parameterCd="00060",
                      statCd="00003")

dataCA_90s <- getNWISData(stateCd="WI",
                          parameterCd="00060",
                          statCd="00003",
                          startDT="1990-01-01",
                          endDT="1999-12-31")

sitesCA <- getRDB1Data("http://waterservices.usgs.gov/nwis/site/?format=rdb&stateCd=ca&seriesCatalogOutput=true&outputDataTypeCd=dv&hasDataTypeCd=dv",asDateTime = FALSE)


# Get sites:
library(dplyr)

allData <- getWQPData(siteid="USGS-04085435")
characteristics <- unique(allData$CharacteristicName)

df <- group_by(allData, CharacteristicName)
summary <- summarise(df, 
                     startDate = min(ActivityStartDate, na.rm = TRUE),
                     endDate = max(ActivityStartDate, na.rm = TRUE),
                     count = n()
                     )