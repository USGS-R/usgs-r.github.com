library(dataRetrieval)
library(dplyr)
library(USGSHydroTools)

# NWIS search gives an error:
# sitesNWIS <- getNWISSites(parameterCd="00665",huc="0410")


# Water Quality Portal search:

# First look for sites with 50 observations:
parameter <- "00665"
data <- getWQPData(huc="0410*", characteristicName="Phosphorus")

sites <-  getWQPSites(huc="0410*", characteristicName="Phosphorus")

data_bySite <- group_by(data, MonitoringLocationIdentifier)
summarize <-  summarise(data_bySite,
                        Count = n(),
                        CountAfter2000 = sum(ActivityStartDateTime > 
                                               as.POSIXct("2000-01-01 00:00:00"),na.rm = TRUE),
                        MinDate = min(ActivityStartDateTime, na.rm = TRUE),
                        MaxDate = max(ActivityStartDateTime, na.rm = TRUE)) %.%
  arrange(desc(Count))  %.%
  filter(Count >= 50) %.%
  filter(CountAfter2000 >= 10)


sumStation <- merge(summarize, sites, by="MonitoringLocationIdentifier", all.x=TRUE)


latVar <- "LatitudeMeasure"
lonVar <- "LongitudeMeasure" 

mainTitle <- "All sites measuring Phosphorous"

xmin <- min(sumStation[,lonVar],na.rm = TRUE)-3
xmax <- max(sumStation[,lonVar],na.rm = TRUE)+1
ymin <- min(sumStation[,latVar],na.rm = TRUE)-.5
ymax <- max(sumStation[,latVar],na.rm = TRUE)+.5

#legend upper left corner:
xleft <- xmin + 0.2
ytop <- 0.85*(ymax-ymin) + ymin

MapLocations(sites,latVar,lonVar,
             xmin,xmax,ymin,ymax,mainTitle=mainTitle,
             includeLabels=FALSE)

#############################################################

sizeVar <- "Count"
colorVar <- "CountAfter2000"
latVar <- "LatitudeMeasure"
lonVar <- "LongitudeMeasure" 
mainTitle <- ""

sizeThresh <- c(100,1000)
colThresh <- round(quantile(sumStation[,colorVar],probs = c(.25,.5,.75),na.rm=TRUE))

colText <- expression(bold(atop("Color represents","number of samples since 2000")))

sizeText <- expression(bold(atop("Size represents","total number of samples")))

MapSizeColor(sumStation,colorVar,sizeVar,latVar,lonVar,sizeThresh, colThresh,
             titlePos=-1,colText=colText,sizeText=sizeText,
             xmin,xmax,ymin,ymax,xleft=xleft,ytop=ytop,
             mainTitle=mainTitle,includeLabels=FALSE)


siteIDs <- sapply(strsplit(sumStation$MonitoringLocationIdentifier, "-"), function(x) x[2])
sumStation$siteIDs <- siteIDs

dataAvail <- getNWISDataAvailability(siteIDs,type = "dv")
dischargeAvailable <- filter(dataAvail, parameter_cd == "00060") %.%
  select(site_no, Qstart=startDate, Qend=endDate, Qcount=count)

mergedInfo <- merge(sumStation,dischargeAvailable, by.x="siteIDs", by.y="site_no")
mergedInfo <- select(mergedInfo, siteIDs, Count, CountAfter2000, 
                     MinDate, MaxDate, Qstart, Qend, Qcount, 
                     LatitudeMeasure, LongitudeMeasure)
mergedInfo$MinDate <- as.Date(mergedInfo$MinDate)
mergedInfo$MaxDate <- as.Date(mergedInfo$MaxDate)
