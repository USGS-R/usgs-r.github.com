########################################
#Do once:
install.packages(c("GSqwsr","dataRetrieval"), 
                 repo=c("http://usgs-r.github.com",
                        "http://cran.us.r-project.org"),
                 dependencies=TRUE,type="both")
########################################

library(rloadest)
library(GSqwsr)
library(dataRetrieval)

  #Good model:
site <- "04085427"
j <- "Phosphorus_WW.P"

#   #Bad model:
# site <- "040851385"
# j <- "OrthoPhosphate.P"

QWList <- c("00940","00608","00613","00631","62855","00671","00665","80154","00618")
UVPList <- c("00010", "00060", "00095", "00400", "63680", "00300") 

QWcodes <- whatQW(site, minCount=20, endDate="2013-09-30",ignoreGroups="Information")

siteINFO <-  getSiteFileData(site, interactive=FALSE)
whatUV <- getDataAvailability(site, type="uv")
whatDV <- getDataAvailability(site, type="dv")

QWcodes <- QWcodes[which(QWcodes$parameter_cd %in% QWList),]
pcodeINFO <- parameterCdFile[parameterCdFile$parameter_cd %in% QWcodes$parameter_cd,]
QWcodes <- merge(QWcodes,pcodeINFO,by="parameter_cd")

UVP <- unique(whatUV$parameter_cd[which(whatUV$parameter_cd %in% UVPList)])
DVP <- unique(whatDV$parameter_cd[which(whatDV$parameter_cd %in% UVPList)])

BeginDate <- max(whatUV$startDate[which(whatUV$parameter_cd %in% UVP)])
EndDate <- ""

QW <- importNWISqw(site, params=QWList, begin.date=as.Date("2010-01-01"))
QW$datetime <- as.POSIXct(paste(QW$sample_dt," ",QW$sample_tm, ":00",sep=""),tz="UTC")

UV <- getMultipleUV(site, as.character(BeginDate), EndDate, UVP)

save.image(file=paste(site,j,"RData",sep="."))

#################################################################
#Replace all estimated UV days with daily value
UV$DATE <- as.POSIXct(UV$datetime, format="%Y%m%d")
UV$DATE <- (substr(UV$datetime,1,10))
UV$DATE <- as.Date(UV$DATE)

DailyQ <- renameColumns(retrieveNWISData(siteINFO$site.no, "00060",as.character(BeginDate), EndDate))
DailyQ$DATE <- DailyQ$datetime
Daily_E <- DailyQ[which(DailyQ$Discharge_cubic_feet_per_second_cd=="A:e"),]

UV_new <- merge(UV, Daily_E[,c("datetime","Discharge_cubic_feet_per_second")],
                by.x="DATE",by.y="datetime", all.x=TRUE)

UV_new$Discharge_cubic_feet_per_second[is.na(UV_new$Discharge_cubic_feet_per_second)] <- UV_new$Flow[is.na(UV_new$Discharge_cubic_feet_per_second)]
UV_new$Flow <- UV_new$Discharge_cubic_feet_per_second
UV_new$Discharge_cubic_feet_per_second <- NULL

UV <- UV_new
UV$Flow[is.na(UV$Flow)] <- merge(UV[is.na(UV$Flow),], DailyQ[,c("datetime","Discharge_cubic_feet_per_second")],
                                 by.x="DATE",by.y="datetime", all.x=TRUE)$Discharge_cubic_feet_per_second
rm(UV_new)
###################################################################


##################################
# Smooth the negative Flow values

negativeFlows <- UV[UV$Flow <= 0 & !is.na(UV$Flow),]

if(nrow(negativeFlows) > 0){
}

mergeReturn <- mergeDatasets(QW, UV, QWcodes)
DTComplete <- mergeReturn$DTComplete
QWcodes <- mergeReturn$QWcodes

transformResponse <- "lognormal"
DT <- DTComplete[c(j,getPredictVariables(names(UV)), "decYear","sinDY","cosDY","datetime")]
DT <- na.omit(DT)

predictVariables <- names(DT)[-which(names(DT) %in% j)]
predictVariables <- predictVariables[which(predictVariables != "datetime")]

kitchenSink <- createFullFormula(DT,j)

returnPrelim <- prelimModelDev(DT,j,kitchenSink,
                               "BIC", 
                               transformResponse)

steps <- returnPrelim$steps
modelResult <- returnPrelim$modelStuff
modelReturn <- returnPrelim$DT.mod

pdf(paste(site,j,"ModelSummary.pdf",sep="."),width=11,height=9)
resultPlots(DT,modelReturn,siteINFO)
dev.off()
shell.exec(paste(site,j,"ModelSummary.pdf",sep="."))

pdf(paste(site,j,"Predictions.pdf",sep="."),width=11,height=9)
possibleError <- tryCatch(
  predictionPlot(UV,DT,modelReturn,transformResponse,siteINFO),
  error=function(e) e
)


if(!inherits(possibleError, "error")){
  #REAL WORK
} else {
  cat(i,": ",j," didn't run predict plot\n",sep="")
  plot(1:10)
}
dev.off()
shell.exec(paste(site,j,"Predictions.pdf",sep="."))



summaryPrintout(modelReturn, siteINFO, saveOutput=FALSE,fileName)
EO_bias <- sum(DT$Flow*modelReturn$YPRED)/sum(DT$Flow*DT[[j]]@.Data[,2])
cat("E/O bias: ",EO_bias)



