# Normal workflow:
library(USGSwsQWSR)
library(dataRetrieval)

siteTable <- siteTable

AustinList <- c("00940","00608","00613","00631","62855","00671","00665","80154","00618")

for (i in siteTable$shortName){
  cat(i, "\n")
  
  pathToSave <- paste("M:/QW Monitoring Team/GLRI Nutrients/GLRI nutrients/Regressions/DataForModels2/",i,sep="")
      
  load(file=paste(pathToSave,"QW.RData",sep="/"))
  load(file=paste(pathToSave,"UV.RData",sep="/"))
  load(file=paste(pathToSave,"QWcodes.RData",sep="/"))
  load(file=paste(pathToSave,"DTComplete.RData",sep="/"))
  load(file=paste(pathToSave,"siteINFO.RData",sep="/"))
  
  if ("Jones" == i){
    UV$datetime <- UV$datetime.left
  }
    
  for (j in QWcodes$colName[QWcodes$parameter_cd != "00671" & QWcodes$parameter_cd != "80154"& QWcodes$parameter_cd != "00061"]){
    
    pathToSaveNew <- paste(pathToSave,j,sep="/")
    
    if ("Phosphorus_WW.P" == j) pathToSaveNew <- paste(pathToSaveNew,"BIC",sep="_")
    dir.create(file.path(pathToSaveNew), showWarnings = FALSE)   
    
    transformResponse <- "lognormal"
    DT <- DTComplete[c(j,getPredictVariables(names(UV)), "decYear","sinDY","cosDY","datetime")]
    DT <- na.omit(DT)

    pathToParam <- paste(pathToSaveNew,"/",j,"ModelParams.csv",sep="")
    choicesNew <- read.csv(pathToParam)
    newFormula <-createFormulaFromDF(choicesNew)
    
    possibleError <- tryCatch(
      modelReturn <- censReg(paste(j," ~ ", newFormula, sep=""), dist=transformResponse, data=DT),
      error=function(e) e
    )
    
    if(!inherits(possibleError, "error")){
          
#       pdf(paste(pathToSaveNew,"/",j,"_prediction.pdf",sep=""))
      possibleError <- tryCatch(
        predictionPlot(UV,DT,modelReturn,transformResponse,siteINFO),
        error=function(e) e
      )
      
      if(!inherits(possibleError, "error")){
        #REAL WORK
      } else {
        cat(i,": ",j," didn't run predict plot\n",sep="")
      }
#     dev.off()
    } else {
      cat(i,": ",j," error in running model\n")
    }
    
  }
    
}


