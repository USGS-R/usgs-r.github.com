library(USGSwsQW)
modelReturn <- censReg(paste(j," ~ ", newFormula, sep=""), dist="lognormal", data=DT)
modelReturn
terms <- attributes(modelReturn$terms)$term.labels

estimateData <- as.lcens(DT[[j]])
calibrationData <- as.matrix(cbind(1,DT[,which(names(DT) %in% terms)]))
rownames(calibrationData) <- NULL
colnames(calibrationData)[1] <- ""

evaluat <- censReg_AMLE.fit(estimateData, calibrationData, "lognormal")
evaluat

UV <- UV[,terms]
UV <- na.omit(UV)

PredictionData <- as.matrix(cbind(1, UV))

rownames(PredictionData) <- NULL
colnames(PredictionData)[1] <- ""

predictedReturn <- censReg_AMLE.pred(evaluat, PredictionData)
predVal <- predictedReturn$BACKEST

#Subset the data to get a smaller dataframe:
UV <- UV[75000:150000,]

PredictionData <- as.matrix(cbind(1, UV))

rownames(PredictionData) <- NULL
colnames(PredictionData)[1] <- ""

predictedReturn <- censReg_AMLE.pred(evaluat, PredictionData)
predVal <- predictedReturn$BACKEST


