
## ----openLibrary, echo=FALSE---------------------------------------------
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)



## ----include=TRUE ,echo=FALSE,eval=TRUE----------------------------------
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, tidy=FALSE,comment="")
knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)



## ----start,eval = FALSE--------------------------------------------------
## library("GSqwsr")
## 
## #Sample data included with package:
## DTComplete <- StLouisDT
## UV <- StLouisUV
## QWcodes <- StLouisQWcodes
## siteINFO <- StLouisInfo
## 
## investigateResponse <- "SuspSed"
## transformResponse <- "lognormal"
## 
## DT <- DTComplete[c(investigateResponse,
##                    getPredictVariables(names(UV)),
##                    "decYear","sinDY","cosDY","datetime")]
## DT <- na.omit(DT)
## 
## predictVariables <- names(DT)[-which(names(DT)
##                   %in% c(investigateResponse,"datetime","decYear"))]
## 
## 
## #Check predictor variables
## predictVariableScatterPlots(DT,investigateResponse)
## 
## # Create 'kitchen sink' formula:
## kitchenSink <- createFullFormula(DT,investigateResponse)
## 
## #Run stepwise regression with "kitchen sink" as upper bound:
## returnPrelim <- prelimModelDev(DT,investigateResponse,kitchenSink,
##                                "BIC", #Other option is "AIC"
##                                transformResponse)
## 
## steps <- returnPrelim$steps
## modelResult <- returnPrelim$modelInformation
## modelReturn <- returnPrelim$DT.mod
## 
## # Analyze steps found:
## plotSteps(steps,DT,transformResponse)
## analyzeSteps(steps, investigateResponse,siteINFO)
## 
## # Analyze model produced from stepwise regression:
## resultPlots(DT,modelReturn,siteINFO)
## resultResidPlots(DT,modelReturn,siteINFO)
## 
## # Create prediction plots
## predictionPlot(UV,DT,modelReturn,siteINFO=siteINFO)
## 


## ----openGSqwsr,echo=TRUE,eval=FALSE-------------------------------------
## library(GSqwsr)


## ----openGSqwsrHidden,echo=FALSE,eval=TRUE, message=FALSE----------------
library(GSqwsr)


## ----whatQW,echo=TRUE,eval=TRUE------------------------------------------

site <- "04024000"  
QWcodes <- whatQW(site, minCount=20)
head(QWcodes)


## ----importNWISqw,echo=TRUE,eval=FALSE-----------------------------------
## pCodeQW <- c("00608","00613","00618","00631","00665",
##              "00671","00940","62855","80154")
## startDate <- "2011-03-17"
## endDate <- ""
## QW <- importNWISqw(site, params=pCodeQW,
##                    begin.date=startDate, end.date=endDate)


## ----importNWISqwHidden,echo=FALSE,eval=TRUE-----------------------------
pCodeQW <- c("00608","00613","00618","00631","00665",
             "00671","00940","62855","80154")
startDate <- "2011-04-22"
endDate <- ""
QW <- StLouisQW


## ----qwColNames,echo=TRUE,eval=TRUE--------------------------------------
names(QW)


## ----makeQWObjects,echo=TRUE,eval=FALSE----------------------------------
## 
## QWRaw <- retrieveNWISqwData(site,pCodeQW,startDate,
##                             endDate,expanded=TRUE)
## QW <- makeQWObjects(QWRaw)


## ----getDataAvailability,echo=TRUE,eval=TRUE-----------------------------
UVcodes <- getDataAvailability(site)
UVcodes <- UVcodes[UVcodes$service == "uv",]
names(UVcodes)
UVcodes$parameter_cd


## ----getMultipleUV,echo=TRUE,eval=FALSE----------------------------------
## UVpCodes <- c("00010","00060","00095","00300","00400","63680")
## UV <- getMultipleUV(site, startDate, endDate, UVpCodes)
## 


## ----getMultipleUVHidden,echo=FALSE,eval=TRUE----------------------------
UVpCodes <- c("00010","00060","00095","00300","00400","63680")
UV <- StLouisUV


## ----uvColNames,echo=TRUE,eval=TRUE--------------------------------------
names(UV)


## ----mergeDatasets,echo=TRUE,eval=TRUE-----------------------------------
mergeReturn <- mergeDatasets(QW, UV, QWcodes)
DTComplete <- mergeReturn$DTComplete
QWcodes <- mergeReturn$QWcodes


## ----getDT,echo=TRUE,eval=TRUE-------------------------------------------
investigateResponse <- "Chloride"
predictionVariables <- getPredictVariables(names(UV))

DT <- DTComplete[c(investigateResponse,
                   predictionVariables, 
                   "decYear","sinDY","cosDY","datetime")]

names(DT)


## ----rmNADT,echo=TRUE,eval=TRUE------------------------------------------
DT <- na.omit(DT)


## ----plotQQTransforms,echo=TRUE,eval=TRUE,fig.cap="plotQQTransforms"-----
plotQQTransforms(DT,investigateResponse)


## ----predictVariableScatterPlots,echo=TRUE,eval=TRUE,fig.cap="predictVariableScatterPlots", message=FALSE----
predictVariableScatterPlots(DT,investigateResponse)


## ----createFullFormula,echo=TRUE,eval=TRUE,echo=TRUE---------------------
upperBoundFormula <- createFullFormula(DT,investigateResponse)


## ----createFullFormula2,echo=TRUE,eval=TRUE,echo=FALSE,results='markup'----
substring(upperBoundFormula, first=0,last=59)
substring(upperBoundFormula, first=60,last=119)


## ----prelimModelDev,echo=TRUE,eval=TRUE,echo=TRUE------------------------
transformResponse <- "lognormal"

returnPrelim <- prelimModelDev(DT,
                 investigateResponse,
                 upperBoundFormula,
                 "BIC", #Other option is "AIC"
                 transformResponse)

steps <- returnPrelim$steps
modelResult <- returnPrelim$modelInformation
modelReturn <- returnPrelim$DT.mod


## ----analyzeSteps,echo=TRUE,eval=TRUE,echo=TRUE,fig.cap="analyzeSteps"----
siteINFO <- getSiteFileData(site, interactive=FALSE)
analyzeSteps(steps, investigateResponse,siteINFO)


## ----plotSteps,echo=TRUE,eval=TRUE,echo=TRUE,fig.cap="plotSteps"---------
plotSteps(steps,DT,transformResponse)


## ----resultPlots,echo=TRUE,eval=TRUE,echo=TRUE,fig.cap="resultPlots"-----
resultPlots(DT,modelReturn,siteINFO)


## ----resultResidPlots,echo=TRUE,eval=TRUE,echo=TRUE,fig.cap="resultResidPlots"----
resultResidPlots(DT,modelReturn,siteINFO)


## ----predictionPlot,echo=TRUE,eval=TRUE,echo=TRUE,fig.cap="predictionPlot"----
predictionPlot(UV,DT,modelReturn,siteINFO=siteINFO)


## ----summaryPrintout,echo=TRUE,eval=TRUE,echo=TRUE-----------------------
summaryPrintout(modelReturn, siteINFO, saveOutput=FALSE,fileName)


## ----helpFunc,eval = FALSE-----------------------------------------------
## library(GSqwsr)
## ?plotSteps


## ----rawFunc,eval = FALSE------------------------------------------------
## plotSteps


## ----installFromCran,eval = FALSE----------------------------------------
## install.packages(c("XML", "lubridate", "akima", "KernSmooth",
##                    "leaps", "car", "mvtnorm", "digest",
##                    "relimp", "BSDA", "RODBC","memoise",
##                    "boot","survival","splines","RColorBrewer",
##                    "lattice","MASS"), dependencies=TRUE)
## install.packages(c("USGSwsBase","USGSwsData","dataRetrieval",
##                    "USGSwsGraphs","USGSwsStats",
##                    "USGSwsQW","GSqwsr"),
##                  repos="http://usgs-r.github.com")


## ----openLibraryTest, eval=FALSE-----------------------------------------
## library(GSqwsr)


