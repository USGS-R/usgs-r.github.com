# install.packages("GSHydroTools", repo="http://usgs-r.github.com")

library(GSHydroTools)

#computeSeasonal example
sampleData <- sampleData
sampleData$bpdate <- as.POSIXlt(sampleData$Hbpdate) #convert from POSIXct to POSIXlt
computeSeasonal(df=sampleData,date="bpdate",return.var="bdate")

########################
#Hydrovol example
sampleData <- sampleData
flowData <- flowData
Hydrovol(dfQ=flowData,
         Q="Q",
         time="pdate",
         df.dates=sampleData,
         bdate="Hbpdate",
         edate="Hepdate")

#Plot the hydrograph
plot(flowData$Q~flowData$pdate,
     xlim=as.POSIXct(c("2009-10-01","2009-11-10")),
     ylim=c(0,2000),
     type="l",col="blue")


########################
#loadInstantaneous example
#library(dataRetrieval)
# WQdata <- retrieveNWISqwData(siteNumber="04087120",pCodes="00665",startDate="2009-10-01",endDate="2009-10-31",interactive=FALSE)
# Qdata <- retrieveUnitNWISData(siteNumber="04087120",ParameterCd="00060",StartDate="2009-10-01",EndDate="2009-10-31",format="xml",interactive=FALSE)
WQdata <- WQdata
WQdata$pdate <- as.POSIXct(format(WQdata$dateTime,tz="UTC",usetz=TRUE),tz="CST6CDT")
# as.POSIXct(format(as.POSIXct(df$pdate),tz="GMT",usetz=TRUE),tz="GMT")
flowData <- flowData
WQload <- LoadInstantaneous(df.samples=WQdata,
                            Conc="Total_P",
                            sample.time="dateTime",
                            Conc2liters=1,
                            df.Q=flowData,Q="Q",
                            Q.time="pdate",
                            Q2liters=28.3168466)



#Define individual sampling event periods
WQload$eventID <- c(rep(x=1,times=5),2,rep(3,7),rep(4,5))

#Now sum the loads for each event period indicated by the eventID
tapply(X=WQload$loads,INDEX=WQload$eventID,FUN=sum)




########################
#TSstats example

#Determine mean antecedent flow for XX windows of time preceding event periods

#First find beginning dates for event periods

bdates <- aggregate(x=WQload$bpdate,by=list(WQload$eventID),FUN=min)


Qstats <- TSstats(df=flowData,
                  date="pdate",
                  varnames="Q",
                  dates=WQload,
                  starttime="dateTime",
                  times=c(3,6),
                  units="hrs",
                  stats.return=c("mean","max","sd"),
                  out.varname="Q")



########################
#TSstormstats example

#Find beginning and ending dates/times of the event periods
bsdates <- aggregate(x=WQload$bpdate,by=list(WQload$eventID),FUN=min)
esdates <- aggregate(x=WQload$epdate,by=list(WQload$eventID),FUN=max)

#Name the columns appropriately
names(bsdates) <- c("eventID","bsdate")
names(esdates) <- c("eventID","esdate")

#merge the beginning and ending dates/times into one dataframe
eventDates <- merge(bsdates,esdates,by="eventID")
arrows(x0=eventDates$bsdate,y0=1200,x1=eventDates$esdate,y1=1200,code=3)


#Compute storm stats
eventStats<- TSstormstats(df=flowData,
                          date="pdate",
                          varname="Q",
                          dates=eventDates,
                          starttime="bsdate",
                          endtime="esdate",
                          stats.return=c("mean","max","sd","median","difference"),
                          out.varname="Q")





##########################################
#mapColor example
lat <- SI$lat
lon <-  SI$lon
y <- runif(n=length(lat),min=0,max=50)
df <- data.frame(y=y, lat=lat,lon=lon)
colorVar <- "y"
latVar <- "lat"
lonVar <- "lon"

politicalBounds <- shape_poliboundsClip
hydroPolygons <- subShape_hydropolyClip
hydroLines <- shape_hydrolineClip
xmin <- -96.5
xmax <- -72
ymin <- 40.5
ymax <- 49.5
xleft <- -95
ybottom <- 40.7
xright <- -90.8
ytop <- 43.5
mainTitle <- "OC Pesticides"

#Without labels

#Example works best in a landscape view:
pdf("GreatLakesExamplePlotNoLabels.pdf",width=11,height=8)
MapColor(df,colorVar,latVar,lonVar,
         politicalBounds,hydroPolygons,hydroLines,
         xmin,xmax,ymin,ymax,xleft=xleft,xright=xright,ytop=ytop,ybottom=ybottom,mainTitle=mainTitle,
         includeLabels=FALSE)
dev.off()
#To view the produced plot, us the following command:
shell.exec("GreatLakesExamplePlotNoLabels.pdf")

# With labels:
df <- merge(df, SI, by=c("lat","lon"))
labelVar <- "Site"
offsetLatVar <- "offsetLat"
offsetLonVar <- "offsetLon"
offsetLineLatVar <- "offsetLineLat"
offsetLineLonVar <- "offsetLineLon"
#Example works best in a landscape view:
pdf("GreatLakesExamplePlot.pdf",width=11,height=8)
MapColor(df,colorVar,latVar,lonVar,
         politicalBounds,hydroPolygons,hydroLines,
         xmin,xmax,ymin,ymax,xleft=xleft,xright=xright,ytop=ytop,ybottom=ybottom,mainTitle=mainTitle,includeLabels=TRUE,
         labels=labelVar, offsetLat=offsetLatVar, offsetLon=offsetLonVar,offsetLineLat=offsetLineLatVar,
         offsetLineLon=offsetLineLonVar)
dev.off()
#To view the produced plot, us the following command:
shell.exec("GreatLakesExamplePlot.pdf")




##########################################
#mapSizeColor example

lat <- SI$lat
lon <-  SI$lon
y <- runif(n=length(lat),min=0,max=50)
count <- round(runif(n=length(lat),min=0,max=30),0)
df <- data.frame(y=y, lat=lat,lon=lon,count=count)

colorVar <- "y"
sizeVar <- "count"
latVar <- "lat"
lonVar <- "lon"

politicalBounds <- shape_poliboundsClip
hydroPolygons <- subShape_hydropolyClip
hydroLines <- shape_hydrolineClip
xmin <- -96.5
xmax <- -72
ymin <- 40.5
ymax <- 49.5
xleft <- -95
ybottom <- 40.4
xright <- -90.8
ytop <- 45.3
sizeThresh1 <- 2
sizeThresh2 <- 14
mainTitle <- "Colors vary by concentration"

# Without labels:

#Example works best in a landscape view:
pdf("GreatLakesExamplePlotNoLabels2.pdf",width=11,height=8)
MapSizeColor(df,colorVar,sizeVar,latVar,lonVar,sizeThresh1,sizeThresh2,
             politicalBounds,hydroPolygons,hydroLines,
             xmin,xmax,ymin,ymax,xleft=xleft,xright=xright,ytop=ytop,
             ybottom=ybottom,mainTitle=mainTitle,includeLabels=FALSE)
dev.off()
#To view the produced plot, us the following command:
shell.exec("GreatLakesExamplePlotNoLabels2.pdf")

# With labels:

df <- merge(df, SI, by=c("lat","lon"))
labelVar <- "Site"
offsetLatVar <- "offsetLat"
offsetLonVar <- "offsetLon"
offsetLineLatVar <- "offsetLineLat"
offsetLineLonVar <- "offsetLineLon"

#Example works best in a landscape view:
pdf("GreatLakesExamplePlot2.pdf",width=11,height=8)
MapSizeColor(df,colorVar,sizeVar,latVar,lonVar,sizeThresh1,sizeThresh2,
             politicalBounds,hydroPolygons,hydroLines,
             xmin,xmax,ymin,ymax,xleft=xleft,xright=xright,ytop=ytop,ybottom=ybottom,mainTitle=mainTitle,includeLabels=TRUE,
             labels=labelVar, offsetLat=offsetLatVar, offsetLon=offsetLonVar,offsetLineLat=offsetLineLatVar,
             offsetLineLon=offsetLineLonVar)
dev.off()
#To view the produced plot, us the following command:
shell.exec("GreatLakesExamplePlot2.pdf")


########################################################################
# MapLocations example: map locations with no size or color variation

lat <- SI$lat
lon <-  SI$lon
df <- data.frame(lat=lat,lon=lon)
latVar <- "lat"
lonVar <- "lon"

politicalBounds <- shape_poliboundsClip
hydroPolygons <- subShape_hydropolyClip
hydroLines <- shape_hydrolineClip
xmin <- -96.5
xmax <- -72
ymin <- 40.5
ymax <- 49.5
mainTitle <- "Site Locations"

#Without labels

#Example works best in a landscape view:
pdf("GreatLakesExamplePlotNoLabels3.pdf",width=11,height=8)
MapLocations(df,latVar,lonVar,
             politicalBounds,hydroPolygons,hydroLines,
             xmin,xmax,ymin,ymax,mainTitle=mainTitle,
             includeLabels=FALSE)
dev.off()
#To view the produced plot, us the following command:
shell.exec("GreatLakesExamplePlotNoLabels3.pdf")

SI <- SI

# With labels:
df <- merge(df, SI, by=c("lat","lon"))
labelVar <- "Site"
offsetLatVar <- "offsetLat"
offsetLonVar <- "offsetLon"
offsetLineLatVar <- "offsetLineLat"
offsetLineLonVar <- "offsetLineLon"
#Example works best in a landscape view:
pdf("GreatLakesExamplePlot3.pdf",width=11,height=8)
MapLocations(df,latVar,lonVar,
             politicalBounds,hydroPolygons,hydroLines,
             xmin,xmax,ymin,ymax,mainTitle=mainTitle,includeLabels=TRUE,
             labels=labelVar, offsetLat=offsetLatVar, offsetLon=offsetLonVar,offsetLineLat=offsetLineLatVar,
             offsetLineLon=offsetLineLonVar)
dev.off()
#To view the produced plot, us the following command:
shell.exec("GreatLakesExamplePlot3.pdf")
