####################################################
# Only do once:
#This is Laura's fork:
install.packages("//IGSARMEWFSAPA/projects/QW Monitoring Team/R_fxns/GSHydroTools_1.0.2.tar.gz", repo=NULL, type="source")
#Latest dataRetrieval:
install.packages("//IGSARMEWFSAPA/projects/QW Monitoring Team/R_fxns/dataRetrieval_1.3.2.tar.gz", repo=NULL, type="source")

#####################################################
library(dataRetrieval)
library(GSHydroTools)

siteListWI <- getWQPSites(statecode="US:55")
# siteListWI <- siteListWI[siteListWI$MonitoringLocationTypeName != "Well",]

# Toledo, OH:
ymin <- min(as.numeric(siteListWI$LatitudeMeasure, na.rm = TRUE))-.5
ymax <- max(as.numeric(siteListWI$LatitudeMeasure, na.rm = TRUE))+.5
xmin <- min(as.numeric(siteListWI$LongitudeMeasure, na.rm = TRUE))-.5
xmax <- max(as.numeric(siteListWI$LongitudeMeasure, na.rm = TRUE))+.5
mainTitle <- "WI Sampling Sites"

df <- data.frame(lat=as.numeric(siteListWI$LatitudeMeasure),
                 lon=as.numeric(siteListWI$LongitudeMeasure),
                 stringsAsFactors = FALSE)
latVar <- "lat"
lonVar <- "lon"

pdf("BigMap.pdf")
MapLocations(df,latVar,lonVar,
             xmin,xmax,ymin,ymax,mainTitle=mainTitle,
             includeLabels=FALSE)
dev.off()
shell.exec("BigMap.pdf")

ymin <- 40
ymax <- 48
xmin <- -100
xmax <- -75
MapLocations(df,latVar,lonVar,
             xmin,xmax,ymin,ymax,mainTitle=mainTitle,
             includeLabels=FALSE)

#Something like....
siteListWI[,c("LatitudeMeasure","LongitudeMeasure")]




