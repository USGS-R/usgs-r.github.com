EflowStats
===========

Calculates Hydrologic Indicator stats and fundamental properties of daily streamflow for a given set of data

To install this package use the following code:
install.packages("EflowStats",repos="http://usgs-r.github.com",type="source")
