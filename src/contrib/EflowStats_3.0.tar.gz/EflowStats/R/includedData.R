#' This is data to be included in my package
#'
#' @name obs_data
#' @docType data
#' @author Jessica Thompson \email{jlthomps@@usgs.gov}
#' @keywords data
NULL

#' Example data
#'
#' Example data 
#'
#' @name sampleData
#' @docType data
#' @keywords streamflow data
NULL