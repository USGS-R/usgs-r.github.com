USGSwsData
==========

Data sets as data.frames and as text files for examples in the USGS core pacakges