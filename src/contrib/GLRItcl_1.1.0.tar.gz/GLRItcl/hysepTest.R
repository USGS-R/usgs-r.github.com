library("GLRItcl")

#Available data:

QWPortalGLRI <- QWPortalGLRI
pcodeINFO <- pcodeINFO
stationINFO <- stationINFO

genericCensoringValue <- function(qualifier,value, detectionLimit){
  valueToUse <- ifelse("<" == qualifier, 0, value)    
  return(valueToUse)
}

QWPull_OWC_useful <- filterBlanks(QWPortalGLRI)
QWPull_OWC_blanks <- QWPortalGLRI[!(c(1:nrow(QWPortalGLRI)) %in% QWPull_OWC_useful$index),]

# stationINFO$shortName[stationINFO$fullSiteID == "USGS-04193500" | stationINFO$fullSiteID == "USGS-04193490"] <- "Maumee"
# stationINFO$shortName[stationINFO$fullSiteID == "USGS-04157005" | stationINFO$fullSiteID == "USGS-04157000"] <- "Saginaw"

siteList <- setNames(stationINFO$shortName,stationINFO$fullSiteID)

# Sum values in all classes:
wideOWC <- wideGLRIData(filterGLRIData(QWPull_OWC_useful, genericCensoringValue))
wideOWC$flowCondition <- ifelse(wideOWC$HydrologicCondition=="Stable, low stage" | wideOWC$HydrologicCondition=="Stable, normal stage","Baseflow","Event")
wideOWC$flowCondition[grep("Storm",wideOWC$HydrologicEvent)] <- "Event"
wideOWC$flowCondition <- factor(wideOWC$flowCondition)


#Maumee
wideOWC$site <- ifelse(wideOWC$site=="USGS-04193500" | wideOWC$site=="USGS-04193490","USGS-04193500",wideOWC$site)
#Saginaw
wideOWC$site <- ifelse(wideOWC$site=="USGS-04157005" | wideOWC$site=="USGS-04157000","USGS-04157005",wideOWC$site)
wideOWC$labelName <- siteList[wideOWC$site]

pcodeINFO <- pcodeINFO[pcodeINFO$water_or_sediment == "water",]

OWCdataByClassFull <- PCodeClassSummary(wideOWC,pcodeINFO,"parameter_cd","class",merge=TRUE)
OWCSummaryFull <- statClassSummary(OWCdataByClassFull)
OWCSummaryFull$shortName <- as.character(siteList[OWCSummaryFull$site])
# subsummaryFull <- OWCSummaryFull[OWCSummaryFull$class == "HERBICIDE",c("site","count","startDate","endDate","station.nm")]
OWCdataByClassFull$flowCondition <- ifelse(OWCdataByClassFull$HydrologicCondition=="Stable, low stage" | OWCdataByClassFull$HydrologicCondition=="Stable, normal stage","Baseflow","Event")
OWCdataByClassFull$flowCondition[grep("Storm",OWCdataByClassFull$HydrologicEvent)] <- "Event"
OWCdataByClassFull$flowCondition <- factor(OWCdataByClassFull$flowCondition)

OWCdataByClassFull$labelName <- siteList[OWCdataByClassFull$site]

library(DVstats)
library(dataRetrieval)
source("D:/LADData/RCode/GLRI/plotBoxPlotSets_Single.R")
source("D:/LADData/RCode/GLRI/plotBoxPlotSets_Multiple.R")
# 
# stationINFO$dischargeSites <- stationINFO$STAID
# stationINFO$dischargeSites["04119400" == stationINFO$STAID] <- "04119000"
# stationINFO$dischargeSites["04126010" == stationINFO$STAID] <- "04125550"
# stationINFO$dischargeSites["04128500" == stationINFO$STAID] <- "04127997"
# stationINFO$dischargeSites["04132052" == stationINFO$STAID] <- "04127997"
# stationINFO$dischargeSites["04135020" == stationINFO$STAID] <- "04133501"
# stationINFO$dischargeSites["04043000" == stationINFO$STAID] <- "04041500"
# stationINFO$dischargeSites["04157000" == stationINFO$STAID] <- "04151500"
# stationINFO$dischargeSites["04095090" == stationINFO$STAID] <- "04094000"
# stationINFO$dischargeSites["04032000" == stationINFO$STAID] <- "04036000"
# stationINFO$dischargeSites["04126000" == stationINFO$STAID] <- "04125550"
# stationINFO$dischargeSites["04193490" == stationINFO$STAID] <- "04193500"
# stationINFO$dischargeSites["04160900" == stationINFO$STAID] <- "04161000"
# stationINFO$dischargeSites["410832081262100" == stationINFO$STAID] <- "04206000"
# stationINFO$dischargeSites["04200000" == stationINFO$STAID] <- "04200500"
# stationINFO$dischargeSites["04132025" == stationINFO$STAID] <- NA
# 
# 
# stationINFO$distanceToSite <- rep(0,nrow(stationINFO))
# stationINFO$distanceToSite["04119400" == stationINFO$STAID] <- 18
# stationINFO$distanceToSite["04126010" == stationINFO$STAID] <- 17.5
# stationINFO$distanceToSite["04128500" == stationINFO$STAID] <- 9.5
# stationINFO$distanceToSite["04132052" == stationINFO$STAID] <- 25.5
# stationINFO$distanceToSite["04135020" == stationINFO$STAID] <- 10.3
# stationINFO$distanceToSite["04043000" == stationINFO$STAID] <- 14.8
# stationINFO$distanceToSite["04157000" == stationINFO$STAID] <- 12.3
# stationINFO$distanceToSite["04095090" == stationINFO$STAID] <- 4.6
# stationINFO$distanceToSite["04032000" == stationINFO$STAID] <- 11.5
# stationINFO$distanceToSite["04126000" == stationINFO$STAID] <- 12.75
# stationINFO$distanceToSite["04193490" == stationINFO$STAID] <- 2.138
# stationINFO$distanceToSite["04160900" == stationINFO$STAID] <- 8.634
# stationINFO$distanceToSite["410832081262100" == stationINFO$STAID] <- 5.633
# stationINFO$distanceToSite["04200000" == stationINFO$STAID] <- 2.327

wideOWC$date_site <- paste(wideOWC$ActivityStartDateGiven, wideOWC$site, sep="_")
OWCdataByClassFull$date_site <- paste(OWCdataByClassFull$ActivityStartDateGiven, OWCdataByClassFull$site, sep="_")

eventSummary <- data.frame(dateTime=c(as.POSIXct(NA)),site=c(NA),HydrologicCondition=c(NA),HydrologicEvent=c(NA),HYSEP_localMin=c(NA), HYSEP_Sliding=c(NA), HYSEP_Fixed=c(NA))

pdf("Discharge_w_HYSEPcalcsFixed2_70percent.pdf",paper="a4r",width=11.0,height=8.5)
for (i in stationINFO$site.no[!is.na(stationINFO$site.no)][36:69]){
  cat(which(stationINFO$site.no[!is.na(stationINFO$site.no)] %in% i),"\n")
  subSummary <- OWCSummaryFull[OWCSummaryFull$site == paste("USGS",i,sep="-"),]
  
  if (nrow(subSummary) == 0){
    cat("No sample at site,", i, "\n")
    next
  }
  
  dischargeID <- stationINFO$dischargeSites[which(stationINFO$STAID %in% i)]
  whatDischarge <- getDataAvailability(dischargeID)
  whatDischarge <-  whatDischarge[whatDischarge$parameter_cd == "00060", ]
  
  if(nrow(whatDischarge) == 0){
    cat("No discharge at site,", i, "\n")
    next
  }
  
  if(nrow(whatDischarge[whatDischarge$service == "dv",]) == 0){
    cat("No discharge at site,", i, "\n")
    next
  }
  
  INFO <- getSiteFileData(i)

  startYear <- strsplit(as.character(as.Date(min(subSummary$startDate, na.rm=TRUE))),"-")[[1]][1] #don't want to do just start and end year
  endYear <- strsplit(as.character(as.Date(max(subSummary$endDate, na.rm=TRUE))),"-")[[1]][1]
  Start <- as.character(as.Date(min(subSummary$startDate, na.rm=TRUE))-60)
  End <- as.character(as.Date(max(subSummary$endDate, na.rm=TRUE))+60)
    
  Daily <- getDVData(dischargeID,'00060', Start, End,convert=FALSE)
    
  subData <- OWCdataByClassFull[OWCdataByClassFull$site == paste("USGS",i,sep="-"),]
  subData$Date <- as.Date(subData$ActivityStartDateGiven)
  
  if ("uv" %in% whatDischarge$service){
    instantFlow <- retrieveUnitNWISData(dischargeID,"00060",as.character(as.Date(min(subSummary$startDate, na.rm=TRUE))),as.character(as.Date(max(subSummary$endDate, na.rm=TRUE))))
    instantFlow <- renameColumns(instantFlow)
    instantFlow$dateTime <- as.POSIXct(strptime(instantFlow$dateTime, format="%Y-%m-%d %H:%M:%S"), tz="UTC")
    
    minDate <- min(instantFlow$dateTime, na.rm=TRUE)
    maxDate <- max(instantFlow$dateTime, na.rm=TRUE) 
    
    if(minDate < min(subSummary$startDate, na.rm=TRUE) & maxDate > max(subSummary$startDate, na.rm=TRUE) ){
      subData <- mergeNearest(subData, "ActivityStartDateGiven",right=instantFlow, dates.right="dateTime",max.diff="3 hours")
      subData$site <- subData$site.left
    } else {
      subData <- mergeNearest(subData, "Date",right=Daily, dates.right="Date",max.diff="3 hours")
      subData$Date <- as.Date(subData$Date.left)
      subData$Discharge_cubic_feet_per_second <- subData$Q
    }
    

  } else {
    subData <- mergeNearest(subData, "Date",right=Daily, dates.right="Date",max.diff="3 hours")
    subData$Date <- as.Date(subData$Date.left)
    subData$Discharge_cubic_feet_per_second <- subData$Q
    
  }
  
  naFreeDaily <- Daily[!is.na(Daily$Q),]
  DA_mi <- as.numeric(INFO$drain.area.va)
  
  if(length(DA_mi)>1){
    DA_mi <- DA_mi[!is.na(DA_mi)]
  }
  
  if (is.na(DA_mi)) {
    DA_mi <- 50
    cat("No drainage area for",i,"\n")
  }
  
  dataPoints <- nrow(naFreeDaily)
  difference <- (naFreeDaily$Julian[dataPoints] - naFreeDaily$Julian[1])+1  
  numberOfGaps <- 0
  if (dataPoints != difference){
    for(j in 2:dataPoints) {
      if((naFreeDaily$Julian[j]-naFreeDaily$Julian[j-1])>1){
        startGap <- naFreeDaily$Date[j-1]
        startGapIndex <- j-1
        stopGap <- naFreeDaily$Date[j]
        stopGapIndex <- j
        cat("Gap from", as.character(startGap), "to", as.character(stopGap),"\n")
        numberOfGaps <- 1 + numberOfGaps
      }
    }
  }
  
  if (numberOfGaps == 1){
    maxRange <- which.max(c(startGapIndex, dataPoints-stopGapIndex))
    if (maxRange == 1){
      Start <- naFreeDaily$Date[1]
      End <- naFreeDaily$Date[startGapIndex]
    } else {
      Start <- naFreeDaily$Date[stopGapIndex]
      End <- naFreeDaily$Date[dataPoints]
    }
  }
  
  if (numberOfGaps > 1){
    for(j in 2:dataPoints) {
      if((naFreeDaily$Julian[j]-naFreeDaily$Julian[j-1])>1){
        startGap <- naFreeDaily$Date[j-1]
        startGapIndex <- j-1
        Start <- naFreeDaily$Date[1]
        End <- naFreeDaily$Date[startGapIndex]
        break
      }
    }      
  }
  
  possibleError <- tryCatch( 
    HYSEPReturn_Sliding <- hysep(naFreeDaily$Q, naFreeDaily$Date, Start = Start, End = End, da=DA_mi,
          select = "sliding", STAID = dischargeID),
    error=function(e) e 
  )
  
  if(!inherits(possibleError, "error")){
    
    subData <- mergeNearest(subData, "Date",right=HYSEPReturn_Sliding, dates.right="Dates", max.diff="1 days")
    
    if(any(!is.na(subData$ActivityEndDateGiven))){
      for (k in 1:nrow(subData)){
        if (!is.na(subData$ActivityEndDateGiven[k])) {
          
          if ("uv" %in% whatDischarge$service){
            subFlow <- instantFlow[(instantFlow$dateTime >= subData$ActivityStartDateGiven[k] & instantFlow$dateTime <= subData$ActivityEndDateGiven[k]),] 
          } else {
            subFlow <- Daily[Daily$Date >= as.Date(subData$ActivityStartDateGiven[k]) & Daily$Date <= as.Date(subData$ActivityEndDateGiven[k]),] 
            subFlow$Discharge_cubic_feet_per_second <- subFlow$Q
            subFlow$dateTime <- as.POSIXct(Daily$Date[Daily$Date >= as.Date(subData$ActivityStartDateGiven[k]) & Daily$Date <= as.Date(subData$ActivityEndDateGiven[k])] )
          }
          
          maxFlow <- max(subFlow$Discharge_cubic_feet_per_second, na.rm=TRUE)
          
          if(is.finite(maxFlow)){
            subData$ActivityStartDateGiven[k] <- as.POSIXct(mean(subFlow$dateTime[subFlow$Discharge_cubic_feet_per_second == maxFlow],na.rm=TRUE), tz="UTC")
            subData$Discharge_cubic_feet_per_second[k] <- maxFlow
          }
        }        
      }

    }
    
    #90% criteria:
    subData$flowConditionHYSEP_localMin <- ifelse(0.7*subData$Discharge_cubic_feet_per_second > subData$LocalMin, "Event", "Baseflow")
    subData$flowConditionHYSEP_Sliding <- ifelse(0.7*subData$Discharge_cubic_feet_per_second > subData$Sliding, "Event", "Baseflow")
    subData$flowConditionHYSEP_Fixed <- ifelse(0.7*subData$Discharge_cubic_feet_per_second > subData$Fixed, "Event", "Baseflow")

    
    DFCondition <- data.frame(ActivityStartDateGiven = subData$ActivityStartDateGiven, site = subData$site,flowConditionHYSEP_Sliding = subData$flowConditionHYSEP_localMin)
    
    conditions <- setNames(DFCondition$flowConditionHYSEP_Sliding, paste(DFCondition$ActivityStartDateGiven, DFCondition$site, sep="_"))
    
    ##################################
    mainTitle <- paste(stationINFO$shortName[stationINFO$STAID == i],": ", i,"\nDischarge at:", stationINFO$dischargeSites[stationINFO$STAID == i],
                       ", ", stationINFO$distanceToSite[stationINFO$STAID == i], " miles from the site",sep="")
    
    par(mfrow=c(4,1),mar=c(1,4,0.5,1),oma=c(1,1,2,1)) 
    plot(as.POSIXct(Daily$Date), Daily$Q, type="l",ylim=c(0,max(Daily$Q,na.rm=TRUE)),
         xlab="",ylab="Discharge[cfs]", xaxt="n", tck = 0.02, col="azure4")
    if ("uv" %in% whatDischarge$service){
      lines(instantFlow$dateTime, instantFlow$Discharge_cubic_feet_per_second)
    } 
    polygon(as.POSIXct(c(HYSEPReturn_Sliding$Dates[1], HYSEPReturn_Sliding$Dates,HYSEPReturn_Sliding$Dates[length(HYSEPReturn_Sliding$Dates)])), c(0,HYSEPReturn_Sliding$LocalMin,0), col="grey")
    
    points(subData$ActivityStartDateGiven[subData$flowConditionHYSEP_localMin == "Event"], 
           subData$Discharge_cubic_feet_per_second[subData$flowConditionHYSEP_localMin == "Event"],
           pch=16,col="red",cex=2)
    points(subData$ActivityStartDateGiven[subData$flowConditionHYSEP_localMin == "Baseflow"], 
           subData$Discharge_cubic_feet_per_second[subData$flowConditionHYSEP_localMin == "Baseflow"],
           pch=16,col="blue",cex=2)
    text(grconvertX(0.9, from = "npc", to = "user"), grconvertY(0.9, from = "npc", to = "user"), "LocalMin")
    axis(1,labels=FALSE, tck = 0.02)
    axis(3,labels=FALSE, tck = 0.02)
    axis(4,labels=FALSE, tck = 0.02)
    title(mainTitle,outer=TRUE)
    legend(grconvertX(0.01, from = "npc", to = "user"), grconvertY(0.95, from = "npc", to = "user"), 
           c("Flow (Instantaneous)", "Flow (Daily)","Base","Baseflow Sample","Event Sample"),
           fill=c(NA,NA,"grey",NA,NA),
           pch=c(NA,NA,NA,16,16),
           border=c(NA,NA,"grey",NA,NA),
           lty=c(1,1,NA,NA,NA),
           col=c("black","azure4",NA,"blue","red"))
    
    plot(as.POSIXct(Daily$Date), Daily$Q, type="l",ylim=c(0,max(Daily$Q,na.rm=TRUE)),
         xlab="",ylab="Discharge[cfs]", xaxt="n", tck = 0.02, col="azure4")
    if ("uv" %in% whatDischarge$service){
      lines(instantFlow$dateTime, instantFlow$Discharge_cubic_feet_per_second)
    } 
    polygon(as.POSIXct(c(HYSEPReturn_Sliding$Dates[1],HYSEPReturn_Sliding$Dates,HYSEPReturn_Sliding$Dates[nrow(HYSEPReturn_Sliding)])), c(0,HYSEPReturn_Sliding$Fixed,0), col="grey")
    points(subData$ActivityStartDateGiven[subData$flowConditionHYSEP_Fixed == "Event"], 
           subData$Discharge_cubic_feet_per_second[subData$flowConditionHYSEP_Fixed == "Event"],
           pch=16,col="red",cex=2)
    points(subData$ActivityStartDateGiven[subData$flowConditionHYSEP_Fixed == "Baseflow"], 
           subData$Discharge_cubic_feet_per_second[subData$flowConditionHYSEP_Fixed == "Baseflow"],
           pch=16,col="blue",cex=2)
    text(grconvertX(0.9, from = "npc", to = "user"), grconvertY(0.9, from = "npc", to = "user"), "Fixed")
    axis(1,labels=FALSE, tck = 0.02)
    axis(3,labels=FALSE, tck = 0.02)
    axis(4,labels=FALSE, tck = 0.02)
    
    plot(as.POSIXct(Daily$Date), Daily$Q, type="l",ylim=c(0,max(Daily$Q,na.rm=TRUE)),
         xlab="",ylab="Discharge[cfs]", xaxt="n", tck = 0.02, col="azure4")
    if ("uv" %in% whatDischarge$service){
      lines(instantFlow$dateTime, instantFlow$Discharge_cubic_feet_per_second)
    }
    polygon(as.POSIXct(c(HYSEPReturn_Sliding$Dates[1], HYSEPReturn_Sliding$Dates,HYSEPReturn_Sliding$Dates[nrow(HYSEPReturn_Sliding)])), c(0,HYSEPReturn_Sliding$Sliding,0), col="grey")
    points(subData$ActivityStartDateGiven[subData$flowConditionHYSEP_Sliding == "Event"], 
           subData$Discharge_cubic_feet_per_second[subData$flowConditionHYSEP_Sliding == "Event"],
           pch=16,col="red",cex=2)
    points(subData$ActivityStartDateGiven[subData$flowConditionHYSEP_Sliding == "Baseflow"], 
           subData$Discharge_cubic_feet_per_second[subData$flowConditionHYSEP_Sliding == "Baseflow"],
           pch=16,col="blue",cex=2)
    text(grconvertX(0.9, from = "npc", to = "user"), grconvertY(0.9, from = "npc", to = "user"), "Sliding")
    axis(1,labels=FALSE, tck = 0.02)
    axis(3,labels=FALSE, tck = 0.02)
    axis(4,labels=FALSE, tck = 0.02)
    
    plot(as.POSIXct(Daily$Date), Daily$Q, type="l",ylim=c(0,max(Daily$Q,na.rm=TRUE)),
         xlab="",ylab="Discharge[cfs]", xaxt="n", tck = 0.02, col="azure4")
    if ("uv" %in% whatDischarge$service){
      lines(instantFlow$dateTime, instantFlow$Discharge_cubic_feet_per_second, type="l")
    }
    points(subData$ActivityStartDateGiven[subData$flowCondition == "Event"], 
           subData$Discharge_cubic_feet_per_second[subData$flowCondition == "Event"],
           pch=16,col="red",cex=2)
    points(subData$ActivityStartDateGiven[subData$flowCondition == "Baseflow"], 
           subData$Discharge_cubic_feet_per_second[subData$flowCondition == "Baseflow"],
           pch=16,col="blue",cex=2)
    text(grconvertX(0.9, from = "npc", to = "user"), grconvertY(0.9, from = "npc", to = "user"), "Original")
    axis(3,labels=FALSE, tck = 0.02)
    axis(4,labels=FALSE, tck = 0.02)
    
    ##################################
        
    wideOWC$flowConditionHYSEP[wideOWC$date_site %in% names(conditions)] <- as.character(conditions[wideOWC$date_site[wideOWC$date_site %in% names(conditions)]])
    OWCdataByClassFull$flowConditionHYSEP[OWCdataByClassFull$date_site %in% names(conditions)] <- as.character(conditions[OWCdataByClassFull$date_site[OWCdataByClassFull$date_site %in% names(conditions)]])

    
  } else {
    cat("Error in calling hysep", "\n")
  }
  
  eventSummary <- rbind(eventSummary, data.frame(dateTime=subData$ActivityStartDateGiven,
                        site=subData$site,
                        HydrologicCondition=subData$HydrologicCondition,
                        HydrologicEvent=subData$HydrologicEvent,
                        HYSEP_localMin=subData$flowConditionHYSEP_localMin, 
                        HYSEP_Sliding=subData$flowConditionHYSEP_Sliding,
                        HYSEP_Fixed=subData$flowConditionHYSEP_Fixed))
  
}
dev.off()

eventSummary <- eventSummary[-1,]
# Original
plotNames <- unique(pcodeINFO$class)
for (i in plotNames[!is.na(plotNames)]){
  pdf(paste(sub("/","_",i),"_Original.pdf",sep=""),paper="a4r",width=11.0,height=8.5)
  means <- plotBoxPlotSets_Single(OWCdataByClassFull,i,1)
  pcodes <- pcodeINFO$parameter_cd[pcodeINFO$class %in% i]
  titles <- paste(pcodeINFO$parameter_nm[pcodeINFO$class %in% i],"\n",pcodes,sep="")
  plotBoxPlotSets_Multiple(wideOWC,pcodes,1,titles,means)
  dev.off()
}

plotNames <- unique(pcodeINFO$class)
OWCdataByClassFull$flowConditionHYSEP <- factor(OWCdataByClassFull$flowConditionHYSEP)
wideOWC$flowConditionHYSEP <- factor(wideOWC$flowConditionHYSEP)

for (i in plotNames[!is.na(plotNames)]){
    pdf(paste(sub("/","_",i),"_hysep.pdf",sep=""),paper="a4r",width=11.0,height=8.5)
  means <- plotBoxPlotSets_Single(OWCdataByClassFull,i,1,event="flowConditionHYSEP")
  pcodes <- pcodeINFO$parameter_cd[pcodeINFO$class %in% i]
  titles <- paste(pcodeINFO$parameter_nm[pcodeINFO$class %in% i],"\n",pcodes,sep="")
  plotBoxPlotSets_Multiple(wideOWC,pcodes,1,titles,means,event="flowConditionHYSEP")
    dev.off()
}



########################
# Steve's stuff:
dataByClass <- PCodeClassSummary(wideOWC,pcodeINFO,"parameter_cd","class")
dataByClass$flowCondition <- ifelse(dataByClass$HydrologicCondition=="Stable, low stage" | dataByClass$HydrologicCondition=="Stable, normal stage","Baseflow","Event")
dataByClass$flowCondition[grep("Storm",dataByClass$HydrologicEvent)] <- "Event"
dataByClass$flowCondition <- factor(dataByClass$flowCondition)
parm <- "sumOfValues_HERBICIDE"
xLabelParm <- "site"
statParm <- "mean"
subsetVar <- TRUE
subsetValue <- "flowCondition"
countThresh <- 4
concThresh <- 200
plotTitle <- paste("Trace Organics Water Sample Results:",parm)
ylab <- "Concentration (ug/L)"
logy <- TRUE
addY <- "min10"
PlotPriorities(dataByClass,parm,xLabelParm,statParm,countThresh,concThresh,plotTitle,ylab,subsetVar,subsetValue,logy=TRUE,addY=addY)

###############################

