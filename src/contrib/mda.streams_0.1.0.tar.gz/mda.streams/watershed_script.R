library(rgdal)

shape = readOGR('/Users/jread/Downloads/basins18', layer = 'basins18')
#plot(shape)


get_shed = function(nwis_id, shape){
  
  shed_names <- as.character(unique(shape$SITE_NO))
  match_id <- which(shed_names == nwis_id)
  
  
  if (length(match_id) == 0){
    return(NULL)
  } else if(length(match_id) >1){
    stop('poly match has more than one polygon')
  }
  
  shed <- shape[match_id, ]
  
  return(shed)
}

library(mda.streams)
library(sbtools)
library(tools)
session <- authenticate_sb('jread@usgs.gov')
pow_sites <- get_sites(limit = 10000, session = session)

for (n in 1:length(pow_sites)){
  site <- pow_sites[n]
  site_num <- strsplit(site,split = '_')[[1]][2]
  shed <- get_shed(site_num, shape)
  if(!is.null(shed)){
    exists <- item_exists(scheme = 'mda_streams',type = 'watershed',key = site)
  } else {
    exists = NULL
  }
  if (!is.null(shed) && !exists){
    dsn <- tempdir()
    writeOGR(shed , dsn, site, driver="ESRI Shapefile")
    cat('building ');cat(site); cat('\n')
    shp_files <- list_files_with_exts(
      dir = dsn, exts = c('prj','shx','dbf','shp'), all.files = FALSE,full.names = TRUE)
    post_watershed(site = site, files = shp_files, session = session)
    unlink(shp_files)
    cat('posting ');cat(shp_files); cat('\n')
  } else {
    print(paste0('skipping ',site))
  }
}



