library(testthat)
library(powstreams)

test_check("powstreams")