### R code from vignette source 'linescatter.Rnw'

###################################################
### code chunk number 1: linescatter.Rnw:22-30
###################################################
# Load the USGSwsGraphs package
library(USGSwsGraphs)
# Generate random samples for the examples.
set.seed(2576)
X <- runif(33)
Y <- runif(33)
Z <- rep(c("A", "B", "C"), 11)
XD <- seq(as.Date("2010-01-05"), as.Date("2010-12-15"), length.out=33)


###################################################
### code chunk number 2: linescatter.Rnw:40-47
###################################################
# setSweave is a specialized function that sets up the graphics page for
# Sweave scripts. It should be replaced by a call to setPage or setPDF 
# in a regular script.
setSweave("lsplot01", 6 ,6)
xyPlot(X, Y, Plot=list(color="darkblue"))
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 3: linescatter.Rnw:49-51
###################################################
cat("\\includegraphics{lsplot01.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 4: linescatter.Rnw:63-70
###################################################
# setSweave is a specialized function that sets up the graphics page for
# Sweave scripts. It should be replaced by a call to setPage or setPDF 
# in a regular script.
setSweave("lsplot02", 6 ,6)
timePlot(XD, Y, Plot=list(color="darkblue"))
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 5: linescatter.Rnw:72-74
###################################################
cat("\\includegraphics{lsplot02.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 6: linescatter.Rnw:92-101
###################################################
# setSweave is a specialized function that sets up the graphics page for
# Sweave scripts. It should be replaced by a call to setPage or setPDF 
# in a regular script.
setSweave("lsplot03", 6 ,6)
# Accept the default colors for groups.
AA.pl <- colorPlot(X, Y, color=Z)
addExplanation(AA.pl, where="ul", title="")
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 7: linescatter.Rnw:103-105
###################################################
cat("\\includegraphics{lsplot03.pdf}\n")
cat("\\paragraph{}\n")


