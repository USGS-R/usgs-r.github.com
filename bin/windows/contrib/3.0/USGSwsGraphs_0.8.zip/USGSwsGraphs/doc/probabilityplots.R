### R code from vignette source 'probabilityplots.Rnw'

###################################################
### code chunk number 1: probabilityplots.Rnw:23-31
###################################################
# Load the USGSwsGraphs package
library(USGSwsGraphs)
# Generate the random data
set.seed(2736)
Xnorm <- rnorm(32)
Xlogn <- rlnorm(32)
Xmix <- exp(c(rnorm(15), rnorm(15, 0.5))) + .5
Xbig <- rnorm(100)


###################################################
### code chunk number 2: probabilityplots.Rnw:42-52
###################################################
# setSweave is a specialized function that sets up the graphics page for
# Sweave scripts. It should be replaced by a call to setPage or setPDF 
# in a regular script.
setSweave("probplot01", 6 ,6)
# Create the graph. Note that by default, the x-axis is log-transformed and
#  requires strictly positive data. Setting \texttt{xaxis.log} to
#  \texttt{FALSE} relaxes that requirement.
ecdfPlot(Xmix)
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 3: probabilityplots.Rnw:54-56
###################################################
cat("\\includegraphics{probplot01.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 4: probabilityplots.Rnw:74-79
###################################################
setSweave("probplot02", 6 ,6)
# For the normal distribution, the mean and sd arguments are optional, if
#  supplied, then a line for the fitted distribution is drawn.
probPlot(Xlogn, mean=mean(log(Xlogn)), sd=sd(log(Xlogn)))
graphics.off()


###################################################
### code chunk number 5: probabilityplots.Rnw:81-83
###################################################
cat("\\includegraphics{probplot02.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 6: probabilityplots.Rnw:96-101
###################################################
setSweave("probplot03", 6 ,6)
# Accept all of the defaults, the line is based on the mean and the standard
#  deviation of the data.
qqPlot(Xnorm)
graphics.off()


###################################################
### code chunk number 7: probabilityplots.Rnw:103-105
###################################################
cat("\\includegraphics{probplot03.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 8: probabilityplots.Rnw:119-123
###################################################
setSweave("probplot04", 6 ,6)
# Accept all of the defaults.
qqPlot(Xnorm, Xbig)
graphics.off()


###################################################
### code chunk number 9: probabilityplots.Rnw:125-127
###################################################
cat("\\includegraphics{probplot04.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 10: probabilityplots.Rnw:141-145
###################################################
setSweave("probplot05", 6 ,6)
histGram(Xbig)
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 11: probabilityplots.Rnw:147-149
###################################################
cat("\\includegraphics{probplot05.pdf}\n")
cat("\\paragraph{}\n")


