#Check raw data:

Daily <- ChopDaily
Sample <- ChopSample
INFO <- ChopINFO

multiPlotDataOverview()