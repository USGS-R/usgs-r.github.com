# Flow History Demo:
Daily <- ChopDaily
Sample <- ChopSample
INFO <- ChopINFO

annualSeries <- makeAnnualSeries()

plotFour(qUnit=3)
plotFourStats(qUnit=3)
