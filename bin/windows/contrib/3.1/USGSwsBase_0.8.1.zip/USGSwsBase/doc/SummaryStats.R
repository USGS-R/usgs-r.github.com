### R code from vignette source 'SummaryStats.Rnw'

###################################################
### code chunk number 1: SummaryStats.Rnw:21-33
###################################################
# Load the USGSwsBase package
library(USGSwsBase)
# Retrieve streamflow data for the Raccoon River at Van Meter, IA
# for the 30-year period beginning 1980-10-01.
# Use the renCol function to rename the streamflow column to Flow
RRVM <- renCol(readNWIS("05484500", begin.date="1980-10-01", 
                        end.date="2010-09-30"))
# Print the first and last few rows of the data
head(RRVM)
tail(RRVM)
# Check for missing values
with(RRVM, screenData(datetime, Flow, year = "water"))


###################################################
### code chunk number 2: SummaryStats.Rnw:45-52
###################################################
# There are no missing values, so only need the basic 
# 3 arguments for tapply
RRVM.daily <- with(RRVM, tapply(Flow, 
    baseDay(datetime, numeric=FALSE, year="water"), mean))
# Print the first and last few values of the output
head(RRVM.daily)
tail(RRVM.daily)


###################################################
### code chunk number 3: SummaryStats.Rnw:59-68
###################################################
# There are no missing values
RRVM.dailyDF <- aggregate(Flow ~ 
    baseDay(datetime, numeric=FALSE, year="water"), 
    data=RRVM, FUN=mean)
# Print the first and last few values of the output
head(RRVM.dailyDF)
tail(RRVM.dailyDF)
# Change the name of the grouping column
names(RRVM.dailyDF)[1] <- "Day"


###################################################
### code chunk number 4: SummaryStats.Rnw:78-86
###################################################
# There are no missing values
RRVM.wyDF <- aggregate(Flow ~ 
    waterYear(datetime), 
    data=RRVM, FUN=mean)
# Change the name of the grouping column
names(RRVM.wyDF)[1] <- "WaterYear"
# Print the first few values of the output
head(RRVM.wyDF)


###################################################
### code chunk number 5: SummaryStats.Rnw:96-103
###################################################
# There are no missing values
RRVM.my <- aggregate(Flow ~ month(datetime, label=TRUE) + year(datetime), 
    data=RRVM, FUN=mean)
# Rename columns 1 and 2
names(RRVM.my)[1:2] <- c("Month", "Year")
# Print the first few values of the output
head(RRVM.my)


###################################################
### code chunk number 6: SummaryStats.Rnw:108-121
###################################################
# Create new object, compute the water year and round Flow
RRVM.myTbl <- transform(RRVM.my, 
    WY=ifelse(Month %in% c("Oct", "Nov", "Dec"), Year + 1, Year),
    Flow=signif(Flow, 3))
# Reorder months
RRVM.myTbl$Month <- factor(RRVM.myTbl$Month, 
    levels=c("Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May",
             "Jun", "Jul", "Aug", "Sep"))
# Restructure the dataset, overwrite the new object
RRVM.myTbl <- group2row(RRVM.myTbl, "WY", "Month", "Flow")
# Print the first few values of the output, set width for Vignette
options(width=70)
head(RRVM.myTbl)


