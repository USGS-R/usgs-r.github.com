### R code from vignette source 'MajorIons.Rnw'

###################################################
### code chunk number 1: MajorIons.Rnw:22-26
###################################################
# Load the restrend package and the data
library(restrend)
data(EstrendSub)
head(EstrendSub)


###################################################
### code chunk number 2: MajorIons.Rnw:34-39
###################################################
# Compute FLOW.
EstrendSub <- transform(EstrendSub, FLOW=coalesce(QI, QD))
# Create the subset
Majors <- subset(EstrendSub, select=c("STAID", "DATES", "FLOW", 
																			"Calcium", "Chloride"))


###################################################
### code chunk number 3: MajorIons.Rnw:44-46
###################################################
# Create the report
sampReport(Majors, DATES="DATES", STAID="STAID", file="MajorIonSampling")


###################################################
### code chunk number 4: MajorIons.Rnw:60-64
###################################################
# Set up the project
setProj("majors", Majors, STAID="STAID", DATES="DATES", 
        Snames=c("Calcium", "Chloride"), FLOW="FLOW", 
        type="seasonal", Start="1968-10-01", End="1989-10-01")


###################################################
### code chunk number 5: MajorIons.Rnw:84-88
###################################################
# Which are OK?
estrend.st
# What seasonal definition?
estrend.ss


###################################################
### code chunk number 6: MajorIons.Rnw:99-101
###################################################
# Do the flow adjustment accepting all defaults
flowAdjust()


###################################################
### code chunk number 7: MajorIons.Rnw:107-109
###################################################
# Do the flow adjustment accepting all defaults
flowAdjust(Station="07331600", Snames=c("Calcium", "Chloride"), span=1)


###################################################
### code chunk number 8: MajorIons.Rnw:119-121
###################################################
# Trend tests, accepting default seasons
SKTrends()


###################################################
### code chunk number 9: MajorIons.Rnw:129-132
###################################################
# get the trends
majors.tnd <- getTrends()
print(majors.tnd)


###################################################
### code chunk number 10: MajorIons.Rnw:140-142
###################################################
# get the history
estrend.cl


