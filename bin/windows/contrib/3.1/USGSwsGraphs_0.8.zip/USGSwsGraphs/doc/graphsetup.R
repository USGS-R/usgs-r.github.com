### R code from vignette source 'graphsetup.Rnw'

###################################################
### code chunk number 1: graphsetup.Rnw:23-30
###################################################
# Load the USGSwsGraphs package
library(USGSwsGraphs)
# Generate the random data
set.seed(27036)
X <- rnorm(32)
Y <- X + rnorm(32)
Z <- rnorm(32, sd=1.2)


###################################################
### code chunk number 2: graphsetup.Rnw:56-63
###################################################
# Set up the graphics environment, the equivalent call for an on screen
#  device would be setPage("square")
setSweave("graph01", 6 ,6)
# 
xyPlot(X, Y)
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 3: graphsetup.Rnw:65-67
###################################################
cat("\\includegraphics{graph01.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 4: graphsetup.Rnw:86-102
###################################################
# Set up the graphics environment, the equivalent call for an on screen
#  device would be setPage("square")
setSweave("graph02", 6 ,6)
# 
xyPlot(X, Y, 
# Change from solod black circles to blue plus signs
Plot=list(symbol="+", color="blue"),
# Set the x-axis range to -2 to 2, for symmetry
xaxis.range=c(-2,2),
# label at the five integral values: -2, -1, 0, 1, 2
xlabels=5,
# Change the x- and y-axis titles and end the call
xtitle="Random Data",
ytitle="Correlated Data")
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 5: graphsetup.Rnw:104-106
###################################################
cat("\\includegraphics{graph02.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 6: graphsetup.Rnw:118-137
###################################################
# Set up the graphics environment, the equivalent call for an on screen
#  device would be setPage("square")
setSweave("graph03", 6 ,6)
# Create a scatter plot from the X and Y data. The name of the output (AA.pl)
#  is completely arbiutrary, but consistently used through these examples.
AA.pl <- xyPlot(X, Y, Plot=list(name="Correlated Data", color="blue"),
xaxis.range=c(-2,2), xlabels=5,
xtitle="Random Data",
ytitle="Response Data")
# Use the addXY function to add a plot to the graph. The output contains
#  information about both plots and cen be used to create an explanation
#  or legend.
AA.pl <- addXY(X, Z, Plot=list(name="Uncorrelated Data", what="points",
  color="darkred"), current=AA.pl)
# The addExplanation function processes the information in the output to
#  create an explanaiton of the data shown in the plots.
addExplanation(AA.pl, where="ul", title="")
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 7: graphsetup.Rnw:139-141
###################################################
cat("\\includegraphics{graph03.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 8: graphsetup.Rnw:157-185
###################################################
# Set up the graphics environment, the equivalent call for an on screen
#  device would be setPage(layout=list(width=6, height=4)).
setSweave("graph04", 6 ,4)
# Set the layout for 2 graphs in one row. and allocate room at the top for 
#  a graph title
AA.lo <- setLayout(num.cols=2, xtop=1.2)
# The first graph is the left-most graph
AA.gr <- setGraph(1, AA.lo)
# Create a scatter plot from the X and Y data. 
AA.pl <- xyPlot(X, Y, Plot=list(color="blue"),
xaxis.range=c(-2,2), xlabels=5,
xtitle="Random Data", ytitle="Correlated Data",
margin=AA.gr)
# Add the title
addTitle("A")
# The figure caption should always by the lower-left most graph
addCaption("Figure 4. Example Graphs.")
# Subsequnect graphs are placed to the right in each row
AA.gr <- setGraph(2, AA.lo)
# Create a scatter plot from the X and Y data. 
AA.pl <- xyPlot(X, Z, Plot=list(color="darkred"),
xaxis.range=c(-2,2), xlabels=5,
xtitle="Random Data", ytitle="Uncorrelated Data",
margin=AA.gr)
# Add the title
addTitle("B")
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 9: graphsetup.Rnw:187-189
###################################################
cat("\\includegraphics{graph04.pdf}\n")
cat("\\paragraph{}\n")


