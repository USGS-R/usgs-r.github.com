### R code from vignette source 'ProbabilityPlots.Rnw'

###################################################
### code chunk number 1: ProbabilityPlots.Rnw:27-35
###################################################
# Load the smwrGraphs package
library(smwrGraphs)
# Generate the random data
set.seed(2736)
Xnorm <- rnorm(32)
Xlogn <- rlnorm(32)
Xmix <- exp(c(rnorm(15), rnorm(15, 0.5))) + .5
Xbig <- rnorm(100)


###################################################
### code chunk number 2: ProbabilityPlots.Rnw:46-56
###################################################
# setSweave is a specialized function that sets up the graphics page for
# Sweave scripts. It should be replaced by a call to setPage or setPDF 
# in a regular script.
setSweave("probplot01", 6 ,6)
# Create the graph. Note that by default, the x-axis is log-transformed and
#  requires strictly positive data. Setting \texttt{xaxis.log} to
#  \texttt{FALSE} relaxes that requirement.
ecdfPlot(Xmix)
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 3: ProbabilityPlots.Rnw:58-60
###################################################
cat("\\includegraphics{probplot01.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 4: ProbabilityPlots.Rnw:78-83
###################################################
setSweave("probplot02", 6 ,6)
# For the normal distribution, the mean and sd arguments are optional, if
#  supplied, then a line for the fitted distribution is drawn.
probPlot(Xlogn, mean=mean(log(Xlogn)), sd=sd(log(Xlogn)))
graphics.off()


###################################################
### code chunk number 5: ProbabilityPlots.Rnw:85-87
###################################################
cat("\\includegraphics{probplot02.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 6: ProbabilityPlots.Rnw:100-105
###################################################
setSweave("probplot03", 6 ,6)
# Accept all of the defaults, the line is based on the mean and the standard
#  deviation of the data.
qqPlot(Xnorm)
graphics.off()


###################################################
### code chunk number 7: ProbabilityPlots.Rnw:107-109
###################################################
cat("\\includegraphics{probplot03.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 8: ProbabilityPlots.Rnw:123-127
###################################################
setSweave("probplot04", 6 ,6)
# Accept all of the defaults.
qqPlot(Xnorm, Xbig)
graphics.off()


###################################################
### code chunk number 9: ProbabilityPlots.Rnw:129-131
###################################################
cat("\\includegraphics{probplot04.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 10: ProbabilityPlots.Rnw:146-150
###################################################
setSweave("probplot05", 6 ,6)
histGram(Xbig)
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 11: ProbabilityPlots.Rnw:152-154
###################################################
cat("\\includegraphics{probplot05.pdf}\n")
cat("\\paragraph{}\n")


###################################################
### code chunk number 12: ProbabilityPlots.Rnw:161-171
###################################################
# Compute the density
Xbig.den <- density(Xbig)
range(Xbig.den$x)
setSweave("probplot06", 6 ,6)
# Set type to density and xaxis range to -4, 3.5 by setting breaks
histGram(Xbig, breaks=seq(-4, 3.5, by=.5), Hist=list(type="density"))
# Add the density line, the defaults all work so current arg not needed
with(Xbig.den, addXY(x, y))
# Required call to close PDF output graphics
graphics.off()


###################################################
### code chunk number 13: ProbabilityPlots.Rnw:173-175
###################################################
cat("\\includegraphics{probplot06.pdf}\n")
cat("\\paragraph{}\n")


