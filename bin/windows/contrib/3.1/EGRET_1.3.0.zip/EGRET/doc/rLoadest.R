
## ----openLibrary, echo=FALSE---------------------------------------------
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)



## ----include=TRUE ,echo=FALSE,eval=TRUE----------------------------------
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, concordance=TRUE,tidy=FALSE,comment="")

knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)

bold.colHeaders <- function(x) {
  x <- gsub("\\^(\\d)","$\\^\\1$",x)
  x <- gsub("\\%","\\\\%",x)
  x <- gsub("\\_"," ",x)
  returnX <- paste("\\multicolumn{1}{c}{\\textbf{\\textsf{", x, "}}}", sep = "")
}

addSpace <- function(x) ifelse(x != "1", "[5pt]","")



## ----workflowFlowHistory, echo=TRUE,eval=FALSE---------------------------
## install.packages(c("rloadest"),
##   repos=c("http://usgs-r.github.com",
##           "http://cran.us.r-project.org"),
##   dependencies=TRUE)


## ----openlibraries, echo=TRUE,eval=TRUE,message=FALSE--------------------
library(EGRET)
library(dataRetrieval)
library(rloadest)
library(survival)

siteid <- "01491000"
pcode <- "00631"
startDate <- "1979-10-24"
endDate <- "2011-09-29"

Daily <- getDVData(siteid,"00060",startDate,endDate)
Sample <- getSampleData(siteid,pcode,startDate,endDate)
Sample <- mergeReport()
INFO <- getMetaData(siteid,pcode,interactive=FALSE)
modelEstimation()


## ----removeDuplicates, echo=TRUE,eval=TRUE, warning=FALSE----------------
Sample <- Sample[!duplicated(Sample$Date),]



## ----loadestModel, echo=TRUE,eval=TRUE, warning=FALSE--------------------

loadestModel <- loadReg(Surv(ConcLow, ConcHigh, type="interval2")
                        ~ model(9), 
                   data = Sample, 
                   flow = "Q", dates = "Date",
                   flow.units="cms",
                   conc.units="mg/l",
                   station=INFO$station.nm)

# To see a complete summary of the model results:
# print(loadestModel, brief=FALSE, load.only=FALSE)



## ----loadestPredicts, echo=TRUE,eval=TRUE, warning=FALSE-----------------

# Make DailyLoadest
DailyLoadest <- Daily[,which(!(names(Daily) %in% 
      c("ConcDay","FluxDay","FNConc","FNFlux","SE","yHat")))]

concs <- predConc(loadestModel,DailyLoadest, by="day")
flux <- predLoad(loadestModel,DailyLoadest, by="day")

predictResp <- fitted(loadestModel$cfit, type='response')
predictResp_mean <- fitted(loadestModel$cfit, type='mean')

DailyLoadest$ConcDay <- concs$Conc
DailyLoadest$FluxDay <- DailyLoadest$ConcDay*86.4*DailyLoadest$Q
DailyLoadest$SE <- concs$Std.Err

# Make SampleLoadest

SampleLoadest <- Sample[,which(!(names(Sample) %in% 
        c("yHat","SE","ConcHat")))]

SampleLoadest$SE <- concs$Std.Err[
  which(concs$Date %in% SampleLoadest$Date)]
SampleLoadest$yHat <-predictResp
SampleLoadest$ConcHat <- predictResp_mean



## ----plotFluxBiasLoadest, echo=TRUE,fig.cap="fluxMulti LoadEst",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth',fig.pos="h"----
fluxBiasMulti(localSample = SampleLoadest,
              localDaily=DailyLoadest,
              moreTitle="LoadEst")


## ----plotResidPred, echo=TRUE, fig.cap="Concentration and flux predictions",fig.subcap=c('WRTDS','rloadest'),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold',fig.pos="h"----
plotResidPred()
plotResidPred(localSample = SampleLoadest)


## ----plotResidQ, echo=TRUE, fig.cap="Concentration and flux predictions",fig.subcap=c('WRTDS','rloadest'),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold',fig.pos="h"----
plotResidQ()
plotResidQ(localSample = SampleLoadest)


## ----plotResidTime, echo=TRUE, fig.cap="Concentration and flux predictions",fig.subcap=c('WRTDS','rloadest'),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold',fig.pos="h"----
plotResidTime()
plotResidTime(localSample = SampleLoadest)


## ----boxResidMonth, echo=TRUE, fig.cap="Concentration and flux predictions",fig.subcap=c('WRTDS','rloadest'),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold',fig.pos="h"----
boxResidMonth()
boxResidMonth(localSample = SampleLoadest)


## ----boxConcThree, echo=TRUE, fig.cap="Concentration and flux predictions",fig.subcap=c('WRTDS','rloadest'),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold',fig.pos="h"----
boxConcThree()
boxConcThree(localDaily = DailyLoadest, 
             localSample = SampleLoadest)


## ----plotConcPred, echo=TRUE, fig.cap="Concentration and flux predictions",fig.subcap=c('WRTDS','rloadest'),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold',fig.pos="h"----
plotConcPred()
plotConcPred(localSample = SampleLoadest)


## ----rloadestPlot1, echo=FALSE, eval=TRUE--------------------------------
setSweave("figure/ratingCurve", 5, 5)
plot(loadestModel, which=1, set.up=FALSE)
graphics.off()


## ----rloadestPlot1Show, echo=TRUE, eval=FALSE----------------------------
## plot(loadestModel, which=1, set.up=FALSE)


## ----rloadestPlot2, echo=FALSE, eval=TRUE--------------------------------
setSweave("figure/residuals", 5, 5)
plot(loadestModel, which=2, set.up=FALSE)
graphics.off()


## ----rloadestPlot2Show, echo=TRUE, eval=FALSE----------------------------
## plot(loadestModel, which=2, set.up=FALSE)


## ----rloadestPlot3, echo=FALSE, eval=TRUE--------------------------------
setSweave("figure/scaleLocation", 5, 5)
plot(loadestModel, which=3, set.up=FALSE)
graphics.off()


## ----rloadestPlot3Show, echo=TRUE, eval=FALSE----------------------------
## plot(loadestModel, which=3, set.up=FALSE)


## ----rloadestPlot4, echo=FALSE, eval=TRUE--------------------------------
setSweave("figure/correlogram", 5, 5)
plot(loadestModel, which=4, set.up=FALSE)
graphics.off()


## ----rloadestPlot4Show, echo=TRUE, eval=FALSE----------------------------
## plot(loadestModel, which=4, set.up=FALSE)


## ----rloadestPlot5, echo=FALSE, eval=TRUE--------------------------------
setSweave("figure/qNormal", 5, 5)
plot(loadestModel, which=5, set.up=FALSE)
graphics.off()


## ----rloadestPlot5Show, echo=TRUE, eval=FALSE----------------------------
## plot(loadestModel, which=5, set.up=FALSE)


## ----rloadestPlot6, echo=FALSE, eval=TRUE--------------------------------
setSweave("figure/loadestBox", 5, 5)
plot(loadestModel, which=6, set.up=FALSE)
graphics.off()


## ----rloadestPlot6Show, echo=TRUE, eval=FALSE----------------------------
## plot(loadestModel, which=6, set.up=FALSE)


